"use strict";

/**
 * source 角色薄壳（CJS）：动作名与 service.mjs 导出名同名，直接转发。
 *
 * 实现见 plugins/hongguo/PLAN.md §4.1。
 */

const bridge = require("../lib/bridge.js");

const actions = {
  sites: (args) => bridge.call("sites", args),
  search: (args) => bridge.call("search", args),
  detail: (args) => bridge.call("detail", args),
  play: (args) => bridge.call("play", args),
  probe: (args) => bridge.call("probe", args),
};

module.exports = { actions };
