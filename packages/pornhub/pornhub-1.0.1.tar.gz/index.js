'use strict';
/**
 * Pornhub 插件 · 入口（薄）。
 * 多类型包：按角色分组 actions（见 docs/adr/0046），宿主按消息带的 role 分发。
 *   metadata → roles/metadata.js（域 pornhub：register / search / lookup / season）
 *   source   → roles/source.js（sites / search / detail / play / probe）
 *   home     → roles/home.js（rows / run / http：精选/最新/热门/最多观看/最高评分/我的最爱）
 */
module.exports = {
  actions: {
    metadata: require('./roles/metadata').actions,
    source: require('./roles/source').actions,
    home: require('./roles/home').actions,
  },
};
