'use strict';
/**
 * Emby 片源设置页的前端。
 *
 * 主页面只列服务器（一行一台：名字 / 地址 / 登录态 / 编辑·删除），
 * 添加与编辑都在模态框里完成（连接、账号密码、登录、自检），不把页面拉长。
 * 模态框结构 / 类名与面板 core/dom.js 的 modal() 同款（.mbox*，样式随 SDK 一起进来）。
 * 所有请求打到面板的转发通道 `/api/plugins/<类型>/<id>/api/**`（前缀按页面地址算出，不写死）。
 */
const API = location.pathname.replace(/\/ui\/.*$/, '') + '/api';
const $ = (id) => document.getElementById(id);

let STATE = null;

async function call(path, { method = 'GET', body } = {}) {
  const res = await fetch(API + path, {
    method,
    headers: body ? { 'Content-Type': 'application/json' } : undefined,
    body: body ? JSON.stringify(body) : undefined,
  });
  let data = null;
  try {
    data = await res.json();
  } catch {
    throw new Error(`面板回的不是 JSON（HTTP ${res.status}）`);
  }
  if (!res.ok || data.ok === false) throw new Error(errText(data, res.status));
  return data;
}

/** 从任意形状的响应里抠一句人能读的错 */
function errText(data, status) {
  const e = data && data.error;
  if (typeof e === 'string' && e) return e;
  if (e && typeof e === 'object') {
    if (typeof e.message === 'string' && e.message) return e.message;
    const s = JSON.stringify(e);
    if (s && s !== '{}') return s;
  }
  if (typeof (data && data.message) === 'string' && data.message) return data.message;
  return `HTTP ${status}`;
}

let msgTimer = null;
function say(text, bad = false) {
  const el = $('msg');
  el.textContent = text || '';
  el.style.color = bad ? 'var(--err)' : 'var(--accent)';
  if (msgTimer) clearTimeout(msgTimer);
  msgTimer = setTimeout(() => {
    el.textContent = '';
  }, 5000);
}

const fmtMB = (n) => (Number(n || 0) / 1024 / 1024).toFixed(1);

/** 极简建节点：el('div', {class, onclick, text}, 子节点…) */
function el(tag, props, ...kids) {
  const node = document.createElement(tag);
  for (const [k, v] of Object.entries(props || {})) {
    if (v === null || v === undefined || v === false) continue;
    if (k === 'text') node.textContent = String(v);
    else if (k === 'html') node.innerHTML = String(v);
    else if (k.slice(0, 2) === 'on' && typeof v === 'function') node.addEventListener(k.slice(2), v);
    else node.setAttribute(k, String(v));
  }
  for (const kid of kids.flat().filter(Boolean)) node.append(kid);
  return node;
}

function field(labelText, input, hint) {
  return el('div', { class: 'field' }, el('label', { text: labelText }), input, hint ? el('div', { class: 'note', text: hint }) : null);
}

/* ------------------------------------------------------------- 模态框 */

let currentModal = null;

/**
 * 与面板 core/dom.js 的 modal() 同款：.mbox-mask > .mbox(head/body/actions)。
 * actions: [{label, primary, onclick}]，onclick 返回 false 不关窗口。
 * 同一时刻只有一个；✕ / Esc / 点遮罩关闭。
 */
function openModal({ title, body, actions = [], onClose }) {
  if (currentModal) currentModal.close();
  const close = () => {
    document.removeEventListener('keydown', onKey);
    mask.remove();
    if (currentModal && currentModal.root === mask) currentModal = null;
    if (typeof onClose === 'function') onClose();
  };
  const onKey = (e) => {
    if (e.key === 'Escape') close();
  };
  const box = el(
    'div',
    { class: 'mbox', role: 'dialog', 'aria-modal': 'true' },
    el(
      'div',
      { class: 'mbox-head' },
      el('h3', { text: title || '' }),
      el('button', { class: 'mbox-x', text: '✕', 'aria-label': '关闭', onclick: close })
    ),
    el('div', { class: 'mbox-body' }, ...body),
    el(
      'div',
      { class: 'mbox-actions' },
      ...actions.map((a) =>
        el('button', {
          class: 'btn' + (a.primary ? ' primary' : '') + (a.danger ? ' danger' : ''),
          text: a.label,
          onclick: async (e) => {
            if (!a.onclick) return close();
            const btn = e.currentTarget;
            btn.disabled = true;
            try {
              const keep = await a.onclick({ close });
              if (keep !== false) close();
            } catch (err) {
              /* 出错不关窗口（输入不丢）；错误本身由 onclick 自己往框内状态行写，这里兜个顶 */
              say(err.message, true);
            } finally {
              btn.disabled = false;
            }
          },
        })
      )
    )
  );
  const mask = el('div', { class: 'mbox-mask' }, box);
  mask.addEventListener('click', (e) => {
    if (e.target === mask) close();
  });
  document.body.append(mask);
  document.addEventListener('keydown', onKey);
  const first = box.querySelector('input:not([type=checkbox]), select, textarea');
  if (first) setTimeout(() => first.focus(), 20);
  currentModal = { root: mask, close };
  return currentModal;
}

/** 页内确认框（替代原生 confirm）：回 true/false */
function confirmModal(title, text, dangerLabel = '删除') {
  return new Promise((resolve) => {
    let settled = false;
    const done = (v) => {
      if (settled) return;
      settled = true;
      resolve(v);
    };
    openModal({
      title,
      body: [el('div', { class: 'note', style: 'margin:0;white-space:pre-line', text })],
      actions: [
        { label: '取消', onclick: () => done(false) },
        {
          label: dangerLabel,
          danger: true,
          onclick: () => done(true),
        },
      ],
      onClose: () => done(false),
    });
  });
}

/* ------------------------------------------------------- 服务器编辑框 */

/** 登录态徽章：已登录=绿 / 配了账号=黄或灰（区分有无密码）/ 没配账号=灰 */
function authBadge(a) {
  const x = a || {};
  if (x.loggedIn) return el('span', { class: 'badge badge-success', text: x.username ? `已登录 · ${x.username}` : '已登录' });
  if (x.username && x.hasPassword) return el('span', { class: 'badge badge-warning', text: `已存账号 · ${x.username}` });
  if (x.username) return el('span', { class: 'badge badge-ghost', text: `账号 · ${x.username}（无密码）` });
  return el('span', { class: 'badge badge-ghost', text: '未配置凭据' });
}

/** 一条分区小标题（模态框内分组用） */
function sectionTitle(text) {
  return el('div', { style: 'font-size:12px;color:var(--fg-dim-2);margin:4px 0 -2px', text });
}

/**
 * 添加 / 编辑一台外部 Emby 的模态框。
 * @param {object|null} srv 已保存服务器（编辑）；null = 新增
 */
function editServerModal(srv) {
  const isAdd = !srv;
  let key = srv ? srv.key : '';

  const nameI = el('input', { type: 'text', placeholder: '例：动漫', value: srv ? srv.name : '', autocomplete: 'off' });
  const baseI = el('input', {
    type: 'text',
    placeholder: 'https://media.example.com',
    value: srv ? srv.base : '',
    autocomplete: 'off',
  });
  /* 账号 / 密码回显已保存值（密码留空保存 = 真空密码，Emby 允许无密码账号） */
  const savedAuth = key ? (STATE.auth || {})[key] : null;
  const userI = el('input', {
    type: 'text',
    placeholder: 'Emby 用户名（可先不填）',
    value: savedAuth ? savedAuth.username || '' : '',
    autocomplete: 'off',
  });
  const passI = el('input', {
    type: 'password',
    placeholder: '没有密码就留空',
    value: savedAuth ? savedAuth.password || '' : '',
    autocomplete: 'new-password',
  });
  const badgeHost = el('div');
  const wdI = el('input', { type: 'text', value: '让子弹飞' });
  const testPre = el('pre', { class: 'raw-json', style: 'display:none;margin:0' });

  /* 框内状态行：成功 / 失败都写这里（模态打开时页面顶部那句看不见，不能只靠它） */
  const msgLine = el('div', { class: 'note', style: 'margin:0;min-height:16px;font-weight:600' });
  const formMsg = (text, bad = false) => {
    msgLine.textContent = text || '';
    msgLine.style.color = bad ? 'var(--err)' : 'var(--ok, var(--accent))';
  };

  /** 点一下就「忙」起来的按钮：禁用 + 换文案，失败把真实报错写进框内状态行 */
  function busyBtn(label, busyText, fn, extraClass = '') {
    const b = el('button', { class: `btn ${extraClass}`.trim(), text: label });
    b.addEventListener('click', async () => {
      b.disabled = true;
      b.textContent = busyText;
      try {
        await fn();
      } catch (err) {
        formMsg((err && err.message) || String(err), true);
      } finally {
        b.disabled = false;
        b.textContent = label;
      }
    });
    return b;
  }

  const renderBadge = () => {
    badgeHost.textContent = '';
    const a = key ? (STATE.auth || {})[key] : null;
    if (a) badgeHost.append(authBadge(a));
    else badgeHost.append(el('span', { class: 'badge badge-ghost', text: '保存后可配账号' }));
  };
  renderBadge();

  /**
   * 唯一的「保存」：名字 / 地址 + 填了的账号密码一次存掉。
   * 新增成功后拿生成的 key 就地重开为编辑态（接着可登录 / 自检）；编辑则留在框里。
   * 返回 false = 不关窗口。
   */
  const saveAll = async () => {
    const name = nameI.value.trim();
    const base = baseI.value.trim();
    if (!name) {
      formMsg('给这台外部 Emby 起个名字', true);
      return false;
    }
    if (!base) {
      formMsg('填外部 Emby 的客户端可达地址（如 https://media.example.com）', true);
      return false;
    }
    const d = await call('/servers', { method: 'POST', body: { key: key || undefined, name, base } });
    const saved = d.settings.servers.find(
      (x) => x.name === name && x.base.replace(/\/+$/, '') === base.replace(/\/+$/, '')
    );
    if (!saved) throw new Error('保存后找不到这台服务器');

    /* 凭据：编辑已有服务器时原样回写（输入框已回显）；新增时填了任意一项才存。
     * 密码留空 = 真空密码（不是「不改动」）。 */
    const hasCredInput = userI.value.trim() || passI.value;
    if (!isAdd || hasCredInput) {
      await call('/credentials', {
        method: 'POST',
        body: { key: saved.key, username: userI.value.trim(), password: passI.value },
      });
    }

    if (isAdd || key !== saved.key) {
      currentModal.close();
      await repaint(d);
      editServerModal(saved);
      say('已添加 —— 可点「登录一下」验证');
      return false;
    }
    await repaint(d);
    renderBadge();
    formMsg('已保存');
    say('已保存');
    return false;
  };

  const doLogin = async () => {
    /* 直接读编辑框：没保存 / 改了没保存 → 后端只验不落盘；与已存一致 → 真登录记令牌 */
    const base = baseI.value.trim();
    if (!base) throw new Error('先填外部 Emby 地址');
    if (!userI.value.trim()) throw new Error('先填账号（无密码账号把密码留空即可）');
    formMsg('');
    const d = await call('/login', {
      method: 'POST',
      body: { key: key || undefined, name: nameI.value.trim(), base, username: userI.value.trim(), password: passI.value },
    });
    if (d.persisted === false) {
      formMsg(`账号验证通过（${(d.verified && d.verified.username) || userI.value.trim()}）—— 还没落盘，点「保存」后记住`);
      return;
    }
    await repaint(d);
    renderBadge();
    formMsg('登录成功');
  };

  const doLogout = async () => {
    if (!key) throw new Error('还没保存，没有本地登录态可清');
    formMsg('');
    const d = await call('/logout', { method: 'POST', body: { key } });
    await repaint(d);
    renderBadge();
    formMsg('本地登录态已清掉（账号密码保留）');
  };

  const doTest = async () => {
    if (!baseI.value.trim()) throw new Error('先填外部 Emby 地址');
    formMsg('');
    testPre.style.display = 'none';
    /* 账号 / 密码留空就不带 —— 后端回落该站已保存的凭据（带空串会把已存值盖掉） */
    const body = { key: key || undefined, name: nameI.value.trim(), base: baseI.value.trim(), wd: wdI.value };
    if (userI.value) body.username = userI.value;
    if (passI.value) body.password = passI.value;
    const d = await call('/test', { method: 'POST', body });
    const r = d.result || {};
    const infoLine = !r.info
      ? '连通性：未检测'
      : r.info.ok
        ? `连通性：${r.info.ms} ms · Emby ${r.info.version || '?'} · ServerId ${r.info.serverId || '?'}`
        : `连通性：失败 · ${r.info.error || '未知原因'}`;
    const searchLine = !r.search
      ? '搜索：未检测'
      : r.search.ok
        ? (() => {
            /* count=本次实际返回；total=服务器自报总命中数，有些服不填（0），那就别显示「共 0」 */
            const m = Number(r.search.total) || 0;
            const num = m > 0 ? `${r.search.count} 条（服务器报共 ${m}）` : `${r.search.count} 条（服务器未报总数）`;
            return `搜索「${r.wd || ''}」：${r.search.ms} ms · ${num}${r.search.loggedIn ? ' · 已登录' : ''}` +
              (r.search.top && r.search.top.length ? `\n  ${r.search.top.join(' | ')}` : '');
          })()
        : `搜索「${r.wd || ''}」：失败 · ${r.search.error || '未知原因'}`;
    testPre.style.display = 'block';
    testPre.textContent = [`地址：${r.base || ''}`, infoLine, searchLine, `账号：${r.auth && r.auth.username ? r.auth.username : '（未填）'}`].join('\n');
    if (!r.info || !r.info.ok || !r.search || !r.search.ok) formMsg('自检有项没通过，看下面详情', true);
    else formMsg('自检通过');
  };

  openModal({
    title: isAdd ? '添加外部 Emby' : `编辑 · ${srv.name}`,
    body: [
      msgLine,
      sectionTitle('连接'),
      field('名字', nameI, '分组头显示「Emby · 名字」'),
      field('客户端可达地址', baseI),
      sectionTitle('账号'),
      field('账号', userI),
      field('密码', passI),
      badgeHost,
      el(
        'div',
        { class: 'row btn-fan', style: 'margin:2px 0 0' },
        busyBtn('登录一下', '登录中…', doLogin, 'primary'),
        busyBtn('退出登录', '退出中…', doLogout, 'danger')
      ),
      sectionTitle('自检'),
      el(
        'div',
        { class: 'row', style: 'align-items:flex-end;margin-bottom:0' },
        el('div', { class: 'field', style: 'flex:1;margin:0' }, el('label', { text: '搜索关键词' }), wdI),
        busyBtn('自检', '自检中…', doTest)
      ),
      testPre,
    ],
    actions: [
      { label: '关闭' },
      { label: '保存', primary: true, onclick: saveAll },
    ],
  });
}

/* ------------------------------------------------------------- 列表 */

function renderServers() {
  const tb = $('srvBody');
  tb.textContent = '';
  const list = (STATE.settings && STATE.settings.servers) || [];
  const table = $('srvTable');
  if (!list.length) {
    tb.append(el('tr', {}, el('td', { colspan: '4', class: 'note muted', style: 'text-align:left', text: '还没有外部 Emby —— 点右上角「＋ 添加」加一台。' })));
    return;
  }
  for (const srv of list) {
    const a = (STATE.auth || {})[srv.key] || {};
    const tr = el(
      'tr',
      {},
      el('td', { 'data-label': '名字' }, el('strong', { text: srv.name })),
      el('td', { 'data-label': '地址', class: 'muted' }, el('span', { style: 'word-break:break-all', text: srv.base })),
      el('td', { 'data-label': '登录态' }, authBadge(a)),
      el(
        'td',
        { 'data-label': '操作', style: 'text-align:right;white-space:nowrap' },
        el(
          'button',
          {
            class: 'btn mini',
            onclick: () => editServerModal(srv),
          },
          '编辑'
        ),
        ' ',
        el(
          'button',
          {
            class: 'btn mini danger',
            onclick: async () => {
              const yes = await confirmModal(
                `删除 · ${srv.name}`,
                `删除外部 Emby「${srv.name}」？\n它的账号、密码与令牌会一起删掉。`,
                '删除'
              );
              if (!yes) return;
              await repaint(await call('/servers/delete', { method: 'POST', body: { key: srv.key } }));
              say('已删除');
            },
          },
          '删除'
        )
      )
    );
    tb.append(tr);
  }
}

async function repaint(d) {
  if (d) STATE = d;
  const c = STATE.cacheSettings || {};
  $('cacheTtl').value = c.ttlMinutes !== undefined ? c.ttlMinutes : 30;
  $('cacheMax').value = c.maxMB !== undefined ? c.maxMB : 128;

  const group = STATE.group || {};
  const n = ((STATE.settings && STATE.settings.servers) || []).length;
  $('where').textContent =
    `组 ${group.name || ''} · ${n} 台外部 Emby · 插件 ${(STATE.plugin && STATE.plugin.name) || ''} ${(STATE.plugin && STATE.plugin.version) || ''}`;

  const up = (STATE.cache && STATE.cache.tables && STATE.cache.tables.upstream) || {};
  const cap = up.maxBytes > 0 ? `${fmtMB(up.maxBytes)} MB` : '不限';
  const ttl = c.ttlMinutes > 0 ? `${c.ttlMinutes} 分钟` : '不缓存';
  $('cacheState').textContent =
    `已用 ${fmtMB(STATE.cache && STATE.cache.bytes)} MB / 上限 ${cap} · ${(STATE.cache && STATE.cache.rows) || 0} 条 · 有效期 ${ttl}`;

  renderServers();
}

async function load() {
  try {
    await repaint(await call('/state'));
  } catch (e) {
    say('读不到状态：' + e.message, true);
  }
}

/* ---------------- 事件接线 ---------------- */

$('addBtn').addEventListener('click', () => editServerModal(null));

$('cacheSave').addEventListener('click', async (e) => {
  e.target.disabled = true;
  try {
    await repaint(
      await call('/cache/settings', {
        method: 'POST',
        body: { cacheTtlMinutes: Number($('cacheTtl').value), cacheMaxMB: Number($('cacheMax').value) },
      })
    );
    say('缓存设置已保存');
  } catch (err) {
    say('保存失败：' + err.message, true);
  }
  e.target.disabled = false;
});

$('cacheReload').addEventListener('click', async () => {
  try {
    await load();
    say('缓存用量已刷新');
  } catch (err) {
    say('刷新失败：' + err.message, true);
  }
});

$('cacheClear').addEventListener('click', async (e) => {
  const yes = await confirmModal('清空缓存', '清空缓存？下次搜索会重新打 Emby。', '清空');
  if (!yes) return;
  e.target.disabled = true;
  try {
    await repaint(await call('/cache/clear', { method: 'POST' }));
    say('缓存已清空');
  } catch (err) {
    say('清空失败：' + err.message, true);
  }
  e.target.disabled = false;
});

load();
