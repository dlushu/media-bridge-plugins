'use strict';
/**
 * Pornhub 源角色：站点清单 / 搜索 / 详情 / 解析 / 测速。
 *
 *   sites   → {sources, sites}（单实例 main + 单站点 pornhub）
 *   search  → {key, wd, page} → 上游形状 {status, ok, text, json:{list:[{vod_id, vod_name, vod_pic, vod_remarks}]}}
 *   detail  → {key, id} → 上游形状 + detail:{lines:[{name, playVia:'proxy', items:[{name, ref}]}]}
 *   play    → {ref} → {urls, header, parse:0}
 *   probe   → 一发探针（上游形状）
 *
 * 播放链说明（诚实标注）：
 *   Pornhub 的 HLS 地址必须带完整详情页 Referer 才给播，客户端带不了这个头，
 *   所以线路统一标 `playVia: 'proxy'` —— 面板代持头中继（relay-playlist 改写清单，
 *   手机全程不直连 Pornhub，也就没有"取址 IP 与播放 IP 不一致"的问题）。
 *   ref 只留 viewkey 和清晰度。CDN 签名地址的寿命不写进 ref：hv-h 那批 e= 还没到期
 *   上游也会 410，写进去 play 就会把死地址交回去。
 */
const ph = require('../lib/ph');
const { createCache } = require('../lib/cache');
const pkg = require('../plugin.json');

const defsCache = createCache(); // viewkey → getMediaDefs 结果，20 分钟

const b64e = (o) => Buffer.from(JSON.stringify(o), 'utf8').toString('base64url');
const b64d = (s) => JSON.parse(Buffer.from(String(s), 'base64url').toString('utf8'));

/**
 * ref 形状（源契约硬性约定）：`<插件 id>/<插件自己定的东西>`。
 * 面板只按第一段（插件 id）路由，其余原样交回 play。
 * 1.2.1 及以前漏了前缀 —— 面板在路由这步就报 BAD_REF，播放从来没进过插件。
 */
const REF_PREFIX = `${pkg.id}/`;
const makeRef = (o) => REF_PREFIX + b64e(o);
/** play 收到的是完整 ref（含前缀）；也兼容没前缀的裸 payload */
function parseRef(ref) {
  const s = String(ref || '');
  const at = s.indexOf('/');
  return b64d(at >= 0 ? s.slice(at + 1) : s);
}

const errUp = (e) => ({
  status: 0, ok: false, text: '', json: null,
  error: { code: (e && e.code) || 'UPSTREAM', message: (e && e.message) || String(e) },
});

async function getDefs(viewkey, timeoutMs) {
  const ck = `defs:${viewkey}`;
  return defsCache.dedup(ck, async () => {
    const hit = defsCache.get(ck);
    if (hit) return hit;
    const defs = await ph.getMediaDefs(viewkey, timeoutMs);
    defsCache.set(ck, defs, 20 * 60000);
    return defs;
  });
}

/**
 * 对上用户点的那一档。拿不到可靠批次时会降级 embed，embed 只有一个默认档，
 * 清晰度还可能是画布尺寸（854/426）而不是 1080/720。
 * 对不上就取最高档里带 validto= 的。没有带 validto= 的地址就不交：
 * hv-h 的 e= 还没到期，上游也会 410，不能拿它冒充还能播。
 */
async function pickUrl(viewkey, want, timeoutMs) {
  const defs = await getDefs(viewkey, timeoutMs);
  const hls = defs.hls || [];
  const reli = (h) => /[?&]validto=/.test(String(h.url || ''));
  const byQuality = hls.filter((h) => String(h.quality || '') === want && reli(h));
  const pick = byQuality[0]
            || hls.filter(reli).slice().sort((a, b) => (Number(b.quality) || 0) - (Number(a.quality) || 0))[0];
  if (!pick) throw Object.assign(new Error('Pornhub 未返回可播地址'), { code: 'NO_URL' });
  return pick.url;
}

/** 清单是不是这批作废。只认 403/404/410；网络失败不当作废，交给面板自己再取一次。 */
async function playlistDead(url, referer, timeoutMs) {
  try {
    const r = await ph.fetchText(url, { timeoutMs: Math.min(8000, timeoutMs), referer });
    return r.status === 403 || r.status === 404 || r.status === 410;
  } catch {
    return false;
  }
}

/** hls 条目 → 版本项（按清晰度从高到低） */
function itemsOf(viewkey, hls) {
  const seen = new Set();
  const items = [];
  const sorted = (hls || []).slice().sort((a, b) => (Number(b.quality) || 0) - (Number(a.quality) || 0));
  for (const h of sorted) {
    const q = String(h.quality || '');
    if (q && seen.has(q)) continue;
    if (q) seen.add(q);
    const item = {
      name: q ? `${q}p` : '默认',
      // 这条路固定是 HLS。不报的话面板 Container 留空，DirectStreamUrl 落成裸 stream，
      // 靠后缀认类型的客户端（ExoPlayer 系）不会当清单播。
      container: 'hls',
      ref: makeRef({ v: viewkey, q }),
    };
    const height = Number(q);
    if (height > 0) item.height = height; // 规格字段：面板拿它标版本，知道才给
    items.push(item);
  }
  return items;
}

const actions = {
  /** 站点清单 */
  async sites() {
    return {
      sources: [
        { id: 'main', name: 'Pornhub', url: 'https://www.pornhub.com', mode: 'remote', enabled: true, ok: true, ms: 0, siteCount: 1 },
      ],
      sites: [
        { key: 'pornhub', name: 'Pornhub', api: 'https://www.pornhub.com', searchable: true, source: 'main' },
      ],
    };
  },

  /** 搜候选：{key, wd, page} */
  async search(args = {}, ctx) {
    const wd = String(args.wd || '').trim();
    const page = Math.max(1, Number(args.page) || 1);
    if (!wd) return { status: 200, ok: true, text: '', json: { list: [] } };
    try {
      const cards = await ph.searchVideos(wd, page, Number(args.timeoutMs) || 25000);
      return {
        status: 200, ok: true, text: '',
        json: {
          list: cards.map((c) => ({
            vod_id: c.viewkey,
            vod_name: c.title,
            vod_pic: ph.proxifyPoster(c.thumb || ''),
            vod_remarks: [c.duration, c.views].filter(Boolean).join(' · '),
          })),
        },
      };
    } catch (e) {
      return errUp(e);
    }
  },

  /** 取详情：{key, id} → 线路→选集（每清晰度一个版本项） */
  async detail(args = {}) {
    const vk = ph.extractViewkey(args.id);
    if (!vk) {
      return { status: 200, ok: true, text: '', json: null, detail: null, detailNote: `认不出 viewkey：${String(args.id || '').slice(0, 40)}` };
    }
    try {
      const defs = await getDefs(vk, Number(args.timeoutMs) || 30000);
      const items = itemsOf(vk, defs.hls);
      if (!items.length) {
        return {
          status: 200, ok: true, text: '', json: { viewkey: vk, via: defs.via },
          detail: null,
          detailNote: defs.walled ? 'Pornhub 详情页被年龄墙拦截，embed 也未返回可播地址' : 'Pornhub 未返回可播地址',
        };
      }
      return {
        status: 200, ok: true, text: '',
        json: { viewkey: vk, via: defs.via, qualities: items.map((x) => x.name) },
        vod_id: vk, // 直绑回传：资源级坐标（本插件即 viewkey），面板不解释、原样记 ProviderIds
        detail: {
          // flag 是版本标题里的线路名；只写 name 的话面板拼出来是「Pornhub · undefined」。
          lines: [{ name: 'Pornhub', flag: 'HLS', playVia: 'proxy', items }],
        },
        detailNote: '',
      };
    } catch (e) {
      return errUp(e);
    }
  },

  /** 解析播放地址：{ref} → {urls, header}（Referer 必须是完整详情页地址） */
  async play(args = {}) {
    let r;
    try { r = parseRef(args.ref); }
    catch { return errUp(Object.assign(new Error('播放 ref 认不出'), { code: 'BAD_REF' })); }
    const vk = ph.extractViewkey(r.v);
    if (!vk) return errUp(Object.assign(new Error('播放 ref 里没有 viewkey'), { code: 'BAD_REF' }));
    const timeoutMs = Number(args.timeoutMs) || 20000;
    try {
      // 每次现解析。旧 ref 里带的 u/exp 不再用：签名时间还在不代表这批地址还活着。
      defsCache.del(`defs:${vk}`);
      const want = String(r.q || '');
      let url = await pickUrl(vk, want, timeoutMs);
      // 交出前探一次清单。410/403/404 是这批作废，丢掉缓存再换一批，只再试一次。
      const dead = await playlistDead(url, ph.DETAIL_URL(vk), timeoutMs);
      if (dead) {
        defsCache.del(`defs:${vk}`);
        url = await pickUrl(vk, want, timeoutMs);
        if (await playlistDead(url, ph.DETAIL_URL(vk), timeoutMs)) {
          throw Object.assign(new Error(`Pornhub ${want || '默认'} 档清单已失效`), { code: 'UPSTREAM' });
        }
      }
      return {
        status: 200, ok: true, text: '', json: {},
        urls: [url],
        header: { 'Referer': ph.DETAIL_URL(vk), 'User-Agent': ph.UA },
        parse: 0,
      };
    } catch (e) {
      return errUp(e);
    }
  },

  /** 设置页后端挂在 home 角色上，这里转发（避免循环引用，懒加载） */
  async http(args = {}, ctx) {
    return require('./home').actions.http(args, ctx);
  },

  /** 测速探针 */
  async probe(args = {}) {
    const t0 = Date.now();
    try {
      const r = await ph.fetchText('https://www.pornhub.com/', { timeoutMs: Math.min(15000, Number(args.timeoutMs) || 15000) });
      return { status: 200, ok: r.status === 200, text: '', json: {}, name: 'Pornhub', ms: Date.now() - t0 };
    } catch (e) {
      return { status: 0, ok: false, text: '', json: null, name: 'Pornhub', ms: Date.now() - t0, error: { code: (e && e.code) || 'UPSTREAM', message: (e && e.message) || String(e) } };
    }
  },
};

module.exports = { actions };
