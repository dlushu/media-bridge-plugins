"use strict";

/**
 * 红果短剧三合一插件入口（CJS）。
 *
 * `actions` 用「角色分组」形状：面板 runner 见对象即按 `roleActions[角色]` 取动作表，
 * 角色名来自 `plugin.json` 的 `types`（面板按 `types[0]` 作为本次实例的 `type`）。
 */

module.exports = {
  actions: {
    home: require("./roles/home.js").actions,
    source: require("./roles/source.js").actions,
    metadata: require("./roles/metadata.js").actions,
  },
};
