'use strict';
/**
 * 迅雷字幕 —— 字幕插件。
 *
 * 契约见 framework/contracts/contract-subtitle.md：
 *   · tracks：入参是这一集/这一部片的坐标 { name, originalName, year, season, episode }
 *            → [{ lang, format, label?, ref }]；报空数组 = 没有字幕。
 *   · fetch ：入参只有 { ref } → { body, contentType? }；body 是 UTF-8 字符串。
 *
 * 上游：`https://api-shoulei-ssl.xunlei.com/oracle/subtitle?name=<query>`（迅雷字幕库搜索）。
 * 实测口径（本地验证过）：
 *   · 带集号查询才定位得准（"繁花 第01集" / "繁花 S01E01"），裸片名会误匹配。
 *   · `languages` 字段是垃圾值（["默认"] / [""] / ["x264-*"]），语言只能从文件名猜。
 *   · 结果有重复（同 url 出现两次），要按 url 去重。
 *
 * ref 形状：`xunlei-subtitle/<下载地址的 base64url>` —— 自包含、可重复解析（fetch 只认 ref，
 * 不需要重跑 tracks 反查）。字幕内容缓存在插件自己的 data/ 下（契约第七节）。
 * 失败**抛异常**（带 e.code），不返回 { ok:false } 那种业务信封（字幕桥不认）。
 *
 * 设置（接口地址 / 缓存时长）由插件自己在 data/settings.json 声明并存储（总契约第九节），
 * 设置页走 `http` 动作读写；`plugin.json` 的 `webui` 让面板在「字幕」栏挂出入口。
 */

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const httpFetch = globalThis.fetch;
const DEFAULT_API_BASE = 'https://api-shoulei-ssl.xunlei.com/oracle/subtitle?name=';
const UA =
  'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 ' +
  '(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36';
const FORMATS = ['srt', 'ass', 'ssa', 'vtt'];
/** tracks 结果的默认缓存时长（迅雷字幕库变动慢，6 小时足够；fetch 结果永久缓存） */
const DEFAULT_CACHE_HOURS = 6;

/* ------------------------------------------------------------------ 设置 */

function settingsFile(ctx) {
  return path.join(ctx.dataDir, 'settings.json');
}

function readSettings(ctx) {
  try {
    const obj = JSON.parse(fs.readFileSync(settingsFile(ctx), 'utf8'));
    return obj && typeof obj === 'object' ? obj : {};
  } catch {
    return {};
  }
}

function writeSettings(ctx, obj) {
  fs.mkdirSync(ctx.dataDir, { recursive: true });
  fs.writeFileSync(settingsFile(ctx), JSON.stringify(obj, null, 2));
}

/** 设置合并默认值：空/非法一律回退默认，调用点拿到的永远是可用配置。 */
function settingsOf(ctx) {
  const s = readSettings(ctx);
  const apiBase = String(s.apiBase || '').trim() || DEFAULT_API_BASE;
  const hours = Number(s.cacheHours);
  return {
    apiBase,
    cacheMs: Number.isFinite(hours) && hours >= 0 ? hours * 3600 * 1000 : DEFAULT_CACHE_HOURS * 3600 * 1000,
  };
}

/* ------------------------------------------------------------------ 缓存 */

/** 内存缓存（秒回）+ 在途合并（并发重复只打一发上游） */
const memTracks = new Map();
const memContent = new Map();
const inflight = new Map();

function sha1(s) {
  return crypto.createHash('sha1').update(String(s)).digest('hex');
}

function cacheDir(ctx, kind) {
  const dir = path.join(ctx.dataDir, 'cache', kind);
  fs.mkdirSync(dir, { recursive: true });
  return dir;
}

function readTracksCache(ctx, key, ttlMs) {
  const hit = memTracks.get(key);
  if (hit && Date.now() - hit.at < ttlMs) return hit.rows;
  try {
    const f = path.join(cacheDir(ctx, 'tracks'), key + '.json');
    const obj = JSON.parse(fs.readFileSync(f, 'utf8'));
    if (obj && Array.isArray(obj.rows) && Date.now() - Number(obj.at) < ttlMs) {
      memTracks.set(key, { at: Number(obj.at), rows: obj.rows });
      return obj.rows;
    }
  } catch {
    /* 没缓存 / 坏了都当没命中 */
  }
  return null;
}

function writeTracksCache(ctx, key, rows) {
  const at = Date.now();
  memTracks.set(key, { at, rows });
  try {
    fs.writeFileSync(path.join(cacheDir(ctx, 'tracks'), key + '.json'), JSON.stringify({ at, rows }));
  } catch {
    /* 落盘失败不影响本次结果 */
  }
}

/* ------------------------------------------------------- 坐标 → 查询串 */

function pad2(n) {
  return String(n).padStart(2, '0');
}

/** 用"带集号"的查询串定位（裸片名会误匹配）；电影没有季集号时退到 `片名 年份`。 */
function buildQuery(coord) {
  const name = String((coord && coord.name) || '').trim();
  const year = String((coord && coord.year) || '').trim();
  const season = coord && coord.season;
  const episode = coord && coord.episode;
  if (episode === null || episode === undefined || episode === '') {
    return year ? `${name} ${year}` : name;
  }
  const e = Number(episode);
  const s = Number(season);
  if (Number.isFinite(s) && s > 0) return `${name} S${pad2(s)}E${pad2(e)}`;
  return `${name} 第${pad2(e)}集`;
}

/* --------------------------------------------------- 语言 / 格式 / 集号 */

/* 顺序有讲究：先"繁"再"简"，最后兜底中文（迅雷库以中文为主）。 */
const LANG_RULES = [
  [/(繁体|繁體|\bcht\b|zh[-_]?tw|zh[-_]?hk|\btc\b|big5|正体|正體)/i, 'zh-TW'],
  [/(简体|簡體|\bchs\b|zh[-_]?cn|\bsc\b|gb2312|简中|簡中)/i, 'zh-CN'],
  [/(中文|中字|chinese|\bchi\b)/i, 'zh-CN'],
  [/(english|\beng\b|英语|英文|英語|\ben\b)/i, 'en'],
  [/(japanese|\bjpn?\b|日语|日文|日本語)/i, 'ja'],
  [/(korean|\bkor\b|韩语|韩文|한국|\bko\b)/i, 'ko'],
];

function guessLang(text) {
  const s = String(text || '');
  for (const [re, lang] of LANG_RULES) if (re.test(s)) return lang;
  return 'zh'; // 认不出时保守给 zh（契约要求 lang 必填；迅雷库绝大多数是中文轨）
}

/** `ext` 优先；认不出再看文件名后缀；再认不出按 srt。 */
function detectFormat(ext, name) {
  const raw = String(ext || '').toLowerCase().replace(/^\./, '');
  if (FORMATS.includes(raw)) return raw;
  const m = String(name || '').toLowerCase().match(/\.(srt|ass|ssa|vtt)(?:$|[?#])/);
  return m ? m[1] : 'srt';
}

/** 结果文件名/别名是否指向我们要的那一集（过滤掉"9分钟读完《三体1》"这类噪声）。 */
function matchesEpisode(hay, episode) {
  const e = Number(episode);
  if (!Number.isFinite(e)) return true;
  const n = String(e);
  const nn = pad2(e);
  const s = String(hay || '');
  return [
    new RegExp(`[eE][pP]?0*${n}(?![0-9])`), // E01 / EP01 / E1 / e1
    new RegExp(`第\\s*0*${n}\\s*[集话話]`), // 第01集 / 第1话
    new RegExp(`(?:^|[^0-9])0*${nn}(?:[^0-9]|$)`), // 独立出现 01
  ].some((re) => re.test(s));
}

/* --------------------------------------------------------------- ref */

function makeRef(url) {
  return 'xunlei-subtitle/' + Buffer.from(String(url), 'utf8').toString('base64url');
}

function refToUrl(ref) {
  const s = String(ref || '');
  const at = s.indexOf('/');
  const rest = at >= 0 ? s.slice(at + 1) : '';
  let url = '';
  try {
    url = Buffer.from(rest, 'base64url').toString('utf8');
  } catch {
    url = '';
  }
  return /^https?:\/\//i.test(url) ? url : '';
}

/* ------------------------------------------------------------ 上游调用 */

async function apiSearch(query, apiBase) {
  const res = await httpFetch(apiBase + encodeURIComponent(query), {
    headers: { 'User-Agent': UA, Accept: 'application/json' },
  });
  if (!res.ok) {
    const e = new Error(`迅雷字幕接口 HTTP ${res.status}`);
    e.code = 'UPSTREAM_HTTP';
    throw e;
  }
  const json = await res.json();
  return Array.isArray(json && json.data) ? json.data : [];
}

/* ------------------------------------------------------------ 动作实现 */

const actions = {
  async tracks(args, ctx) {
    const coord = args || {};
    const name = String(coord.name || '').trim();
    if (!name) return []; // 没片名就没法搜；如实回空

    const query = buildQuery(coord);
    const key = sha1('tracks|' + query);
    const cfg = settingsOf(ctx);

    const cached = readTracksCache(ctx, key, cfg.cacheMs);
    if (cached) return cached;
    if (inflight.has(key)) return inflight.get(key);

    const job = (async () => {
      const list = await apiSearch(query, cfg.apiBase);
      const episode = coord.episode;

      const seenUrl = new Set();
      /* 同一语言 + 同一格式只留分数最高的一条（结果里同片多份、噪声多，收敛成干净轨表） */
      const best = new Map();
      for (const it of list) {
        const url = String((it && it.url) || '').trim();
        if (!url || seenUrl.has(url)) continue;
        seenUrl.add(url);
        const hay = `${(it && it.name) || ''} ${(it && it.extra_name) || ''}`;
        if (!matchesEpisode(hay, episode)) continue;
        const lang = guessLang(hay);
        const format = detectFormat(it.ext, it.name);
        const score = Number(it.score) || 0;
        const k = lang + '|' + format;
        const prev = best.get(k);
        if (!prev || score > prev.score) best.set(k, { lang, format, score, it });
      }

      const rows = [...best.values()]
        .sort((a, b) => b.score - a.score || a.lang.localeCompare(b.lang))
        .map(({ lang, format, it }) => ({
          lang,
          format,
          label: String(it.name || '').trim() || `${lang} ${format}`,
          ref: makeRef(it.url),
        }));

      writeTracksCache(ctx, key, rows);
      return rows;
    })();

    inflight.set(key, job);
    try {
      return await job;
    } finally {
      inflight.delete(key);
    }
  },

  async fetch(args, ctx) {
    const ref = String((args && args.ref) || '');
    const url = refToUrl(ref);
    if (!url) {
      const e = new Error(`认不出这个字幕 ref：${ref.slice(0, 80) || '(空)'}`);
      e.code = 'BAD_REF';
      throw e;
    }

    const key = sha1(url);
    const hitMem = memContent.get(key);
    if (hitMem) return { body: hitMem };

    const file = path.join(cacheDir(ctx, 'content'), key + '.txt');
    try {
      const onDisk = fs.readFileSync(file, 'utf8');
      memContent.set(key, onDisk);
      return { body: onDisk };
    } catch {
      /* 未缓存，联网取 */
    }

    const res = await httpFetch(url, { headers: { 'User-Agent': UA }, redirect: 'follow' });
    if (!res.ok) {
      const e = new Error(`下载字幕 HTTP ${res.status}`);
      e.code = 'UPSTREAM_HTTP';
      throw e;
    }
    const buf = Buffer.from(await res.arrayBuffer());
    const text = decodeText(buf);

    memContent.set(key, text);
    try {
      fs.writeFileSync(file, text);
    } catch {
      /* 落盘失败不影响本次结果 */
    }
    /* 不回 contentType —— 面板按轨的 format 落一份（service.js 的 SUBTITLE_CONTENT_TYPE） */
    return { body: text };
  },

  /**
   * webui 转发通道（总契约第九节）：设置页的读写走这里。
   * 接口地址 / 缓存时长是插件自己的配置，声明与存储都归插件（存进自己的 data/settings.json）。
   */
  async http(args, ctx) {
    if (args.path === '/save' && args.method === 'POST') {
      let body;
      try {
        body = JSON.parse(args.body || '{}');
      } catch {
        return { status: 400, body: { ok: false, error: 'bad json' } };
      }
      const next = {};
      if (typeof body.apiBase === 'string') next.apiBase = body.apiBase.trim();
      if (body.cacheHours !== null && body.cacheHours !== undefined && body.cacheHours !== '') {
        const h = Number(body.cacheHours);
        if (Number.isFinite(h) && h >= 0) next.cacheHours = h;
      }
      writeSettings(ctx, next);
      return { body: { ok: true } };
    }
    if (args.path === '/settings') {
      const s = readSettings(ctx);
      return { body: { apiBase: s.apiBase || '', cacheHours: s.cacheHours == null ? null : s.cacheHours } };
    }
    return { status: 404, body: { ok: false, error: 'no route' } };
  },
};

/** BOM 优先；否则严格试 UTF-8，失败按 GB18030（GBK 超集）解 —— 与参考实现同口径。 */
function decodeText(buf) {
  if (buf.length >= 3 && buf[0] === 0xef && buf[1] === 0xbb && buf[2] === 0xbf) {
    return buf.slice(3).toString('utf8');
  }
  try {
    return new TextDecoder('utf-8', { fatal: true }).decode(buf);
  } catch {
    return new TextDecoder('gb18030').decode(buf);
  }
}

module.exports = { actions };
