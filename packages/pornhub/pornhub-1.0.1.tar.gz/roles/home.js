'use strict';
/**
 * Pornhub 首页角色：rows / run / http。
 *
 * 行：
 *   featured    精选      /video
 *   newest      最新      /video?o=cm
 *   hot         热门      /video?o=ht
 *   most_viewed 最多观看  /video?o=mv
 *   top_rated   最高评分  /video?o=tr
 *   recommended 推荐视频  /recommended（带登录 Cookie = 个性化推荐；不带 = 通用推荐）
 *   favorites   我的最爱  /users/<用户名>/videos/favorites（公开收藏，只填用户名、不用登录；
 *               与 CapyPlayer 组件同款地址。未填用户名时这一行不申报）
 *
 * 失败按契约 throw（回 {ok:false} 会被宿主当成"成功但空行"）。
 * 一页必须填满：按 startIndex+limit 窗口连续取上游页再切。
 */
const crypto = require('crypto');
const ph = require('../lib/ph');
const settings = require('../lib/settings');
const { createCache } = require('../lib/cache');
const pkg = require('../plugin.json');

const rowCache = createCache();
const strip = (s) => String(s || '').trim();

const LIST_ROWS = [
  { id: 'featured', title: '精选', order: 'featured' },
  { id: 'newest', title: '最新', order: 'newest' },
  { id: 'hot', title: '热门', order: 'hot' },
  { id: 'most_viewed', title: '最多观看', order: 'most_viewed' },
  { id: 'top_rated', title: '最高评分', order: 'top_rated' },
  { id: 'recommended', title: '推荐视频', order: 'recommended' },
  /* 轮播推荐位专用行：客户端"不带库 Id、只要一批条目"的那条查询由面板按 `feed` 路由过来 ——
   * 面板把那条查询认成 `feed:'random'`，找**第一个**声明它的行（见契约 `contract-home.md` 的 `feed`）。
   * 没有任何行声明时，客户端首页那块轮播**恒为空**。 */
  { id: 'random', title: '随机', order: 'random' },
];
const FAV_ROW = { id: 'favorites', title: '我的最爱', order: 'favorites' };
const ALL_ROWS = [...LIST_ROWS, FAV_ROW];

/** 轮播位要"每次看不一样"，缓存得比别人短；其余行 10 分钟 */
const CACHE_SEC = (id) => (id === 'favorites' ? 300 : id === 'random' ? 60 : 600);

/**
 * 洗牌（Fisher–Yates）：`random` 行的取数用。
 * 上游没有"随机排序"入口，取一页再打乱最省事、也不算编数据（条目都真实存在，只是顺序随机）。
 * 分页语义在这里不重要：轮播只取十来条，跨页重复由 `fetchWindow` 的 `seen` 兜住。
 */
function shuffle(arr) {
  const a = Array.isArray(arr) ? arr.slice() : [];
  for (let i = a.length - 1; i > 0; i -= 1) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

function wire(ctx) {
  if (ctx && ctx.dataDir) settings.setDataDir(ctx.dataDir);
}

function savedUsername() {
  return settings.readSettings().favoritesUsername || '';
}
function savedCookie() {
  return settings.readSettings().cookie || '';
}

/** 参数优先级：本次 run 带的 params > 设置页存的 */
function resolveUsername(args) {
  const fromParams = args && args.params && strip(args.params.username);
  return fromParams || savedUsername();
}

function toHomeItem(c) {
  const item = {
    id: `pornhub_${c.viewkey}_movie`,
    type: 'movie',
    title: c.title,
    providerIds: { pornhub: c.viewkey },
    sourceLoc: { site: 'pornhub', vodId: c.viewkey },
  };
  const poster = ph.proxifyPoster(c.thumb);
  /* 放行**根相对**的封面（面板图片中继 `/api/emby/img/…`，见 lib/ph.js 的 proxifyPoster）——
   * 只认 http(s) 的话，pix-cdn77 那批封面会被这里整条丢掉，条目一个图都没有。 */
  if (poster && /^(https?:\/\/|\/)/i.test(poster)) item.poster = poster;
  const bits = [c.duration, c.views ? `${c.views} 次播放` : ''].filter(Boolean);
  if (bits.length) item.overview = bits.join(' · ');
  return item;
}

/**
 * 按窗口连续取上游页（pageSize 条/页），再切出 [startIndex, startIndex+limit)。
 * fetchPage(page) → 卡片数组；某页不满 pageSize 或为空即到尾。
 */
async function fetchWindow(fetchPage, pageSize, startIndex, limit) {
  const startPage = Math.floor(startIndex / pageSize) + 1;
  const base = (startPage - 1) * pageSize;
  const acc = [];
  const seen = new Set(); // 上游页之间有重复卡片（推荐流混入），窗口内先去重免得同一条出现两次
  let page = startPage;
  let lastFull = false;
  while (base + acc.length < startIndex + limit && page < startPage + 10) {
    const items = await fetchPage(page);
    if (!items.length) { lastFull = false; break; }
    for (const it of items) {
      if (seen.has(it.viewkey)) continue;
      seen.add(it.viewkey);
      acc.push(it);
    }
    lastFull = items.length >= pageSize;
    if (!lastFull) break;
    page += 1;
  }
  // 最后一页是满的 → 后面可能还有，total 报「至少这么多」免得客户端以为到尾
  const total = lastFull ? base + acc.length + 1 : base + acc.length;
  return { items: acc.slice(startIndex - base, startIndex - base + limit), total };
}

const actions = {
  /** 行清单：收藏行只在已填用户名时申报 */
  async rows(args = {}, ctx) {
    wire(ctx);
    const rows = LIST_ROWS.map((r) => {
      const row = { id: r.id, title: r.title, collectionType: 'movies', cacheDuration: CACHE_SEC(r.id) };
      /* 轮播推荐位：声明 `feed` 之后，面板把客户端那条"不要库 Id、只要一批条目"的查询路由到这一行
       * （面板把它认成 `feed:'random'`，取第一个声明的行）。不声明 ⇒ 客户端首页轮播**恒为空**。 */
      if (r.order === 'random') row.feed = 'random';
      return row;
    });
    const u = savedUsername();
    if (u) {
      rows.push({
        id: FAV_ROW.id, title: FAV_ROW.title, collectionType: 'movies', cacheDuration: 300,
        params: [{ name: 'username', title: 'Pornhub 用户名', type: 'input', value: u, description: '填用户名即可看公开收藏，不用登录' }],
      });
    }
    return { ok: true, rows };
  },

  /** 跑一行：{ rowId, params?, startIndex?, limit? } → { items, total, cached? } */
  async run(args = {}, ctx) {
    wire(ctx);
    const row = ALL_ROWS.find((r) => r.id === strip(args.rowId));
    if (!row) throw new Error(`未知行: ${args.rowId}`);
    const startIndex = Math.max(0, Number(args.startIndex) || 0);
    const limit = Math.min(60, Math.max(1, Number(args.limit) || 24));
    const timeoutMs = Number(args.timeoutMs) || 25000;

    let cacheTag = '';
    let fetchPage;
    let pageSize;
    if (row.order === 'favorites') {
      const username = resolveUsername(args);
      if (!username) {
        throw Object.assign(new Error('未填写 Pornhub 用户名（插件设置页填写后，这一行才会出现）'), { code: 'NO_USERNAME' });
      }
      cacheTag = `fav:${username}`;
      pageSize = 45; // 收藏一页条数随账号而定（实测 39/47），按列表页同口径窗口取数；不满即到尾
      fetchPage = (p) => ph.favoritesVideos(username, p, timeoutMs);
    } else if (row.order === 'recommended') {
      const cookie = (args.params && strip(args.params.cookie)) || savedCookie();
      // 缓存键只放 cookie 指纹，不放原文
      cacheTag = cookie ? `rec:${crypto.createHash('md5').update(cookie).digest('hex').slice(0, 8)}` : 'rec:anon';
      pageSize = ph.REC_PAGE_SIZE;
      fetchPage = (p) => ph.recommendedVideos(p, { cookie, timeoutMs });
    } else if (row.order === 'random') {
      /* 轮播推荐位：上游没有随机排序入口，取一页**精选**再打乱 —— 条目都真实存在，只是顺序随机。 */
      cacheTag = 'random';
      pageSize = ph.LIST_PAGE_SIZE;
      fetchPage = async (p) => shuffle(await ph.listVideos('featured', p, timeoutMs));
    } else {
      cacheTag = row.id;
      pageSize = ph.LIST_PAGE_SIZE;
      fetchPage = (p) => ph.listVideos(row.order, p, timeoutMs);
    }

    const cacheKey = `home|${cacheTag}|${startIndex}|${limit}`;
    const hit = rowCache.get(cacheKey);
    if (hit) return Object.assign({ cached: true }, hit);
    const { items, total } = await fetchWindow(fetchPage, pageSize, startIndex, limit);
    const out = { items: items.map((c) => toHomeItem(c)), total };
    rowCache.set(cacheKey, out, CACHE_SEC(row.id) * 1000);
    return out;
  },

  /** 设置页后端：state / settings / test */
  async http(args = {}, ctx) {
    wire(ctx);
    const method = String(args.method || 'GET').toUpperCase();
    const p = String(args.path || '/').replace(/\/+$/, '') || '/';
    let body = {};
    if (args.body) {
      try { body = typeof args.body === 'string' ? JSON.parse(args.body) : args.body; }
      catch { return { status: 400, body: { ok: false, error: '请求体不是 JSON' } }; }
    }
    const ok = (v) => ({ status: 200, body: Object.assign({ ok: true }, v) });
    const bad = (status, message) => ({ status, body: { ok: false, error: message } });
    const state = () => ({
      plugin: { id: pkg.id, name: pkg.name, version: pkg.version },
      ...settings.publicSettings(),
    });
    try {
      if (p === '/state' && method === 'GET') return ok(state());
      if (p === '/settings' && method === 'POST') {
        const patch = {};
        if (body.username !== undefined) patch.favoritesUsername = strip(body.username);
        if (body.cookie !== undefined) patch.cookie = strip(body.cookie);
        settings.writeSettings(patch);
        return ok(state());
      }
      if (p === '/test' && method === 'POST') {
        if (body.kind === 'recommended') {
          const cookie = strip(body.cookie) || savedCookie();
          const cards = await ph.recommendedVideos(1, { cookie, timeoutMs: 25000 });
          return ok({ result: { kind: 'recommended', personalized: !!cookie, count: cards.length, top: cards.slice(0, 3).map((c) => c.title) } });
        }
        const u = strip(body.username) || savedUsername();
        if (!u) return bad(400, '先填写用户名');
        const cards = await ph.favoritesVideos(u, 1, 25000);
        return ok({ result: { kind: 'favorites', username: u, count: cards.length, top: cards.slice(0, 3).map((c) => c.title) } });
      }
      return bad(404, `设置页没有这个接口：${method} ${p}`);
    } catch (e) {
      const msg = (e && typeof e.message === 'string' && e.message) || String(e || '未知错误');
      return bad(400, msg);
    }
  },
};

module.exports = { actions };
