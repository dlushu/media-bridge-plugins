'use strict';
/**
 * SubtitleCat 字幕插件入口（动作层）
 *
 * 契约见开发套件仓 framework/contracts/contract-subtitle.md（通用部分在 plugin-contract.md 第八节）。
 * 两个动作 + 设置页后端：
 *
 *   tracks  申报字幕轨  {name, originalName, year, season, episode}
 *                       **只认番号**：坐标里提不出番号就回空数组（不占位、不按标题搜）；
 *                       搜到就按下载量取最优条目、按语言顺序挑一个版本，回**一条轨**
 *   fetch   取字幕内容  {ref}     ref 自带 `subtitlecat/` 前缀，解开是站内下载路径
 *   http    webui 后端  {method,path,query,body}  插件自己设置页的后端
 *
 * 坐标里的 `season` / `episode` **不用** —— 番号片没有季集概念（电影式），
 * 字幕与线路无关，面板为一个播放目标只问一次。
 *
 * 缓存归插件自己（总契约第八节）：「番号 → 挑中的下载项」按设置缓存；
 * 字幕正文基本不变，按长 TTL 缓存（SUBS_TTL_MS）；冷缓存的并发同键请求由
 * `cache.singleflight` 去重 —— 同一番号、同一条字幕同时只放一发打站点。
 */
const settings = require('./lib/settings');
const cache = require('./lib/cache');
const code = require('./lib/code');
const site = require('./lib/site');
const pkg = require('./plugin.json');

const PLUGIN_ID = pkg.id;

/** 单次请求的超时（面板对 tracks 的调用预算默认 20s，这些加起来要留在里面） */
const SEARCH_TIMEOUT_MS = 6000;
const DETAIL_TIMEOUT_MS = 4000;
const DOWNLOAD_TIMEOUT_MS = 10000;
/** 一次 tracks 最多爬几个详情页（按下载量从高到低，拿到语言链接就停） */
const MAX_DETAIL_PAGES = 2;
/** 「搜过了、没有」的负缓存：短 TTL，免得同一个没字幕的番号每次打开详情都打站点 */
const NEG_TTL_MS = 30 * 60 * 1000;
/** 字幕正文的缓存窗口：内容基本不变，长缓存（30 天） */
const SUBS_TTL_MS = 30 * 24 * 60 * 60 * 1000;

/** 每次动作进来先登记数据目录（缓存、设置都按它定位） */
function useCtx(ctx) {
  if (ctx && ctx.dataDir) settings.setDataDir(ctx.dataDir);
}

/* ---------------------------------------------------------------- ref */

/** ref = `<插件 id>/<base64url(JSON)>`，载荷 `{ u: 站内下载路径, f: 格式 }` */
function encodeRef(payload) {
  return `${PLUGIN_ID}/${Buffer.from(JSON.stringify(payload), 'utf8').toString('base64url')}`;
}

function decodeRef(ref) {
  const s = String(ref || '');
  const prefix = `${PLUGIN_ID}/`;
  if (!s.startsWith(prefix)) return null;
  try {
    const o = JSON.parse(Buffer.from(s.slice(prefix.length), 'base64url').toString('utf8'));
    if (!o || typeof o !== 'object' || !o.u) return null;
    return o;
  } catch {
    return null;
  }
}

/* ---------------------------------------------------------------- 挑轨 */

const LANG_TAG = { 'zh-CN': '【简中】', 'zh-TW': '【繁中】', en: '【英文】', ja: '【日文】', ko: '【韩文】' };
const tagOf = (lang) => LANG_TAG[lang] || `【${lang || '字幕'}】`;

/** 按设置里的语言顺序挑一个版本：顺序表里没有的排最后，保持站内原有次序 */
function chooseByLang(links, langOrder) {
  const order = String(langOrder || '')
    .split(',')
    .map((x) => x.trim().toLowerCase())
    .filter(Boolean);
  const rank = (l) => {
    const i = order.indexOf(String(l.lang || '').toLowerCase());
    return i < 0 ? order.length + 1 : i;
  };
  return links.slice().sort((a, b) => rank(a) - rank(b))[0] || null;
}

/**
 * 番号 → 挑中的下载项 `{ path, lang, format, code, title, downloads }`；没有回 null。
 * 结果（含「没有」）写 search 表缓存；`fresh` = 绕过缓存（自检用）。
 */
async function resolveTrack(cfg, avCode, { fresh = false } = {}) {
  const key = ['pick', cfg.siteBase, cfg.langOrder, avCode].join('|');
  if (!fresh) {
    const hit = cache.get('search', key);
    if (hit) return hit.none ? null : hit;
  }

  const run = async () => {
    /* 先试带横杠的番号，再试紧凑形（去横杠）—— 先中先用 */
    const words = [...new Set([avCode, avCode.replace(/[-_ ]/g, '')])].filter(Boolean);
    let matches = [];
    for (const word of words) {
      matches = await site.searchPage(cfg.siteBase, word, SEARCH_TIMEOUT_MS);
      if (matches.length) break;
    }

    let picked = null;
    for (const top of matches.slice(0, MAX_DETAIL_PAGES)) {
      const links = await site.detailLinks(cfg.siteBase, top.sid, top.slug, DETAIL_TIMEOUT_MS);
      const one = chooseByLang(links, cfg.langOrder);
      if (one) {
        picked = {
          path: one.path,
          lang: one.lang || 'und',
          format: one.format,
          code: avCode,
          title: top.title,
          downloads: top.downloads,
        };
        break;
      }
    }

    cache.put('search', key, picked || { none: true }, picked ? cache.limits().ttlMs : NEG_TTL_MS);
    return picked;
  };

  /* `fresh`（自检）要求绕过缓存真打站点，连去重也一起绕过；正常并发同一番号只放一发 */
  return fresh ? run() : cache.singleflight(key, run);
}

/** 挑中的下载项 → 契约的一条轨 `{ lang, format, label, ref }` */
function trackOf(picked) {
  return {
    lang: picked.lang,
    format: picked.format,
    label: `${tagOf(picked.lang)}${picked.code}`,
    ref: encodeRef({ u: picked.path, f: picked.format }),
  };
}

const CONTENT_TYPE = { srt: 'application/x-subrip', ass: 'text/x-ssa', ssa: 'text/x-ssa', vtt: 'text/vtt' };

/* ---------------------------------------------------------------- 动作 */

const actions = {
  /**
   * 申报字幕轨 —— **只认番号**：坐标提不出番号就回空数组（面板如实不填任何轨）。
   * 搜到就回**一条轨**（下载量最优条目 × 语言顺序最优版本）。
   */
  async tracks(args, ctx) {
    useCtx(ctx);
    const cfg = settings.read();
    const avCode = code.codeOf(args);
    if (!avCode) {
      if (ctx) ctx.log(`字幕：坐标里提不出番号（${String((args && (args.originalName || args.name)) || '').slice(0, 60)}），按口径一条都不报`);
      return [];
    }
    const picked = await resolveTrack(cfg, avCode);
    if (!picked) {
      if (ctx) ctx.log(`字幕：番号 ${avCode} 在 SubtitleCat 没搜到可用的`);
      return [];
    }
    if (ctx) ctx.log(`字幕：番号 ${avCode} → ${tagOf(picked.lang)}${picked.title || picked.path}（下载 ${picked.downloads} 次）`);
    return [trackOf(picked)];
  },

  /** 取字幕内容 —— 解开 ref 里的下载路径，抓正文原样回；失败如实抛（面板如实落状态码） */
  async fetch(args, ctx) {
    useCtx(ctx);
    const cfg = settings.read();
    const o = decodeRef(args && args.ref);
    if (!o) {
      const e = new Error(`认不出这个字幕 ref：${String((args && args.ref) || '').slice(0, 80)}`);
      e.code = 'BAD_REF';
      throw e;
    }
    const key = ['sub', cfg.siteBase, o.u].join('|');
    const hit = cache.get('subs', key);
    if (hit && hit.body) {
      if (ctx) ctx.log(`字幕：缓存命中 ${o.u} —— 不打站点`);
      return { body: hit.body, contentType: hit.contentType };
    }
    /* 并发点开同一条轨（或客户端一发多连）只下载一次，其余等这发的结果 */
    return cache.singleflight(key, async () => {
      const body = await site.download(cfg.siteBase, o.u, DOWNLOAD_TIMEOUT_MS);
      if (!String(body || '').trim()) {
        const e = new Error(`SubtitleCat 回的字幕是空的：${o.u}`);
        e.code = 'UPSTREAM';
        throw e;
      }
      const contentType = CONTENT_TYPE[o.f] || CONTENT_TYPE.srt;
      cache.put('subs', key, { body, contentType }, SUBS_TTL_MS);
      if (ctx) ctx.log(`字幕：取到 ${o.u}（${body.length} 字）`);
      return { body, contentType };
    });
  },

  /** 插件设置页的后端（面板只转发、不解释，见总契约第九节） */
  async http(args, ctx) {
    useCtx(ctx);
    const method = String(args.method || 'GET').toUpperCase();
    const p = String(args.path || '/').replace(/\/+$/, '') || '/';
    let body = {};
    if (args.body) {
      try {
        body = typeof args.body === 'string' ? JSON.parse(args.body) : args.body;
      } catch {
        return { status: 400, body: { ok: false, error: '请求体不是 JSON' } };
      }
    }
    const ok = (v) => ({ status: 200, body: Object.assign({ ok: true }, v) });
    const bad = (status, message) => ({ status, body: { ok: false, error: message } });
    const state = () => ({
      plugin: { id: pkg.id, name: pkg.name, version: pkg.version },
      settings: settings.read(),
      cacheSettings: settings.cacheCfg(),
      cache: cache.stats(),
    });

    try {
      if (p === '/state' && method === 'GET') return ok(state());

      if (p === '/settings' && method === 'POST') {
        settings.setSite(body);
        return ok(state());
      }

      if (p === '/cache' && method === 'GET') {
        return ok({ cacheSettings: settings.cacheCfg(), cache: cache.stats() });
      }
      if (p === '/cache/clear' && method === 'POST') {
        return ok({ cacheSettings: settings.cacheCfg(), cache: cache.clear(body.table ? String(body.table) : '') });
      }
      if (p === '/cache/settings' && method === 'POST') {
        const next = settings.setCache(body);
        cache.sweep('search', { force: true });
        cache.sweep('subs', { force: true });
        return ok({ cacheSettings: next, cache: cache.stats() });
      }

      if (p === '/test' && method === 'POST') {
        return ok({ result: await selfTest(body) });
      }

      return bad(404, `插件设置页没有这个接口：${method} ${p}`);
    } catch (e) {
      return bad(400, (e && e.message) || String(e));
    }
  },
};

/**
 * 一键自检：给一个番号（或一段标题），完整跑一遍「提番号 → 搜索 → 详情页 → 挑轨」，
 * 绕过缓存真打站点；每段如实报（不猜、不兜底）。
 */
async function selfTest(body) {
  const cfg = settings.read();
  const input = String((body && body.code) || '').trim() || 'SSIS-001';
  const t0 = Date.now();
  const out = { base: cfg.siteBase, input, langOrder: cfg.langOrder, code: '', search: null, pick: null, ms: 0 };

  out.code = code.extractSearchCode(input) || '';
  if (!out.code) {
    out.search = { ok: false, error: '从这段文本里提不出番号（插件按口径一条都不报）' };
    out.ms = Date.now() - t0;
    return out;
  }

  try {
    const words = [...new Set([out.code, out.code.replace(/[-_ ]/g, '')])].filter(Boolean);
    let matches = [];
    let usedWord = '';
    for (const word of words) {
      matches = await site.searchPage(cfg.siteBase, word, SEARCH_TIMEOUT_MS);
      usedWord = word;
      if (matches.length) break;
    }
    out.search = {
      ok: true,
      word: usedWord,
      count: matches.length,
      top: matches.slice(0, 3).map((x) => `${x.title}（下载 ${x.downloads} 次）`),
    };
    if (matches.length) {
      const picked = await resolveTrack(cfg, out.code, { fresh: true });
      out.pick = picked
        ? { ok: true, lang: picked.lang, format: picked.format, title: picked.title, path: picked.path }
        : { ok: false, error: `前 ${MAX_DETAIL_PAGES} 个条目都没有可用的语言版本` };
    }
  } catch (e) {
    out.search = { ok: false, error: (e && e.message) || String(e), code: (e && e.code) || '' };
  }
  out.ms = Date.now() - t0;
  return out;
}

module.exports = { actions };
