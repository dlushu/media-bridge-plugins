'use strict';
/**
 * TMDB 多类型包入口（元数据 + 首页，见 docs/adr/0046）。
 *
 *   metadata/… → roles/metadata  注册 / 查信息 / 分集 / 搜索（TMDB 连接设置归它管）
 *   home/…     → roles/home      首页示例行（连接设置复用 metadata 那份，行参数各自存）
 *
 * 一个包一个进程、一份数据（包根 data/）。
 */
module.exports = {
  actions: {
    metadata: require('./roles/metadata').actions,
    home: require('./roles/home').actions,
  },
};
