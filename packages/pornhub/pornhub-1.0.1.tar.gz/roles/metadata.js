'use strict';
/**
 * Pornhub 元数据角色：注册域 `pornhub`（电影式），动作：
 *   register  → 域声明（名字/能力/外链模板）
 *   search    → {type, wd, page} → {rows}
 *   lookup    → {type, entryId} → {item}（主站详情优先，撞墙降级 embed + 搜索卡片缓存）
 *   season    → 电影式，如实回空
 *
 * 失败如实回 {ok:false, error:{code,message}}，不编数据。
 */
const ph = require('../lib/ph');
const { createCache } = require('../lib/cache');

const DOMAIN = 'pornhub';

const searchCache = createCache(); // `wd|page` → cards，10 分钟
const cardCache = createCache();   // viewkey → 卡片（标题/封面/时长/播放量），60 分钟，给 lookup 兜底

function rowOf(c) {
  return {
    entryId: c.viewkey,
    type: 'movie',
    title: c.title,
    originalTitle: '',
    year: '',
    premiereDate: '',
    searchTitle: c.title,
    overview: '',
    posterPath: ph.proxifyPoster(c.thumb || ''),
    backdropPath: '',
    communityRating: null,
    runtime: ph.durToMin(c.duration),
    genres: [],
  };
}

const fail = (e) => ({
  ok: false,
  error: { code: (e && e.code) || 'UPSTREAM', message: (e && e.message) || String(e) },
});

const actions = {
  /** 域声明 */
  async register() {
    return {
      ok: true,
      name: 'Pornhub',
      series: false,
      imageBase: '', // 海报要么是整串 URL，要么是面板图片中继的根相对地址（/api/emby/img/…），都原样透传
      links: [{ name: 'Pornhub', url: 'https://www.pornhub.com/view_video.php?viewkey={id}' }],
      language: 'en',
      capabilities: {
        series: false,
        fields: ['identity', 'titles', 'searchTitle', 'overview', 'images', 'runtime', 'search', 'genres', 'rating'],
      },
    };
  },

  /** 按名字搜索：{type, wd, page} → {rows} */
  async search(args = {}, ctx) {
    const wd = String(args.wd || '').trim();
    const page = Math.max(1, Number(args.page) || 1);
    if (!wd) return { ok: true, rows: [] };
    const ck = `${wd}|${page}`;
    try {
      const cards = await searchCache.dedup(ck, async () => {
        const hit = searchCache.get(ck);
        if (hit) return hit;
        const list = await ph.searchVideos(wd, page, Number(args.timeoutMs) || 25000);
        for (const c of list) cardCache.set(c.viewkey, c, 3600000);
        searchCache.set(ck, list, 600000);
        return list;
      });
      return { ok: true, rows: cards.map((c) => rowOf(c)) };
    } catch (e) {
      return fail(e);
    }
  },

  /** 取元数据：{type, entryId} → {item} */
  async lookup(args = {}, ctx) {
    const vk = ph.extractViewkey(args.entryId);
    if (!vk) return { ok: false, error: { code: 'BAD_ID', message: `认不出 viewkey：${String(args.entryId || '').slice(0, 40)}` } };
    const card = cardCache.get(vk);
    try {
      // 主站详情页（元数据最全）；撞墙/失败则降级 embed
      const d = await ph.fetchDetailPage(vk, Number(args.timeoutMs) || 25000).catch(() => null);
      let title = '', thumb = '', premiereDate = '', via = '';
      let genres = [], rating = null, views = null;
      if (d && !d.walled) {
        title = d.title; thumb = d.thumb; premiereDate = d.premiereDate || ''; via = 'page';
        genres = d.genres || []; rating = d.rating ?? null; views = d.views ?? null;
      }
      if (!title || !thumb) {
        const e = await ph.fetchEmbed(vk, Number(args.timeoutMs) || 20000).catch(() => null);
        if (e) {
          if (!title) title = e.title;
          if (!thumb) thumb = e.thumb;
          via = via || 'embed';
        }
      }
      if (!title && card) { title = card.title; via = via || 'card'; }
      if (!thumb && card) thumb = card.thumb || '';
      if (!title) {
        return { ok: false, error: { code: 'UPSTREAM', message: '取不到该视频的信息（可能被年龄墙拦截）' } };
      }
      const item = {
        entryId: vk,
        type: 'movie',
        title,
        originalTitle: '',
        year: (premiereDate || '').slice(0, 4),
        // 契约口径：premiereDate 回 ISO 串 YYYY-MM-DDT00:00:00.0000000Z
        premiereDate: premiereDate ? `${premiereDate}T00:00:00.0000000Z` : '',
        searchTitle: title,
        overview: views ? `播放量 ${Number(views).toLocaleString('en-US')}` : '',
        posterPath: ph.proxifyPoster(thumb),
        backdropPath: '',
        // 站内 rating 是好评百分比（89 = 89%），换到 Emby 的 10 分制
        communityRating: rating !== null ? Math.round(rating) / 10 : null,
        runtime: card ? ph.durToMin(card.duration) : null,
        genres,
      };
      return { ok: true, item, via };
    } catch (e) {
      return fail(e);
    }
  },

  /** 电影式：没有季集，如实回空 */
  async season(args = {}) {
    return { ok: true, item: { entryId: ph.extractViewkey(args.entryId), seasons: [] } };
  },

  /** 设置页后端挂在 home 角色上，这里转发（避免循环引用，懒加载） */
  async http(args = {}, ctx) {
    return require('./home').actions.http(args, ctx);
  },
};

module.exports = { actions, DOMAIN };
