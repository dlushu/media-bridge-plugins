"use strict";

/**
 * home 角色薄壳（CJS）：只把面板的动作名转发进 lib/service.mjs。
 *
 * 面板动作名 → service.mjs 导出名：rows→homeRows、run→homeRun。
 * 实现见 plugins/hongguo/PLAN.md §4.2。
 */

const bridge = require("../lib/bridge.js");

const actions = {
  rows: (args) => bridge.call("homeRows", args),
  run: (args) => bridge.call("homeRun", args),
};

module.exports = { actions };
