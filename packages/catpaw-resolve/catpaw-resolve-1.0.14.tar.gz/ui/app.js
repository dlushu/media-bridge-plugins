'use strict';
/**
 * 猫爪源-网盘自解析版设置页的前端。
 *
 * 所有请求都打到**面板的转发通道**：`/api/plugins/<类型>/<id>/api/**` ——
 * 面板把它转成动作 `http`，由插件的 `index.js` 处理（面板不解释内容）。
 *
 * ⚠️ 路径是**算出来的**，不写死类型与 id：页面自己的地址是
 * `/api/plugins/source/catpaw-resolve/ui/index.html`，把 `/ui/…` 之后切掉就得到通道前缀。
 */
const API = location.pathname.replace(/\/ui\/.*$/, '') + '/api';

const $ = (id) => document.getElementById(id);

async function call(path, { method = 'GET', body } = {}) {
  const res = await fetch(API + path, {
    method,
    headers: body ? { 'Content-Type': 'application/json' } : undefined,
    body: body ? JSON.stringify(body) : undefined,
  });
  let data = null;
  try {
    data = await res.json();
  } catch {
    throw new Error(`面板回的不是 JSON（HTTP ${res.status}）`);
  }
  if (!res.ok || data.ok === false) throw new Error((data && data.error) || `HTTP ${res.status}`);
  return data;
}

let msgTimer = null;
function say(text, bad = false) {
  const el = $('msg');
  el.textContent = text || '';
  el.style.color = bad ? 'var(--err)' : 'var(--accent)';
  if (msgTimer) clearTimeout(msgTimer);
  msgTimer = setTimeout(() => {
    el.textContent = '';
  }, 4000);
}

/** 面板与插件之间传的是 JSON，所以这里一律用 DOM 建节点，不拼 HTML 串 */
function el(tag, attrs = {}, ...kids) {
  const n = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs)) {
    if (k === 'class') n.className = v;
    else if (k === 'text') n.textContent = v;
    else if (k === 'onclick') n.addEventListener('click', v);
    else if (v !== null && v !== undefined && v !== false) n.setAttribute(k, String(v));
  }
  for (const k of kids) if (k) n.append(k);
  return n;
}

function fmtTime(ms) {
  if (!ms) return '—';
  const d = new Date(ms);
  const p = (n) => String(n).padStart(2, '0');
  return `${p(d.getMonth() + 1)}-${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}:${p(d.getSeconds())}`;
}

const STATUS_TEXT = { running: '运行中', starting: '启动中', stopping: '停止中', stopped: '已停止', error: '异常' };

function statusBadge(one) {
  const cls = one.status === 'running' ? 'ok' : one.status === 'error' ? 'err' : one.status === 'starting' ? 'warn' : '';
  return el('span', { class: 'badge ' + cls }, el('span', { class: 'dot ' + (one.status || '') }), STATUS_TEXT[one.status] || one.status || '—');
}

function instanceRow(one) {
  const ops = el('td', { class: 'ops' });
  const busy = (btn) => {
    btn.disabled = true;
    btn.textContent = '…';
  };
  const act = (op, label, cls) =>
    el('button', {
      class: 'btn mini ' + (cls || ''),
      text: label,
      title: op ? `对这个实例执行 ${op}` : label,
      onclick: async (e) => {
        busy(e.target);
        try {
          await call(`/instances/${encodeURIComponent(one.id)}/${op}`, { method: 'POST' });
          say(`${one.id} ${label}完成`);
        } catch (err) {
          say(`${one.id} ${label}失败：${err.message}`, true);
        }
        await load();
      },
    });

  if (one.mode === 'local') {
    if (one.status === 'running') ops.append(act('stop', '停止'), act('restart', '重启'));
    else ops.append(act('start', '启动', 'primary'));
    ops.append(act('update', '更新'));
  }
  ops.append(
    el('button', {
      class: 'btn mini danger',
      text: '删除',
      onclick: async (e) => {
        if (!window.confirm(`删除实例「${one.name || one.id}」？它下载的源包与运行数据会一起删掉。`)) return;
        busy(e.target);
        try {
          await call(`/instances/${encodeURIComponent(one.id)}`, { method: 'DELETE' });
          say(`已删除 ${one.id}`);
        } catch (err) {
          say(`删除失败：${err.message}`, true);
        }
        await load();
      },
    })
  );

  const nameTd = el('td');
  nameTd.append(
    el('div', { text: one.name || '(未命名)' }),
    el('div', { class: 'muted mono', style: 'font-size:12px', text: one.id })
  );

  const srcTd = el('td', { class: 'mono', style: 'font-size:12px;word-break:break-all', text: one.sourceUrl || '' });

  const statusTd = el('td');
  statusTd.append(statusBadge(one));
  if (one.error) statusTd.append(el('div', { class: 'err', style: 'margin-top:6px;max-width:420px', text: one.error }));

  return el('tr', {}, nameTd, srcTd, statusTd, ops);
}

/**
 * 实例表的"内容指纹"：id + 状态。轮询时指纹没变就整步跳过——
 * 每 2 秒拆表重建会把 .table-wrap 的横向滚动清零，触屏滑动途中重建还会把手势打断。
 */
let instSig = '';
function sigOf(list) {
  return list.map((x) => x.id + ':' + x.status).join('|');
}

/** 窄屏表格摊成卡片时，按表头给每行单元格补列名（移动端样式见 /sdk/plugin-ui.css） */
function labelCols(table) {
  const heads = Array.from(table.querySelectorAll('thead th')).map((t) => t.textContent.trim());
  for (const tr of table.querySelectorAll('tbody tr')) {
    Array.from(tr.children).forEach((td, i) => {
      if (heads[i]) td.setAttribute('data-label', heads[i]);
    });
  }
  return table;
}

function paintInstances(list) {
  const host = $('instHost');
  host.textContent = '';
  instSig = sigOf(list);
  if (!list.length) {
    host.append(el('div', { class: 'hint warn', text: '还没有实例。点右上角「添加实例」，填源包地址本地部署一个。' }));
    return;
  }
  const table = el('table');
  table.append(
    el(
      'thead',
      {},
      el(
        'tr',
        {},
        el('th', { text: '实例' }),
        el('th', { text: '源包' }),
        el('th', { text: '状态' }),
        el('th', { text: '' })
      )
    )
  );
  const body = el('tbody');
  for (const one of list) body.append(instanceRow(one));
  table.append(body);
  host.append(el('div', { class: 'table-wrap' }, labelCols(table)));
}

/**
 * 把已存的凭据**回显**到各张卡的输入框里（键名与 `/state` 的 `credentials` 一一对应）。
 * 只有输入框当前是空的才回填 —— 整页 `load()` 会在每次保存后被调用，
 * 无条件回填会把用户正在敲的内容冲掉。
 */
function paintCredentials(c) {
  const map = {
    quarkCookie: 'quarkCookie',
    ucCookie: 'ucCookie',
    ucToken: 'ucToken',
    ucUt: 'ucUt',
    pan115Cookie: 'pan115Cookie',
    baiduCookie: 'baiduCookie',
    xunleiUsername: 'xunleiUser',
    xunleiPassword: 'xunleiPass',
    aliToken: 'aliToken',
    aliRefreshToken: 'aliRefresh',
    tianyiCookie: 'tianyiCookie',
    tianyiAccount: 'tianyiAccount',
    tianyiPassword: 'tianyiPassword',
    pikpakUsername: 'pikpakUser',
    pikpakPassword: 'pikpakPass',
    pan123Auth: 'pan123Auth',
    pan123Account: 'pan123User',
    guangyaAccessToken: 'guangyaAccessToken',
    guangyaRefreshToken: 'guangyaRefreshToken',
    guangyaDeviceId: 'guangyaDeviceId',
  };
  for (const [key, id] of Object.entries(map)) {
    const el = $(id);
    if (el && !el.value) el.value = String((c && c[key]) || '');
  }
}

/** 已配 / 没配那句话 */
const has = (b, yes, no) => (b ? yes : no);

/* ---------------- 网盘服务列表：一家一行，状态直接亮在行上，配置收进模态框 ---------------- */

const ND_LIST = [
  { key: 'quark', label: '夸克' },
  { key: 'uc', label: 'UC' },
  { key: 'pan115', label: '115 网盘' },
  { key: 'baidu', label: '百度网盘' },
  { key: 'xunlei', label: '迅雷' },
  { key: 'ali', label: '阿里云盘' },
  { key: 'tianyi', label: '天翼云盘' },
  { key: 'pikpak', label: 'PikPak' },
  { key: 'pan123', label: '123 云盘' },
  { key: 'yidong', label: '移动云盘（139）' },
  { key: 'guangya', label: '光鸭云盘' },
];

function openNd(key) {
  for (const d of ND_LIST) $('ndForm-' + d.key).classList.add('hidden');
  $('ndForm-' + key).classList.remove('hidden');
  const def = ND_LIST.find((d) => d.key === key);
  $('ndTitle').textContent = (def ? def.label : key) + ' · 配置';
  $('ndModal').classList.remove('hidden');
}

/**
 * 行上那枚状态章 —— **只认真实检查结果**（GET /verify 的 driver.check）：
 *   没出结果      → 检查中…（灰）
 *   打通了        → 已登录（绿）
 *   打不通 + 没配 → 未登录（黄）
 *   打不通 + 已配 → 登录失效（红，hover 看真实报错）
 * `opts.anonOk`：这家没凭据也能用（移动云盘 / 123 的无限档），没配时不给警告色。
 */
function ndBadgeReal(key, configured, ch, opts) {
  const opt = opts || {};
  const b = $('ndBadge-' + key);
  if (!b) return;
  b.removeAttribute('title');
  if (!ch) {
    b.className = 'badge';
    b.textContent = '检查中…';
    return;
  }
  if (ch.ok) {
    b.className = 'badge ok';
    b.textContent = opt.okText || '已登录';
    return;
  }
  if (!configured) {
    b.className = 'badge ' + (opt.anonOk ? '' : 'warn');
    b.textContent = opt.noText || '未登录';
    return;
  }
  b.className = 'badge err';
  b.textContent = '登录失效';
  if (ch.error) b.title = ch.error;
}

/** 配置弹窗里那句状态：前半截说"配了什么"（本地零成本），后半截是**真实检查**结论 */
function stateLine(id, bits, ch) {
  const host = $(id);
  host.textContent = '';
  host.append(document.createTextNode(bits.filter(Boolean).join(' · ')));
  if (bits.length) host.append(document.createTextNode(' · '));
  const s = document.createElement('span');
  if (!ch) {
    s.textContent = '检查中…';
    s.className = 'muted';
  } else if (ch.ok) {
    s.textContent = `有效（${ch.ms} ms）`;
    s.style.color = 'var(--accent)';
  } else {
    s.textContent = ch.error || '不通';
    s.style.color = 'var(--err)';
  }
  host.append(s);
}

let ndRowsBuilt = false;
function paintNdRows() {
  if (ndRowsBuilt) return;
  ndRowsBuilt = true;
  const host = $('ndHost');
  host.textContent = '';
  for (const d of ND_LIST) {
    host.append(
      el(
        'tr',
        {},
        el('td', { text: d.label }),
        el('td', { class: 'muted', id: 'ndBands-' + d.key, text: '—' }),
        el('td', {}, el('span', { class: 'badge', id: 'ndBadge-' + d.key, text: '检查中…' })),
        el('td', { class: 'ops' }, el('button', { class: 'btn mini', text: '编辑', onclick: () => openNd(d.key) }))
      )
    );
  }
  /* 表头是静态 HTML，行是动态补进 tbody 的 —— 同样补一遍列名 */
  labelCols(host.closest('table'));
}

/** 每家网盘**几档线路**（后端 `/state` 的 `bands`）—— 如「2 档 · 原画 / 转码」 */
function paintNdBands(bands) {
  for (const d of ND_LIST) {
    const cell = $('ndBands-' + d.key);
    if (!cell) continue;
    const hit = (bands || []).find((x) => x.name === d.key);
    const list = (hit && hit.bands) || [];
    cell.textContent = list.length
      ? `${list.length} 档 · ${list.map((b) => `${b.label}${b.playVia === 'proxy' ? '（需中继）' : ''}`).join(' / ')}`
      : '—';
  }
}

/* 每家第二个参数 ch 是 GET /verify 的真实检查结果：undefined=还在检查，
 * {ok:true,ms}=打通，{ok:false,error}=打不通。徽章只认它，配置位只决定"没配/失效"的口径。 */

function paintQuark(q, ch) {
  const st = q || {};
  stateLine('quarkState', [has(st.hasCookie, '已配 Cookie', '还没配 Cookie')], ch);
  ndBadgeReal('quark', !!st.hasCookie, ch);
}

function paintUc(u, ch) {
  const st = u || {};
  const bits = [st.hasCookie ? '已配 Cookie' : '还没配 Cookie'];
  if (st.hasToken) bits.push('已配 Token');
  if (st.hasUt) bits.push('已配 ut');
  stateLine('ucState', bits, ch);
  ndBadgeReal('uc', !!st.hasCookie, ch);
}

function paintPan115(p, ch) {
  const st = p || {};
  stateLine('pan115State', [st.hasCookie ? '已配 Cookie' : '还没配 Cookie'], ch);
  ndBadgeReal('pan115', !!st.hasCookie, ch);
}

function paintBaidu(b, ch) {
  const st = b || {};
  stateLine('baiduState', [st.hasCookie ? '已配 Cookie' : '还没配 Cookie'], ch);
  ndBadgeReal('baidu', !!st.hasCookie, ch);
}

function paintXunlei(x, ch) {
  const st = x || {};
  const bits = [st.hasUsername ? '已配账号' : '还没配账号'];
  if (st.hasPassword) bits.push('已配密码');
  if (st.hasRefreshToken) bits.push('有续期令牌');
  stateLine('xunleiState', bits, ch);
  ndBadgeReal('xunlei', !!(st.hasRefreshToken || (st.hasUsername && st.hasPassword)), ch);
}

function paintAli(a, ch) {
  const st = a || {};
  const bits = [st.hasToken ? '已配访问令牌' : '还没配访问令牌'];
  if (st.hasRefreshToken) bits.push('有刷新令牌');
  stateLine('aliState', bits, ch);
  ndBadgeReal('ali', !!(st.hasToken || st.hasRefreshToken), ch);
}

function paintTianyi(t, ch) {
  const st = t || {};
  const bits = [st.hasCookie ? '已配 Cookie' : '还没配 Cookie'];
  if (st.hasAccount) bits.push('已配账号');
  stateLine('tianyiState', bits, ch);
  ndBadgeReal('tianyi', !!(st.hasCookie || (st.hasAccount && st.hasPassword)), ch);
}

/** PikPak 走登录态转存链路：没登录就没法解析 */
function paintPikpak(p, ch) {
  const st = p || {};
  const bits = [st.hasRefreshToken ? '已扫码登录（有续期令牌）' : st.hasUsername ? '已配账号（密码登录）' : '还没登录'];
  if (st.hasRefreshToken && st.hasUsername) bits.push('另存了账号');
  stateLine('pikpakState', bits, ch);
  ndBadgeReal('pikpak', !!(st.hasRefreshToken || (st.hasUsername && st.hasPassword)), ch);
}

function paintPan123(p, ch) {
  const st = p || {};
  const bits = [st.hasAuth ? '已配登录令牌' : '没配登录令牌'];
  if (st.hasAccount) bits.push('已配账号');
  stateLine('pan123State', bits, ch);
  /* 没配也不算错：「123无限」匿名就出，只有「P123」要令牌 → 不给红/黄，灰着说明 */
  ndBadgeReal('pan123', !!(st.hasAuth || (st.hasAccount && st.hasPassword)), ch, {
    anonOk: true,
    noText: '未配（P123 档要）',
  });
}

/** 移动云盘不要凭据：徽章说的是"分享接口通不通"（verify 会真打一发），不是登录 */
function paintYidong(_y, ch) {
  stateLine('yidongState', ['不需要凭据（全程匿名）'], ch);
  const b = $('ndBadge-yidong');
  if (b) {
    b.removeAttribute('title');
    if (!ch) {
      b.className = 'badge';
      b.textContent = '检查中…';
    } else if (ch.ok) {
      b.className = 'badge ok';
      b.textContent = '接口正常';
    } else {
      b.className = 'badge err';
      b.textContent = '接口不通';
      if (ch.error) b.title = ch.error;
    }
  }
}

/** 光鸭列目录匿名、取地址要转存自有盘 */
function paintGuangya(g, ch) {
  const st = g || {};
  const bits = [st.hasAccessToken ? '已配访问令牌' : st.hasRefreshToken ? '有刷新令牌（会自动续期）' : '还没登录'];
  if (st.hasDeviceId) bits.push('有设备号');
  stateLine('guangyaState', bits, ch);
  ndBadgeReal('guangya', !!(st.hasAccessToken || st.hasRefreshToken), ch);
}

/* ---------------- 真实验证（GET /verify）：打开页自动全量，保存后只重验这一家 ---------------- */

const ND_PAINTERS = {
  quark: paintQuark,
  uc: paintUc,
  pan115: paintPan115,
  baidu: paintBaidu,
  xunlei: paintXunlei,
  ali: paintAli,
  tianyi: paintTianyi,
  pikpak: paintPikpak,
  pan123: paintPan123,
  yidong: paintYidong,
  guangya: paintGuangya,
};

/** 最近一次 /state 的原件 + 最近一次各家验证结果；load() 重绘输入框时不能把徽章打回"检查中" */
let ndState = null;
let ndChecks = {};
/** 验证序号：连点保存时只认最后一发的回执，旧的回来直接丢（免得旧结论盖新结论） */
let verifySeq = 0;

function repaintNd(key) {
  const fn = ND_PAINTERS[key];
  if (fn) fn(ndState ? ndState[key] : {}, ndChecks[key]);
}

function applyStates(patch) {
  if (!ndState) ndState = {};
  Object.assign(ndState, patch);
  Object.keys(patch).forEach(repaintNd);
}

/** 真打一发包检查。keys 省略 = 十一家全验；给了 = 只验这几家（保存凭据后用）。 */
async function verifyKeys(keys) {
  const seq = ++verifySeq;
  const list = keys && keys.length ? keys : ND_LIST.map((d) => d.key);
  /* 先立刻翻成"检查中…"，不然旧结论会挂到新请求回来 */
  list.forEach((k) => {
    ndChecks[k] = undefined;
    repaintNd(k);
  });
  try {
    const qs = keys && keys.length ? '?provider=' + keys.map(encodeURIComponent).join(',') : '';
    const d = await call('/verify' + qs);
    if (seq !== verifySeq) return;
    Object.assign(ndChecks, d.checks || {});
    applyStates(d.states || {});
  } catch (e) {
    if (seq !== verifySeq) return;
    list.forEach((k) => {
      ndChecks[k] = { ok: false, error: '验证请求失败：' + e.message };
      repaintNd(k);
    });
  }
}

/** 凭据保存 / 清掉后的统一收尾：先落本地配置态，再真实验证这一家 */
async function savedNd(key, statePatch) {
  applyStates(statePatch);
  await verifyKeys([key]);
}

function paintAutoUpdate(au, results) {
  $('auEnabled').checked = !!au.enabled;
  $('auHours').value = au.hours || 12;
  const bits = [];
  if (au.running) bits.push('正在检查');
  if (au.lastRunAt) bits.push(`上次 ${fmtTime(au.lastRunAt)}（${au.lastReason || '-'}）`);
  if (au.nextRunAt) bits.push(`下次 ${fmtTime(au.nextRunAt)}`);
  $('auState').textContent = bits.join(' · ') || '还没跑过';

  const host = $('auResults');
  host.textContent = '';
  const rows = results || au.results || [];
  if (!rows.length) return;
  const table = el('table');
  table.append(
    el('thead', {}, el('tr', {}, el('th', { text: '实例' }), el('th', { text: '结果' }), el('th', { text: '说明' })))
  );
  const body = el('tbody');
  for (const r of rows) {
    body.append(
      el(
        'tr',
        {},
        el('td', { text: r.name || r.id }),
        el('td', {}, el('span', { class: 'badge ' + (r.ok ? 'ok' : 'err'), text: r.ok ? (r.changed ? '有新版' : '已最新') : '失败' })),
        el('td', { class: 'muted', text: r.error || (r.restarted ? '已重启' : '') })
      )
    );
  }
  table.append(body);
  host.append(el('div', { class: 'table-wrap' }, labelCols(table)));
}

/** 插件自己那份缓存的用量（两个旋钮是输入框，其余在这儿显示） */
function paintCache(settings, stats) {
  $('cacheTtl').value = settings.ttlMinutes !== undefined ? settings.ttlMinutes : 5;
  $('cacheMax').value = settings.maxMB !== undefined ? settings.maxMB : 64;
  const up = (stats.tables && stats.tables.upstream) || {};
  const mb = (n) => (Number(n || 0) / 1024 / 1024).toFixed(1);
  const cap = up.maxBytes > 0 ? `${mb(up.maxBytes)} MB` : '不限';
  const ttl = settings.ttlMinutes > 0 ? `${settings.ttlMinutes} 分钟` : '不缓存';
  $('cacheState').textContent = `已用 ${mb(stats.bytes)} MB / 上限 ${cap} · ${stats.rows || 0} 条 · 有效期 ${ttl}`;
}

/** 拉一次状态并整页重绘。`loud` 只在首次与手动刷新时为真 —— 轮询期间后端一直不通的话，
 *  不该每 2 秒嚷一次（见下面的 `pollInstances`）。 */
async function load(loud = false) {
  try {
    const d = await call('/state');
    paintInstances(d.instances || []);
    paintNdRows();
    paintNdBands(d.bands || []);
    /* 十一家配置态重绘；徽章结论沿用最近一次 /verify（ndChecks），不打回"检查中" */
    ndState = d;
    ND_LIST.forEach((x) => repaintNd(x.key));
    paintAutoUpdate(d.autoUpdate || {});
    paintCache(d.cacheSettings || {}, d.cache || {});
    paintCredentials(d.credentials || {});
  } catch (e) {
    if (loud) say('读不到状态：' + e.message, true);
  }
}

/**
 * 轮询只重画**实例表**：这一页另外几张卡里是输入框（自动更新的小时数、缓存的旋钮、夸克 Cookie），
 * 整页重绘会把用户正在敲的值冲掉。
 */
async function pollInstances() {
  try {
    const d = await call('/state');
    const list = d.instances || [];
    if (sigOf(list) === instSig) return;
    paintInstances(list);
  } catch {
    /* 轮询期间静默：一次读不到不代表坏了，下一轮再试 */
  }
}

/**
 * 实例状态每 2 秒重拉一次（与面板「插件 → 管理」页同一口径）。
 *
 * ⚠️ 这一步不能省：`/instances/:id/start` 是**异步**的 —— 后端 `startInstance()` 不等监听
 * 就返回，那一刻状态是 `starting`。只在动作后刷一次的话，「启动中」会一直挂着、看不到
 * 「运行中」（`running` 是几秒后由 runner 探到端口才置上的）。
 */
let timer = null;
function startPolling() {
  if (timer) return;
  timer = setInterval(async () => {
    if (!$('instHost')) {
      clearInterval(timer);
      timer = null;
      return;
    }
    await pollInstances();
  }, 2000);
}

/* ---------------- 事件接线 ---------------- */

$('reload').addEventListener('click', async () => {
  await load(true);
  await verifyKeys();
});

$('addInst').addEventListener('click', () => {
  $('instModal').classList.remove('hidden');
});
$('instClose').addEventListener('click', () => {
  $('instModal').classList.add('hidden');
});

$('ndClose').addEventListener('click', () => {
  $('ndModal').classList.add('hidden');
});

$('add').addEventListener('click', async (e) => {
  /* 只收本地部署：插件下载源包、自己起进程，端口由后端随机挑（不需要用户知道） */
  const body = {
    mode: 'local',
    name: $('name').value.trim(),
    url: $('url').value.trim(),
    port: 0,
  };
  if (!body.url) return say('请填源包地址', true);
  e.target.disabled = true;
  e.target.textContent = '添加中…';
  try {
    const d = await call('/instances', { method: 'POST', body });
    say(`已添加 ${d.instance.id}`);
    $('name').value = '';
    $('url').value = '';
    $('instModal').classList.add('hidden');
    await load();
  } catch (err) {
    say('添加失败：' + err.message, true);
  }
  e.target.disabled = false;
  e.target.textContent = '添加';
});

$('quarkSave').addEventListener('click', async (e) => {
  const cookie = $('quarkCookie').value.trim();
  if (!cookie) {
    say('没填内容：要清掉请点「清掉」', true);
    return;
  }
  e.target.disabled = true;
  try {
    const d = await call('/quark', { method: 'POST', body: { cookie } });
    await savedNd('quark', { quark: d.quark || {} });
    say('夸克 Cookie 已保存');
  } catch (err) {
    say('保存失败：' + err.message, true);
  }
  e.target.disabled = false;
});

$('quarkClear').addEventListener('click', async (e) => {
  if (!window.confirm('清掉插件里保存的夸克 Cookie？')) return;
  e.target.disabled = true;
  try {
    await savedNd('quark', { quark: (await call('/quark', { method: 'POST', body: { cookie: '' } })).quark || {} });
    $('quarkCookie').value = '';
    say('夸克 Cookie 已清掉');
  } catch (err) {
    say('清掉失败：' + err.message, true);
  }
  e.target.disabled = false;
});

$('ucSave').addEventListener('click', async (e) => {
  const body = {
    cookie: $('ucCookie').value.trim(),
    token: $('ucToken').value.trim(),
    ut: $('ucUt').value.trim(),
  };
  if (!body.cookie && !body.token && !body.ut) {
    say('没填内容：要清掉请点「清掉」', true);
    return;
  }
  e.target.disabled = true;
  try {
    const d = await call('/uc', { method: 'POST', body });
    await savedNd('uc', { uc: d.uc || {} });
    say('UC 登录态已保存');
  } catch (err) {
    say('保存失败：' + err.message, true);
  }
  e.target.disabled = false;
});

$('ucClear').addEventListener('click', async (e) => {
  if (!window.confirm('清掉插件里保存的 UC Cookie / Token / ut？')) return;
  e.target.disabled = true;
  try {
    const d = await call('/uc', { method: 'POST', body: { cookie: '', token: '', ut: '' } });
    await savedNd('uc', { uc: d.uc || {} });
    $('ucCookie').value = '';
    $('ucToken').value = '';
    $('ucUt').value = '';
    say('UC 登录态已清掉');
  } catch (err) {
    say('清掉失败：' + err.message, true);
  }
  e.target.disabled = false;
});

/* ---------------- 115：手动粘贴 + 扫码登录（通用 /qrcode 端点） ---------------- */

$('pan115Save').addEventListener('click', async (e) => {
  const cookie = $('pan115Cookie').value.trim();
  if (!cookie) {
    say('没填内容：要清掉请点「清掉」', true);
    return;
  }
  e.target.disabled = true;
  try {
    const d = await call('/pan115', { method: 'POST', body: { cookie } });
    await savedNd('pan115', { pan115: d.pan115 || {} });
    say('115 Cookie 已保存');
  } catch (err) {
    say('保存失败：' + err.message, true);
  }
  e.target.disabled = false;
});

$('pan115Clear').addEventListener('click', async (e) => {
  if (!window.confirm('清掉插件里保存的 115 Cookie？')) return;
  e.target.disabled = true;
  try {
    await savedNd('pan115', { pan115: (await call('/pan115', { method: 'POST', body: { cookie: '' } })).pan115 || {} });
    $('pan115Cookie').value = '';
    say('115 Cookie 已清掉');
  } catch (err) {
    say('清掉失败：' + err.message, true);
  }
  e.target.disabled = false;
});

/* ---------------- 百度：扫码登录 + 手动粘贴（都要含 BDUSS） ---------------- */

$('baiduSave').addEventListener('click', async (e) => {
  const cookie = $('baiduCookie').value.trim();
  if (!cookie) {
    say('没填内容：要清掉请点「清掉」', true);
    return;
  }
  e.target.disabled = true;
  try {
    const d = await call('/baidu', { method: 'POST', body: { cookie } });
    await savedNd('baidu', { baidu: d.baidu || {} });
    say('百度 Cookie 已保存');
  } catch (err) {
    say('保存失败：' + err.message, true);
  }
  e.target.disabled = false;
});

$('baiduClear').addEventListener('click', async (e) => {
  if (!window.confirm('清掉插件里保存的百度 Cookie？')) return;
  e.target.disabled = true;
  try {
    await savedNd('baidu', { baidu: (await call('/baidu', { method: 'POST', body: { cookie: '' } })).baidu || {} });
    $('baiduCookie').value = '';
    say('百度 Cookie 已清掉');
  } catch (err) {
    say('清掉失败：' + err.message, true);
  }
  e.target.disabled = false;
});

let qrTimer = null;
let qrSessionId = null;
let qrProvider = '115';
/** 轮询重入保护：百度那条 `channel/unicast` 是**长轮询**（能挂十几秒），
 *  不挡住的话 1.6s 的定时器会叠一堆在飞的请求。 */
let qrBusy = false;

/** provider → 页面上显示的名字（弹窗提示用） */
const QR_LABEL = { quark: '夸克', uc: 'UC', '115': '115', baidu: '百度', ali: '阿里云盘', pikpak: 'PikPak', guangya: '光鸭' };
/** provider → 弹窗里那句"拿什么扫"（各家的 App 不一样，别写死一句通用的） */
const QR_TIP = {
  quark: '用手机上的夸克 App 扫码，并在手机上确认登录。',
  uc: '用手机上的 UC 浏览器扫码，并在手机上确认登录。',
  '115': '用手机上的 115 App 扫码，并在手机上确认登录。',
  baidu: '用手机上的百度 App 扫码，并在手机上确认登录。',
  ali: '用手机上的阿里云盘 App 扫码，并在手机上确认登录。',
  pikpak: '用手机上的 PikPak App 扫码，并在手机上确认登录。',
  guangya: '用手机上的光鸭 App 扫码，并在手机上确认登录。',
};

function stopQrPoll() {
  if (qrTimer) {
    clearInterval(qrTimer);
    qrTimer = null;
  }
}

function closeQr() {
  stopQrPoll();
  qrSessionId = null;
  $('qrModal').classList.add('hidden');
}

/** 取一张新二维码并开始轮询（`qrProvider` 由点哪个按钮决定） */
async function qrFetch() {
  stopQrPoll();
  qrBusy = false;
  $('qrImg').removeAttribute('src');
  $('qrHint').textContent = '正在取二维码…';
  try {
    const d = await call(`/qrcode?provider=${encodeURIComponent(qrProvider)}`);
    qrSessionId = d.sessionId;
    if (d.image) $('qrImg').setAttribute('src', d.image);
    $('qrHint').textContent = d.message || (d.image ? `请用 ${QR_LABEL[qrProvider] || qrProvider} App 扫码` : '二维码没取到，点「刷新二维码」重试');
    /* 百度那条是长轮询（后端一发最多挂 15s），间隔给大一点，别叠请求 */
    qrTimer = setInterval(qrPoll, qrProvider === 'baidu' ? 3000 : 1600);
  } catch (err) {
    $('qrHint').textContent = '取二维码失败：' + err.message;
  }
}

async function qrPoll() {
  if (!qrSessionId) return stopQrPoll();
  if (qrBusy) return; // 上一发还挂着（百度那条是长轮询），别叠
  qrBusy = true;
  try {
    const d = await call(`/qrcode/status?provider=${encodeURIComponent(qrProvider)}&sessionId=${encodeURIComponent(qrSessionId)}`);
    if (d.status === 'scanned') {
      $('qrHint').textContent = d.message || '已扫码，请在手机上确认登录';
    } else if (d.status === 'confirmed') {
      closeQr();
      say(`${QR_LABEL[qrProvider] || qrProvider} 登录成功，凭据已保存`);
      /* 扫码 provider 用 '115' 这个名字，网盘服务列表的键是 pan115 */
      const ndKey = qrProvider === '115' ? 'pan115' : qrProvider;
      await load();
      await verifyKeys([ndKey]);
    } else if (d.status === 'expired' || d.status === 'failed') {
      stopQrPoll();
      $('qrHint').textContent = (d.status === 'expired' ? '二维码已过期' : '扫码失败：' + (d.message || '')) + '，点「刷新二维码」重来';
    }
  } catch (err) {
    $('qrHint').textContent = '轮询失败：' + err.message;
  }
  qrBusy = false;
}

/** 六个入口共用一个弹窗，点谁就把 `qrProvider` 设成谁 */
for (const [id, provider] of [
  ['quarkQr', 'quark'],
  ['ucQr', 'uc'],
  ['pan115Qr', '115'],
  ['baiduQr', 'baidu'],
  ['aliQr', 'ali'],
  ['pikpakQr', 'pikpak'],
  ['guangyaQr', 'guangya'],
]) {
  $(id).addEventListener('click', () => {
    qrProvider = provider;
    $('qrTitle').textContent = `${QR_LABEL[provider] || provider} 扫码登录`;
    $('qrTip').textContent = QR_TIP[provider] || QR_TIP['115'];
    $('qrModal').classList.remove('hidden');
    qrFetch();
  });
}
$('qrClose').addEventListener('click', closeQr);
$('qrRefresh').addEventListener('click', qrFetch);

/* ---------------- 迅雷：账号密码（走它自己的 OAuth 登录，没有 Cookie 这条路） ---------------- */

$('xunleiSave').addEventListener('click', async (e) => {
  const username = $('xunleiUser').value.trim();
  const password = $('xunleiPass').value.trim();
  if (!username && !password) {
    say('至少填账号或密码；要清掉请点「清掉」', true);
    return;
  }
  e.target.disabled = true;
  try {
    const body = {};
    if (username) body.username = username;
    if (password) body.password = password;
    const d = await call('/xunlei', { method: 'POST', body });
    await savedNd('xunlei', { xunlei: d.xunlei || {} });
    say('迅雷账号已保存');
  } catch (err) {
    say('保存失败：' + err.message, true);
  }
  e.target.disabled = false;
});

$('xunleiClear').addEventListener('click', async (e) => {
  if (!window.confirm('清掉插件里保存的迅雷账号与续期令牌？')) return;
  e.target.disabled = true;
  try {
    const d = await call('/xunlei', { method: 'POST', body: { username: '', password: '', refreshToken: '' } });
    await savedNd('xunlei', { xunlei: d.xunlei || {} });
    $('xunleiUser').value = '';
    $('xunleiPass').value = '';
    say('迅雷账号已清掉');
  } catch (err) {
    say('清掉失败：' + err.message, true);
  }
  e.target.disabled = false;
});

/* ---------------- 阿里云盘：OAuth 令牌（没有 Cookie 这条路） ---------------- */

$('aliSave').addEventListener('click', async (e) => {
  const token = $('aliToken').value.trim();
  const refreshToken = $('aliRefresh').value.trim();
  if (!token && !refreshToken) {
    say('至少填访问令牌或刷新令牌；要清掉请点「清掉」', true);
    return;
  }
  e.target.disabled = true;
  try {
    const body = {};
    if (token) body.token = token;
    if (refreshToken) body.refreshToken = refreshToken;
    const d = await call('/ali', { method: 'POST', body });
    await savedNd('ali', { ali: d.ali || {} });
    say('阿里云盘令牌已保存');
  } catch (err) {
    say('保存失败：' + err.message, true);
  }
  e.target.disabled = false;
});

$('aliClear').addEventListener('click', async (e) => {
  if (!window.confirm('清掉插件里保存的阿里云盘令牌？')) return;
  e.target.disabled = true;
  try {
    const d = await call('/ali', { method: 'POST', body: { token: '', refreshToken: '' } });
    await savedNd('ali', { ali: d.ali || {} });
    $('aliToken').value = '';
    $('aliRefresh').value = '';
    say('阿里云盘令牌已清掉');
  } catch (err) {
    say('清掉失败：' + err.message, true);
  }
  e.target.disabled = false;
});

/* ---------------- 天翼云盘：账号密码登录（driver 的 logbox 链路）或粘 Cookie ---------------- */

$('tianyiLogin').addEventListener('click', async (e) => {
  const account = $('tianyiAccount').value.trim();
  const password = $('tianyiPassword').value;
  if (!account || !password) {
    say('账号密码登录要两样都填', true);
    return;
  }
  e.target.disabled = true;
  e.target.textContent = '登录中…';
  try {
    const d = await call('/tianyi', { method: 'POST', body: { account, password } });
    await savedNd('tianyi', { tianyi: d.tianyi || {} });
    say(d.logged ? '天翼登录成功，Cookie 已保存' : '天翼登录态已更新');
  } catch (err) {
    say('天翼登录失败：' + err.message, true);
  }
  e.target.disabled = false;
  e.target.textContent = '账号密码登录';
});

$('tianyiSave').addEventListener('click', async (e) => {
  const cookie = $('tianyiCookie').value.trim();
  if (!cookie) {
    say('没填内容：要清掉请点「清掉」', true);
    return;
  }
  e.target.disabled = true;
  try {
    const d = await call('/tianyi', { method: 'POST', body: { cookie } });
    await savedNd('tianyi', { tianyi: d.tianyi || {} });
    say('天翼 Cookie 已保存');
  } catch (err) {
    say('保存失败：' + err.message, true);
  }
  e.target.disabled = false;
});

$('tianyiClear').addEventListener('click', async (e) => {
  if (!window.confirm('清掉插件里保存的天翼 Cookie 与账号密码？')) return;
  e.target.disabled = true;
  try {
    const d = await call('/tianyi', { method: 'POST', body: { clear: true } });
    await savedNd('tianyi', { tianyi: d.tianyi || {} });
    $('tianyiAccount').value = '';
    $('tianyiPassword').value = '';
    $('tianyiCookie').value = '';
    say('天翼登录态已清掉');
  } catch (err) {
    say('清掉失败：' + err.message, true);
  }
  e.target.disabled = false;
});

/* ---------------- PikPak：账号密码（扫码登录走通用 /qrcode 端点） ---------------- */

$('pikpakSave').addEventListener('click', async (e) => {
  const username = $('pikpakUser').value.trim();
  const password = $('pikpakPass').value.trim();
  if (!username && !password) {
    say('没填内容：要清掉请点「清掉」', true);
    return;
  }
  e.target.disabled = true;
  try {
    const body = {};
    if (username) body.username = username;
    if (password) body.password = password;
    const d = await call('/pikpak', { method: 'POST', body });
    await savedNd('pikpak', { pikpak: d.pikpak || {} });
    say('PikPak 账号密码已保存（解析时会用它登录）');
  } catch (err) {
    say('保存失败：' + err.message, true);
  }
  e.target.disabled = false;
});

$('pikpakClear').addEventListener('click', async (e) => {
  if (!window.confirm('清掉插件里保存的 PikPak 账号信息？')) return;
  e.target.disabled = true;
  try {
    const d = await call('/pikpak', { method: 'POST', body: { username: '', password: '', refreshToken: '' } });
    await savedNd('pikpak', { pikpak: d.pikpak || {} });
    $('pikpakUser').value = '';
    $('pikpakPass').value = '';
    say('PikPak 已清掉');
  } catch (err) {
    say('清掉失败：' + err.message, true);
  }
  e.target.disabled = false;
});

/* ---------------- 123 云盘：JWT（`123无限` 匿名就出，P123 档才要） ---------------- */

$('pan123Save').addEventListener('click', async (e) => {
  const auth = $('pan123Auth').value.trim();
  const account = $('pan123User').value.trim();
  if (!auth && !account) {
    say('至少填登录令牌或账号；要清掉请点「清掉」', true);
    return;
  }
  e.target.disabled = true;
  try {
    const body = {};
    if (auth) body.auth = auth;
    if (account) body.account = account;
    const d = await call('/pan123', { method: 'POST', body });
    await savedNd('pan123', { pan123: d.pan123 || {} });
    say('123 云盘凭据已保存');
  } catch (err) {
    say('保存失败：' + err.message, true);
  }
  e.target.disabled = false;
});

$('pan123Clear').addEventListener('click', async (e) => {
  if (!window.confirm('清掉插件里保存的 123 云盘凭据？（清了「123无限」那条档位照旧能用）')) return;
  e.target.disabled = true;
  try {
    const d = await call('/pan123', { method: 'POST', body: { auth: '', account: '', password: '' } });
    await savedNd('pan123', { pan123: d.pan123 || {} });
    $('pan123Auth').value = '';
    $('pan123User').value = '';
    say('123 云盘凭据已清掉');
  } catch (err) {
    say('清掉失败：' + err.message, true);
  }
  e.target.disabled = false;
});

/* 移动云盘没有凭据操作：它的"接口通不通"随打开页面 /verify 全量检查自动刷新。 */

/* ---------------- 光鸭云盘：设备码扫码登录 + 手动粘贴令牌 ---------------- */

$('guangyaSave').addEventListener('click', async (e) => {
  const body = {};
  const accessToken = $('guangyaAccessToken').value.trim();
  const refreshToken = $('guangyaRefreshToken').value.trim();
  const deviceId = $('guangyaDeviceId').value.trim();
  if (!accessToken && !refreshToken && !deviceId) {
    say('没填内容：要清掉请点「清掉」', true);
    return;
  }
  if (accessToken) body.accessToken = accessToken;
  if (refreshToken) body.refreshToken = refreshToken;
  if (deviceId) body.deviceId = deviceId;
  e.target.disabled = true;
  try {
    const d = await call('/guangya', { method: 'POST', body });
    await savedNd('guangya', { guangya: d.guangya || {} });
    say('光鸭令牌已保存');
  } catch (err) {
    say('保存失败：' + err.message, true);
  }
  e.target.disabled = false;
});

$('guangyaClear').addEventListener('click', async (e) => {
  if (!window.confirm('清掉插件里保存的光鸭令牌与设备号？（清了「分享列目录」仍可用，但取播放地址会报未登录）')) return;
  e.target.disabled = true;
  try {
    const d = await call('/guangya', { method: 'POST', body: { clear: true } });
    await savedNd('guangya', { guangya: d.guangya || {} });
    $('guangyaAccessToken').value = '';
    $('guangyaRefreshToken').value = '';
    $('guangyaDeviceId').value = '';
    say('光鸭登录态已清掉');
  } catch (err) {
    say('清掉失败：' + err.message, true);
  }
  e.target.disabled = false;
});

$('auSave').addEventListener('click', async (e) => {
  e.target.disabled = true;
  try {
    await call('/autoupdate', { method: 'POST', body: { autoUpdate: $('auEnabled').checked, autoUpdateHours: Number($('auHours').value) || 12 } });
    say('自动更新设置已保存');
  } catch (err) {
    say('保存失败：' + err.message, true);
  }
  e.target.disabled = false;
  await load();
});

$('auRun').addEventListener('click', async (e) => {
  e.target.disabled = true;
  e.target.textContent = '检查中…';
  try {
    const d = await call('/autoupdate/run', { method: 'POST' });
    paintAutoUpdate(d.autoUpdate || {}, d.results || []);
    say('检查完成');
  } catch (err) {
    say('检查失败：' + err.message, true);
  }
  e.target.disabled = false;
  e.target.textContent = '立即检查';
  await load();
});

$('cacheSave').addEventListener('click', async (e) => {
  e.target.disabled = true;
  try {
    const d = await call('/cache/settings', {
      method: 'POST',
      body: { cacheTtlMinutes: Number($('cacheTtl').value), cacheMaxMB: Number($('cacheMax').value) },
    });
    paintCache(d.cacheSettings || {}, d.cache || {});
    say('缓存设置已保存');
  } catch (err) {
    say('保存失败：' + err.message, true);
  }
  e.target.disabled = false;
  await load();
});

$('cacheReload').addEventListener('click', async () => {
  try {
    const d = await call('/cache');
    paintCache(d.cacheSettings || {}, d.cache || {});
    say('缓存用量已刷新');
  } catch (err) {
    say('刷新失败：' + err.message, true);
  }
});

$('cacheClear').addEventListener('click', async (e) => {
  if (!window.confirm('清空缓存？下次取数会重新打上游。')) return;
  e.target.disabled = true;
  try {
    const d = await call('/cache/clear', { method: 'POST' });
    paintCache(d.cacheSettings || {}, d.cache || {});
    say('缓存已清空');
  } catch (err) {
    say('清空失败：' + err.message, true);
  }
  e.target.disabled = false;
  await load();
});

/* 打开页面：读配置 + 十一家真实验证（并行跑，一家超时不拖其余） */
load(true);
verifyKeys();
startPolling();