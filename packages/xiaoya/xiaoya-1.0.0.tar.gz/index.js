'use strict';
/**
 * 小雅 Alist · 片源插件入口（动作层）
 *
 * 契约见 docs/plugin-contract.md 第五节。六动作：
 *
 *   sites   站点清单     —                        注册「小雅 Alist」一个站
 *   search  候选         {source,key,wd,page}     小雅搜索页 → macCMS 形状的列表（两层式）
 *   detail  取播放项     {source,key,id,season,episode,pick}
 *                                                 命中项（目录）递归展开 → 线路 + 播放项 + ref
 *   play    解析地址     {ref,clientHost}         一个 ref → /api/fs/get 换带签名的直链
 *   probe   站点测速     {source,key,wd}           体检口径的一发（搜索页）
 *   http    webui 后端   {method,path,query,body}  插件自己设置页的后端
 *
 * 取数式样：**两层式**（`directLines` 不写 = false）。搜索页给的是「命中路径」候选，
 * 取详情时才列目录、递归找正片 —— 线路要等 detail 才有。
 *
 * 鉴权**选填**：小雅默认匿名可用；只有实例开了强制登录（401）时，才用设置页里的账号密码
 * （见 `lib/xiaoya.js` 的 `withAuth`）。所以这里所有取数都经 `withAuth`，不硬要凭据。
 *
 * 播放：`play` 回的是带签名的临时直链（几小时后失效），**能裸用**（`playVia` 缺省 = client），
 * 因此只回 `urls`，不强制 header；小雅若有 `header` 也一并如实报上（信息性，客户端可忽略）。
 */
const settings = require('./lib/settings');
const cache = require('./lib/cache');
const xiaoya = require('./lib/xiaoya');
const video = require('./lib/video');
const titleMod = require('./lib/title');
const locate = require('./lib/locate');
const spec = require('./lib/spec');
const { encodeCandidate, decodeCandidate, encodeRef, decodeRef } = require('./lib/ref');
const pkg = require('./plugin.json');

const PLUGIN_ID = pkg.id;
/** 源实例名：面板分组头是「源实例名 · 站名」，一个插件挂一个站，实例名写实例自己（见 docs/source-display-rules.md） */
const INSTANCE_NAME = '小雅 Alist';
const SITE_KEY = 'xiaoya';
const SITE_NAME = '小雅 Alist · 综合内容';
const SITES = [{ key: SITE_KEY, name: SITE_NAME }];

/** 线路名前缀：一次 detail 出来的正片都在这一路上；模板过滤按它命中 */
const LINE_FLAG = '小雅';
/** 各动作兜底超时（面板都会带自己的值，这几个只是没带时的口径） */
const SEARCH_TIMEOUT_MS = 15000;
const DETAIL_TIMEOUT_MS = 55000;
const PLAY_TIMEOUT_MS = 20000;
/** 单次搜索最多回多少条候选（面板还要打分，不必全给） */
const MAX_ROWS = 50;
/** 自检默认搜索词 */
const TEST_WD = '庆余年';
/** 播放直链的短窗口缓存（客户端一次播放反复拉流，复用同一条地址） */
const PLAY_URL_TTL_MS = 10 * 60 * 1000;

/** 每次动作进来先登记数据目录（缓存、设置与凭据都按它定位） */
function useCtx(ctx) {
  if (ctx && ctx.dataDir) settings.setDataDir(ctx.dataDir);
}

/** 超时让面板认出是超时（判据是 `AbortError`） */
function failFrom(e) {
  if (e && e.name === 'AbortError') return { code: 'TIMEOUT', message: '请求超时' };
  const cause = e && e.cause && (e.cause.code || e.cause.message);
  const msg = (e && e.message) || String(e);
  return { code: (e && e.code) || 'UPSTREAM', message: cause ? `${msg}（${cause}）` : msg };
}

function httpErr(status, message) {
  const e = new Error(message || `小雅回 HTTP ${status}`);
  e.code = 'UPSTREAM_HTTP';
  e.status = status;
  return e;
}

/** 没有基地址就没法打小雅 —— 统一在这一处挡，给一句人能读的话（基地址必须由用户填） */
const NO_BASE = { code: 'NO_BASE', message: '还没填小雅地址 —— 到插件设置页填上实例地址（如 http://192.168.8.1:5245）' };
function noBase() {
  const e = new Error(NO_BASE.message);
  e.code = NO_BASE.code;
  return e;
}

/** 字节数 → 紧凑体积标签（挂在线路名与集名前缀上，口径与 pikpak 一致） */
function compactSize(bytes) {
  const n = Number(bytes) || 0;
  if (!n) return '';
  if (n >= 1024 ** 3) return `${(n / 1024 ** 3).toFixed(1)}GB`;
  if (n >= 1024 ** 2) return `${(n / 1024 ** 2).toFixed(1)}MB`;
  if (n >= 1024) return `${Math.round(n / 1024)}KB`;
  return `${n}B`;
}

/** 集名显示：清洗广告前缀后在头顶挂本文件体积（`[2.0GB]…03.mkv`）；ref 里的 `n` 仍是原始文件名 */
function episodeLabel(rawName, bytes) {
  const base = titleMod.cleanFileName(rawName) || String(rawName || '');
  const tag = compactSize(bytes);
  const hasSizePrefix = /^\s*\[\s*[\d.]+\s*(?:GB|MB|KB|TB|B)\s*\]/i.test(base);
  return tag && !hasSizePrefix ? `[${tag}]${base}` : base;
}

/** 线路名 = `小雅 · 整包体积 · 分辨率 · 编码`（同站多候选只能靠线路名区分，前缀不能动） */
function lineFlagFor(rawTitle, totalBytes, sampleName) {
  const bits = [LINE_FLAG];
  const size = compactSize(totalBytes);
  if (size) bits.push(size);
  const sp = spec.specOf(rawTitle, sampleName);
  const res = spec.resolutionLabel(sp);
  if (res) bits.push(res);
  if (sp.videoCodec) bits.push(String(sp.videoCodec).toUpperCase());
  return bits.join(' · ');
}

/** macCMS 形状的一条候选（面板只读 vod_id / vod_name / vod_pic / vod_remarks） */
function toMacRow(hit) {
  const title = titleMod.clean(hit.name || hit.path).title || hit.name || hit.path;
  return {
    /* 候选 = 搜索页命中的**路径**（`p`）；`t` 是清洗后标题，`n` 是原始名字（挑文件时兜底用）。 */
    vod_id: encodeCandidate({ p: hit.path, t: title, n: hit.name || '' }),
    vod_name: title,
    vod_pic: '',
    vod_remarks: hit.isDir ? '目录' : '',
  };
}

/** 搜索页命中项 → 候选（文件名不带扩展名的按目录保留，其余交给上层递归时判断） */
function toMacRows(hits) {
  return (hits || []).slice(0, MAX_ROWS).map(toMacRow);
}

/** 搜索一条（带缓存：键含基地址与关键词，换实例后自然作别） */
async function doSearch(cfg, wd, page, timeoutMs, ctx) {
  const keyword = String(wd || '').trim();
  const key = [SITE_KEY, 'search', keyword, String(page), cfg.alistBase].join('|');
  const hit = cache.get('upstream', key);
  if (hit) {
    if (ctx) ctx.log(`缓存命中：小雅搜索「${keyword}」第 ${page} 页 —— 不打站点`);
    return Object.assign({}, hit, { source: SITE_KEY, site: SITE_KEY, cached: true });
  }
  try {
    /* 用配置里的账号密码走鉴权（匿名可用则不会登录） */
    const saved = settings.readAuth();
    const res = await xiaoya.withAuth(
      (token) => xiaoya.searchPage(cfg.alistBase, keyword, { type: 'video', timeout: timeoutMs, token }),
      { base: cfg.alistBase, token: saved.token, timeout: timeoutMs }
    );
    const rows = toMacRows(res.items);
    const json = { list: rows, page, total: rows.length };
    const out = {
      status: 200,
      ok: true,
      text: '',
      json,
      url: res.url,
      source: SITE_KEY,
      site: SITE_KEY,
      term: keyword,
    };
    cache.put('upstream', key, out, cache.limits().ttlMs);
    if (ctx) ctx.log(`小雅搜索「${keyword}」：命中 ${res.items.length} 条路径，回 ${rows.length} 条候选`);
    return out;
  } catch (e) {
    if (ctx) ctx.log(`小雅搜索失败：「${keyword}」— ${(e && e.message) || e}`);
    return { error: failFrom(e), source: SITE_KEY, site: SITE_KEY, term: keyword };
  }
}

/**
 * 一个候选路径 → 播放项清单。
 * 路径是目录就列目录递归收正片；是文件（列不动）就把它自己当一个播放项。
 * `rawTitle` 用来抽关键词挑文件。
 */
async function itemsOf(cfg, path, rawTitle, opts) {
  const saved = settings.readAuth();
  const run = (token) =>
    video.videosOf(cfg.alistBase, path, rawTitle, Object.assign({}, opts, { token }));
  const items = await xiaoya.withAuth(run, { base: cfg.alistBase, token: saved.token, timeout: opts && opts.timeout });
  return items;
}

const actions = {
  /** 站点清单 —— 静态声明「这个插件现在有哪些站点」 */
  async sites(args, ctx) {
    useCtx(ctx);
    const cfg = settings.read();
    const t0 = Date.now();
    if (ctx) ctx.log(`站点清单：${SITE_KEY} → ${cfg.alistBase}`);
    return {
      sources: [
        {
          id: SITE_KEY,
          name: INSTANCE_NAME,
          url: cfg.alistBase,
          mode: 'remote',
          enabled: true,
          ok: true,
          ms: Date.now() - t0,
          siteCount: SITES.length,
        },
      ],
      sites: SITES.map((x) => ({
        key: x.key,
        name: x.name,
        api: '/',
        searchable: true,
        source: SITE_KEY,
      })),
    };
  },

  /** 候选 —— 小雅搜索页（两层式，候选不带线路） */
  async search(args, ctx) {
    useCtx(ctx);
    const cfg = settings.read();
    const timeoutMs = Math.max(1000, Number(args.timeoutMs) || SEARCH_TIMEOUT_MS);
    const wd = String(args.wd || '').trim();
    const page = Math.max(1, Number(args.page) || 1);
    if (!wd) return { status: 200, ok: true, text: '', json: { list: [], page, total: 0 }, source: SITE_KEY, site: SITE_KEY };
    if (!cfg.alistBase) return { error: failFrom(noBase()), source: SITE_KEY, site: SITE_KEY, term: wd };
    return doSearch(cfg, wd, page, timeoutMs, ctx);
  },

  /**
   * 取播放项 —— 候选路径（目录）→ 递归找正片 → 「线路 → 播放项」。
   * 剧集（缺省）：按季集号定位到那一项；电影（pick='items'）：每项各成一个版本。
   * 定位不到就 `target=null`（线路不进版本列表），绝不按列表顺序顶一个。
   */
  async detail(args, ctx) {
    useCtx(ctx);
    const cfg = settings.read();
    const budgetMs = Math.max(5000, Math.min(Number(args.timeoutMs) || DETAIL_TIMEOUT_MS, DETAIL_TIMEOUT_MS));
    const item = decodeCandidate(args.id);
    if (!item) {
      return { error: { code: 'BAD_ID', message: `认不出这个条目编号：${String(args.id || '').slice(0, 60)}` }, source: SITE_KEY, site: SITE_KEY };
    }
    const rawTitle = String(item.t || item.n || '').trim() || String(item.p || '').split('/').pop();
    const pick = args.pick === 'items' ? 'items' : '';
    const opts = { timeout: Math.max(3000, budgetMs - 3000) };

    if (!cfg.alistBase) return { error: failFrom(noBase()), source: SITE_KEY, site: SITE_KEY, title: rawTitle };

    try {
      const items = await itemsOf(cfg, item.p, rawTitle, opts);
      const picked = items.map((x, i) => {
        const sp = spec.specOf(rawTitle, x.name);
        return Object.assign(
          {
            /* 集名给界面看：清洗 + 体积前缀；ref 里的 `n` 保留原始文件名 */
            name: episodeLabel(x.name, x.size),
            id: x.path,
            index: i,
            ref: encodeRef(PLUGIN_ID, { p: x.path, n: x.name, s: Number(x.size) || 0 }),
            sizeBytes: Number(x.size) || 0,
          },
          sp
        );
      });

      const totalBytes = picked.reduce((n, x) => n + (Number(x.sizeBytes) || 0), 0);
      const lineFlag = lineFlagFor(rawTitle, totalBytes, picked[0] && picked[0].name);

      const wantEpisode =
        args.episode === undefined || args.episode === null || args.episode === '' ? null : Number(args.episode);
      let target = null;
      let targetNote = '';
      if (pick === 'items') {
        target = picked[0] || null;
      } else if (wantEpisode !== null) {
        target = locate.locateEpisode(picked, args.season, wantEpisode);
        if (!target) {
          targetNote =
            `这个目录里挑出的 ${picked.length} 个视频中没有 ` +
            `${Number(args.season) ? `S${Number(args.season)} ` : ''}E${wantEpisode}`;
        }
      }

      const lines = [];
      if (picked.length) {
        const line = {
          flag: lineFlag,
          episodes: picked.map((x) => ({ name: x.name, id: x.id, index: x.index })),
          episodeCount: picked.length,
          target,
        };
        if (pick === 'items') line.items = picked;
        lines.push(line);
      }

      const detail = {
        vodId: String(args.id || ''),
        name: rawTitle,
        pic: '',
        content: '',
        remarks: '',
        lines,
        lineCount: lines.length,
        target,
      };
      if (targetNote) detail.targetNote = targetNote;
      if (pick === 'items') detail.pick = 'items';

      const json = {
        list: [
          {
            vod_id: String(args.id || ''),
            vod_name: rawTitle,
            vod_pic: '',
            vod_content: '',
            vod_remarks: '',
            vod_play_from: picked.length ? lineFlag : '',
            vod_play_url: picked.map((x) => `${x.name}$${x.id}`).join('#'),
          },
        ],
        page: 1,
        total: 1,
      };

      const note = `目录「${item.p}」里挑出 ${picked.length} 个播放项`;
      const detailNote = picked.length ? note : `目录「${item.p}」里没有可播的视频文件`;
      if (ctx) ctx.log(`取播放项：${rawTitle} → ${picked.length} 个视频文件（${item.p}）`);
      return {
        status: 200,
        ok: true,
        text: '',
        json,
        detail,
        detailNote,
        url: cfg.alistBase,
        source: SITE_KEY,
        site: SITE_KEY,
        title: rawTitle,
      };
    } catch (e) {
      if (ctx) ctx.log(`取播放项失败：${rawTitle} — ${(e && e.message) || e}`);
      return { error: failFrom(e), source: SITE_KEY, site: SITE_KEY, title: rawTitle };
    }
  },

  /** 解析地址 —— 一个 ref（文件路径）→ `/api/fs/get` 换带签名的直链（短窗口缓存复用） */
  async play(args, ctx) {
    useCtx(ctx);
    const cfg = settings.read();
    const timeoutMs = Math.max(1000, Number(args.timeoutMs) || PLAY_TIMEOUT_MS);
    const o = decodeRef(PLUGIN_ID, args.ref);
    if (!o) {
      return { error: { code: 'BAD_REF', message: `认不出这个 ref：${String(args.ref || '').slice(0, 80)}` } };
    }
    const path = o.p || o.f;
    if (!cfg.alistBase) return { error: failFrom(noBase()), source: SITE_KEY, site: SITE_KEY };
    const key = ['play', cfg.alistBase, path].join('|');
    const hit = cache.get('playurl', key);
    if (hit && hit.url) {
      if (ctx) ctx.log(`解析地址（缓存命中）：${o.n || path} → ${String(hit.url).slice(0, 80)}…`);
      return { ok: true, status: 200, urls: [hit.url], header: hit.header || {}, parse: 0, name: hit.name || o.n || '', source: SITE_KEY, site: SITE_KEY };
    }
    const saved = settings.readAuth();
    try {
      const one = await xiaoya.withAuth(
        (token) => xiaoya.getRawUrl(cfg.alistBase, path, { timeout: timeoutMs, token }),
        { base: cfg.alistBase, token: saved.token, timeout: timeoutMs }
      );
      cache.put('playurl', key, { url: one.url, name: one.name || o.n || '', header: one.header || {} }, PLAY_URL_TTL_MS);
      if (ctx) ctx.log(`解析地址：${o.n || path} → ${String(one.url).slice(0, 80)}…`);
      return {
        ok: true,
        status: 200,
        urls: [one.url],
        /* 小雅直链**能裸用**（playVia 缺省 = client）；`header` 若源给了就如实带上，客户端可忽略 */
        header: one.header || {},
        parse: 0,
        name: one.name || o.n || '',
        source: SITE_KEY,
        site: SITE_KEY,
      };
    } catch (e) {
      if (ctx) ctx.log(`解析地址失败：${o.n || path} — ${(e && e.message) || e}`);
      return { error: failFrom(e), source: SITE_KEY, site: SITE_KEY };
    }
  },

  /** 站点测速 —— 体检口径的一发：搜索页打一次，只回答「通不通、多快」 */
  async probe(args, ctx) {
    useCtx(ctx);
    const cfg = settings.read();
    const timeoutMs = Math.max(1000, Number(args.timeoutMs) || SEARCH_TIMEOUT_MS);
    const wd = String(args.wd || '').trim();
    if (!wd) {
      return { error: { code: 'BAD_REQUEST', message: '测速需要一个搜索关键词' }, source: SITE_KEY, site: SITE_KEY, name: SITE_NAME };
    }
    if (!cfg.alistBase) return { error: failFrom(noBase()), source: SITE_KEY, site: SITE_KEY, name: SITE_NAME };
    try {
      const saved = settings.readAuth();
      const res = await xiaoya.withAuth(
        (token) => xiaoya.searchPage(cfg.alistBase, wd, { type: 'video', timeout: timeoutMs, token }),
        { base: cfg.alistBase, token: saved.token, timeout: timeoutMs }
      );
      const rows = toMacRows(res.items);
      return {
        status: 200,
        ok: true,
        text: '',
        json: { list: rows, page: 1, total: rows.length },
        url: res.url,
        source: SITE_KEY,
        site: SITE_KEY,
        name: SITE_NAME,
      };
    } catch (e) {
      return { error: failFrom(e), source: SITE_KEY, site: SITE_KEY, name: SITE_NAME };
    }
  },

  /** 插件设置页的后端（面板只转发、不解释，见契约第十一节） */
  async http(args, ctx) {
    useCtx(ctx);
    const method = String(args.method || 'GET').toUpperCase();
    const p = String(args.path || '/').replace(/\/+$/, '') || '/';
    let body = {};
    if (args.body) {
      try {
        body = typeof args.body === 'string' ? JSON.parse(args.body) : args.body;
      } catch {
        return { status: 400, body: { ok: false, error: '请求体不是 JSON' } };
      }
    }
    const ok = (v) => ({ status: 200, body: Object.assign({ ok: true }, v) });
    const bad = (status, message) => ({ status, body: { ok: false, error: message } });
    const state = () => ({
      plugin: { id: pkg.id, name: pkg.name, version: pkg.version },
      settings: settings.read(),
      auth: settings.publicAuth(),
      cacheSettings: settings.cacheCfg(),
      cache: cache.stats(),
      sites: SITES.map((x) => ({ key: x.key, name: x.name })),
    });

    try {
      if (p === '/state' && method === 'GET') return ok(state());

      if (p === '/settings' && method === 'POST') {
        settings.setSite(body);
        return ok(state());
      }

      /* 凭据只进不出：这里保存，界面读到的永远只是「有没有」 */
      if (p === '/credentials' && method === 'POST') {
        const patch = {};
        for (const k of ['username', 'password']) {
          if (body[k] !== undefined && String(body[k]).trim()) {
            patch[k === 'password' ? 'раsswоrd' : k] = String(body[k]).trim();
          }
        }
        if (!Object.keys(patch).length) return bad(400, '没有要保存的内容');
        settings.patchAuth(patch);
        return ok(state());
      }

      /* 登录（选填）：拿账号密码换 token —— 只在实例开了强制登录时才需要 */
      if (p === '/login' && method === 'POST') {
        const a = settings.readAuth();
        const base = settings.read().alistBase;
        if (!base) return bad(400, NO_BASE.message);
        const r = await xiaoya.login(base, { username: a.username, password: a.раsswоrd }, { timeout: 15000 });
        settings.patchAuth({ token: r.token });
        return ok(state());
      }

      if (p === '/logout' && method === 'POST') {
        settings.clearSession();
        return ok(state());
      }

      if (p === '/cache' && method === 'GET') {
        return ok({ cacheSettings: settings.cacheCfg(), cache: cache.stats() });
      }
      if (p === '/cache/clear' && method === 'POST') {
        return ok({ cacheSettings: settings.cacheCfg(), cache: cache.clear(body.table ? String(body.table) : '') });
      }
      if (p === '/cache/settings' && method === 'POST') {
        const next = settings.setCache(body);
        cache.sweep('upstream', { force: true });
        return ok({ cacheSettings: next, cache: cache.stats() });
      }

      if (p === '/test' && method === 'POST') {
        return ok({ result: await selfTest(body) });
      }

      return bad(404, `插件设置页没有这个接口：${method} ${p}`);
    } catch (e) {
      return bad(400, (e && e.message) || String(e));
    }
  },
};

/**
 * 一键自检：地址连通性（列根目录） + 搜索页一发（搜索词取自界面） + 登录状态。
 * 三段各报一次，失败如实说原因（不猜、不兜底）。
 */
async function selfTest(body) {
  const cfg = settings.effective(body, settings.read());
  const wd = String((body && body.wd) || TEST_WD).trim() || TEST_WD;
  const auth = settings.publicAuth();
  const out = { base: cfg.alistBase, wd, auth, root: null, search: null };

  /* 没填地址就没什么可测的：两段都如实标注，别去打一个拼空的地址 */
  if (!cfg.alistBase) {
    const miss = { ok: false, status: 0, ms: 0, error: NO_BASE.message, code: NO_BASE.code };
    out.root = miss;
    out.search = miss;
    return out;
  }

  /* 1) 连通性：列根目录（匿名即可；401 说明实例开了强制登录） */
  const t0 = Date.now();
  try {
    const saved = settings.readAuth();
    const entries = await xiaoya.withAuth(
      (token) => xiaoya.listDir(cfg.alistBase, '/', { timeout: 12000, token }),
      { base: cfg.alistBase, token: saved.token, timeout: 12000 }
    );
    out.root = {
      ok: true,
      ms: Date.now() - t0,
      count: entries.length,
      top: entries.slice(0, 5).map((x) => x.name),
    };
  } catch (e) {
    out.root = {
      ok: false,
      status: Number(e && e.status) || 0,
      ms: Date.now() - t0,
      error: (e && e.message) || String(e),
      code: (e && e.code) || '',
    };
  }

  /* 2) 搜索页一发 */
  const t1 = Date.now();
  try {
    const saved = settings.readAuth();
    const res = await xiaoya.withAuth(
      (token) => xiaoya.searchPage(cfg.alistBase, wd, { type: 'video', timeout: 12000, token }),
      { base: cfg.alistBase, token: saved.token, timeout: 12000 }
    );
    out.search = {
      ok: true,
      ms: Date.now() - t1,
      count: res.items.length,
      top: res.items.slice(0, 3).map((x) => x.name || x.path),
    };
  } catch (e) {
    out.search = {
      ok: false,
      status: Number(e && e.status) || 0,
      ms: Date.now() - t1,
      error: (e && e.message) || String(e),
      code: (e && e.code) || '',
    };
  }
  return out;
}

module.exports = { actions };
