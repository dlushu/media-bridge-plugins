'use strict';
/**
 * 媒体播放器Widgets 输出插件 · 入口（FW/Rex 与 CapyPlayer 共用同一个端点）
 *
 * 它自己**不产出任何媒体数据**。全部数据都经反向通道 `ctx.hostCall` 找面板要：
 *
 *   home.plugins / home.rows / home.run   读某个首页插件的行清单与行结果
 *   agg.search / agg.detail / agg.play    读聚合层（搜索 / 详情 / 播放地址）
 *
 * 对外（在 FW/Rex 播放器里跑）只暴露两条 ingress（见 plugin.json）：
 *
 *   GET  /widget.js     匿名公开 —— 给 FW/Rex 下载的模块代码（装 Widget 时还没令牌，
 *                       存在"先有鸡还是先有蛋"，所以这条必须免鉴权；令牌不写进代码里）
 *   其余 /api/**        要外部访问令牌 —— 面板网关验过才会把请求转到这里，
 *                       本插件不再自己验票（网关转发来的都视为已验）。
 *
 * 设计约束：
 *   · widget.js 每次请求**现生成**（行清单来自设置页选定的首页插件，见 lib/settings.js），不缓存到盘；
 *   · 面板地址只给一个"可达时"的默认值；令牌走「模块 URL 携带」——设置页复制的地址带 ?token=，
 *     经宿主验过才注入生成的 JS；匿名下载（没带 / 带错令牌）拿到的 JS 里令牌为空，安全模型不变；
 *   · 返回给网关的形状与其他插件一致：`{ status?, body, contentType? }`。
 */
const fs = require('fs');
const path = require('path');
const pkg = require('./plugin.json');
const settings = require('./lib/settings');

const RUNTIME_FILE = path.join(__dirname, 'lib', 'widget-runtime.js');

/** hostCall 失败码 → HTTP 状态：入参类问题 400，取不到上游 502，超时 504，其余 500 */
function statusOf(code) {
  if (code === 'BAD_INPUT' || code === 'NO_DOMAIN' || code === 'NO_SITE' || code === 'NO_SOURCE') return 400;
  if (code === 'TIMEOUT') return 504;
  if (code === 'NO_HOSTCALL' || code === 'HOSTCALL_ERROR' || code === 'PLUGIN_ERROR' || code === 'AGG_ERROR') return 502;
  return 502;
}

async function hostCallOrResponse(ctx, target, action, args) {
  try {
    const value = await ctx.hostCall(target, action, args || {});
    return { ok: true, value };
  } catch (e) {
    return {
      ok: false,
      response: {
        status: statusOf(e && e.code),
        body: { error: { code: (e && e.code) || 'UPSTREAM_ERROR', message: (e && e.message) || String(e) } },
      },
    };
  }
}

/* ------------------------------------------------------- widget.js 生成 */

/**
 * 首页插件选取：设置页选的 → 第一个启用且在跑的 → 第一个（哪怕没在跑，
 * 至少让模块列表先出来；真正翻页时上游会如实报错）。
 */
async function pickHomePlugin(ctx, wantedId) {
  const r = await hostCallOrResponse(ctx, 'home', 'plugins', {});
  if (!r.ok) return { error: r.response };
  const plugins = ((r.value && r.value.plugins) || []).filter((p) => p.type !== 'output');
  const wanted = String(wantedId || '').trim();
  const hit = (wanted && plugins.find((p) => p.id === wanted))
    || plugins.find((p) => p.enabled && p.running)
    || plugins[0]
    || null;
  return { plugin: hit, plugins };
}

/**
 * 拼 widget.js。形状严格照 FW/Rex Widgets 规范（见上游 widgets/demo.js）：
 *   顶层 WidgetMetadata（globalParams / search / modules）
 *   顶层 loadDetail(link)
 *   每个榜单行一个 list 模块（不写 type，params 是 page）
 *   一个 type:'stream' 的 loadResource 模块
 * 具体逻辑全在 lib/widget-runtime.js；这里注入四样东西：首页插件 id 与元数据**是结构**（改了要重装
 * 模块，FW 得重读 JS），而聚合模板 id / 需鉴权线路上限**只是兜底快照** —— 运行时每会话从 `/config`
 * 现拉当前值，所以设置页改这两项**不用在客户端重装**（见 lib/widget-runtime.js 的「现拉设置」）。
 */
async function buildWidget(args, ctx) {
  settings.bind(ctx && ctx.dataDir);

  /* 多套输出：模块地址用 `?set=<套id>` 区分（没传 / 找不到都回第一套，
   * 所以老的不带 set 的地址照常可用）。每套各自一套设置（名称 / 首页插件 / 模板 / 上限）。 */
  const set = settings.byId((args.query && args.query.set) || '');

  /* 同一个端点按客户端分支：`?client=capy` 生成 CapyPlayer 组件代码，缺省按 FW/Rex。
   * 两家规范有四处口径差异（参数类型 input/string、条目 type url/link、模块类型 stream/media_list、
   * 顶层 search 只有 FW 认），运行时的分支在 lib/widget-runtime.js（注入的 MB_CLIENT）。 */
  const client = String((args.query && args.query.client) || '').trim().toLowerCase() === 'capy' ? 'capy' : 'fw';
  const isCapy = client === 'capy';

  /* 模块 URL 上的 ?token=（设置页复制的就是这个形态）：问宿主验票，**验过才注入**。
   * 不带 / 带错令牌的匿名请求照常生成 JS，只是令牌位置为空 —— 与手填全局参数时等价。 */
  let injectToken = '';
  const urlToken = String((args.query && args.query.token) || '').trim();
  if (urlToken) {
    const tr = await hostCallOrResponse(ctx, 'panel', 'ingressTokenCheck', { token: urlToken });
    if (tr.ok && tr.value && tr.value.valid) injectToken = urlToken;
  }

  const picked = await pickHomePlugin(ctx, set.home);
  if (picked.error) {
    // 连首页插件清单都拿不到时不 500：仍然吐模块（只有搜索能⽤），并把原因写进默认值提示
    picked.plugin = null;
  }

  let rows = [];
  if (picked.plugin) {
    const rr = await hostCallOrResponse(ctx, 'home', 'rows', { pluginId: picked.plugin.id });
    if (rr.ok) rows = (rr.value && rr.value.rows) || [];
  }

  /* 面板地址默认值：请求 Host 是回环地址时不给默认（手机上的 FW/Rex 够不到它，
   * 留空强制用户填局域网地址）；反向代理来的 https 也能据此给对协议。 */
  const host = String(args.host || '');
  const proto = String(args.proto || 'http');
  const isLoopback = /^(localhost|127\.)/i.test(host);
  const defaultPanel = host && !isLoopback ? `${proto}://${host}` : '';

  const mbRows = rows.map((row, i) => ({
    i,
    pluginId: picked.plugin.id,
    rowId: String(row.id),
    title: String(row.title || row.id),
    fn: 'mbLoadRow_' + i,
  }));

  const modules = mbRows.map((r) => {
    const m = {
      id: 'row_' + r.i,
      title: r.title,
      description: `媒体桥首页行「${r.title}」`,
      functionName: r.fn,
      requiresWebView: false,
      cacheDuration: 300,
      params: [{ name: 'page', title: '页码', type: 'page', value: '1' }],
    };
    /* CapyPlayer 的模块类型只有 media_list / category，也没有 requiresWebView 这个概念 */
    if (isCapy) {
      delete m.requiresWebView;
      m.type = 'media_list';
    }
    return m;
  });
  if (isCapy) {
    /* CapyPlayer 不读顶层 search —— 搜索改成一个普通列表模块（functionName 仍是 mbSearch） */
    modules.push({
      id: 'search',
      title: '搜索媒体桥',
      description: '按关键词搜索媒体桥聚合源',
      functionName: 'mbSearch',
      type: 'media_list',
      cacheDuration: 0,
      params: [
        { name: 'keyword', title: '关键词', type: 'string', value: '' },
        { name: 'page', title: '页码', type: 'page', value: '1' },
      ],
    });
  }
  /* loadResource（stream）**两个分支都要**：CapyPlayer 在 Emby 条目详情页点组件线路时，
     调的就是这个模块（把片名/季集 seriesName/type/season/episode 传进来解析），
     缺了它点击零请求（实测：只留 media_list 时 capy 无任何派发）。 */
  modules.push({
    id: 'loadResource',
    title: '加载播放资源',
    description: '按条目定位片源并解析可播放地址（网盘类源到播放时才提交离线下载）',
    functionName: 'mbLoadResource',
    type: 'stream',
    params: [],
    cacheDuration: 0,
  });

  /* CapyPlayer 的参数类型表里没有 `input`，文本输入一律 `string`（FW/Rex 认 input） */
  const textType = isCapy ? 'string' : 'input';

  /* 模块 id / 标题都按套生成：default 套保持 `mediabridge.fw`（老用户升级后客户端仍认同一个模块），
   * 其余套带后缀，多套才能同时装进一个播放器；标题 = 「媒体桥」或「媒体桥·<名称>」。 */
  const meta = {
    id: set.id === settings.DEFAULT_SET_ID ? 'mediabridge.fw' : 'mediabridge.fw.' + set.id,
    title: '媒体桥' + (set.name ? '·' + set.name : ''),
    version: pkg.version,
  };
  if (!isCapy) {
    meta.requiredVersion = '0.0.1';
    meta.icon = '';
  }
  meta.description = '媒体桥。需在全局参数填面板地址与访问令牌。';
  meta.author = 'media-bridge';
  meta.site = '';
  if (!isCapy) meta.detailCacheDuration = 300;
  meta.globalParams = [
    { name: 'panel', title: '面板地址', type: textType, value: defaultPanel },
    /* URL 带的令牌验过后烘在这里：安装时即生效，不用再手填；匿名下载时为空串 */
    { name: 'token', title: '外部访问令牌', type: textType, value: injectToken },
  ];
  if (!isCapy) {
    meta.search = {
      title: '搜索媒体桥',
      functionName: 'mbSearch',
      params: [
        { name: 'keyword', title: '关键词', type: 'input', value: '' },
        { name: 'page', title: '页码', type: 'page', value: '1' },
      ],
    };
  }
  meta.modules = modules;

  /* 每个行模块一个具名入口（FW/Rex 按 functionName 找全局函数）。
   * 行身份编进闭包，不依赖运行时 params 里有没有模块 id。 */
  const rowBindings = mbRows
    .map((r) => `async function ${r.fn}(params){ return mbLoadRow(${JSON.stringify({ pluginId: r.pluginId, rowId: r.rowId, title: r.title })}, params); }`)
    .join('\n');

  const runtime = fs.readFileSync(RUNTIME_FILE, 'utf8');
  const generated = [
    '/* 本文件由 media-bridge fwrex 输出插件自动生成，请勿手改。',
    ` * 面板版本 ${pkg.version}；生成时间 ${new Date().toISOString()}；输出套 ${set.id}；首页插件 ${picked.plugin ? picked.plugin.id : '(无)'} */`,
    `var MB_META = ${JSON.stringify(meta)};`,
    `var WidgetMetadata = MB_META;`,
    `var MB_SET = ${JSON.stringify(set.id)};`,
    `var MB_HOME_PLUGIN = ${JSON.stringify(picked.plugin ? picked.plugin.id : '')};`,
    `var MB_CLIENT = ${JSON.stringify(client)};`,
    '/* 下面两行只是**兜底默认**：运行时每会话 `POST /config` 现拉面板当前值（按 MB_SET 取本套），' +
      '所以设置页改这两项不用重装模块；拉不到时才用这里这份生成时快照。 */',
    `var MB_TPL = ${JSON.stringify(set.tpl || settings.DEFAULT_TPL)};`,
    `var MB_PROXY_MAX_LINES = ${JSON.stringify(set.proxyMaxLines)};`,
    '/* 面板地址 / 令牌的**生成时快照**：宿主若没把 globalParams 并进模块参数，运行时拿这份兜底 */',
    `var MB_PANEL_DEFAULT = ${JSON.stringify(defaultPanel)};`,
    `var MB_TOKEN_DEFAULT = ${JSON.stringify(injectToken)};`,
    '',
    runtime,
    '',
    '/* ---- 榜单行模块入口（生成时绑定行身份）---- */',
    rowBindings,
    '',
  ].join('\n');

  return {
    status: 200,
    contentType: 'application/javascript; charset=utf-8',
    body: generated,
  };
}

/* ------------------------------------------------------------- 路由 */

function parseBody(args) {
  if (!args.body) return {};
  try {
    return JSON.parse(args.body);
  } catch {
    return null;
  }
}

const actions = {
  /** 自检/信息（面板插件列表会调一下） */
  async info() {
    return { ok: true, id: pkg.id, version: pkg.version };
  },

  /**
   * webui 后端：面板把 `/api/plugins/output/fwrex/api/**` 原样转来。
   * 令牌校验在面板网关（ingress）做，到这里的 token 路径请求都已验过票。
   */
  async http(args = {}, ctx) {
    const method = String(args.method || 'GET').toUpperCase();
    const p = String(args.path || '/').split('?')[0].replace(/\/+$/, '') || '/';
    const q = args.query || {};
    const body = parseBody(args);
    if (body === null) return { status: 400, body: { error: { code: 'BAD_JSON', message: '请求体不是 JSON' } } };

    /* 唯一的匿名入口（plugin.json ingress.public） */
    if (method === 'GET' && p === '/widget.js') return buildWidget(args, ctx);

    /* ---------------- 以下都在 ingress.token 范围内（验外部令牌或登录 cookie） ---------------- */

    settings.bind(ctx && ctx.dataDir);

    /** 设置页首屏：全部输出套 + 可选的首页插件与模板清单 */
    if (method === 'GET' && p === '/state') {
      const r = await hostCallOrResponse(ctx, 'home', 'plugins', {});
      const plugins = r.ok ? ((r.value && r.value.plugins) || []) : [];
      const tr = await hostCallOrResponse(ctx, 'agg', 'templates', {});
      return {
        body: {
          plugin: { id: pkg.id, name: pkg.name, version: pkg.version },
          settings: settings.read(),
          /* 上限的封顶值与套数软上限由插件给，设置页不重复写一遍数字 */
          proxyMaxLinesMax: settings.MAX_PROXY_MAX_LINES,
          maxOutputs: settings.MAX_OUTPUTS,
          homes: plugins
            .filter((x) => x.type !== 'output')
            .map((x) => ({ id: String(x.id), name: String(x.name || x.id), enabled: !!x.enabled, running: !!x.running })),
          /* 模板清单：设置页直接选模板，不按元数据域走（空 = 第一套） */
          templates: tr.ok ? ((tr.value && tr.value.templates) || []) : [],
          /* 取不到清单时如实说明，设置页内联显示 */
          error: r.ok ? '' : ((r.response.body.error && r.response.body.error.message) || '取首页插件清单失败'),
        },
      };
    }

    /** 保存输出套：设置页收集全量 outputs 提交（增 / 删 / 改都是它），归一与封顶交给 settings */
    if (method === 'POST' && p === '/settings') {
      return {
        body: {
          ok: true,
          settings: settings.write({ outputs: Array.isArray(body.outputs) ? body.outputs : [] }),
        },
      };
    }

    /**
     * 客户端每次会话问一次「当前设置」（`lib/widget-runtime.js` 的 mbLiveSettings）。
     * 只回设置本身、不碰首页插件清单，所以极轻 —— 目的是让面板改完设置后**不用在客户端重装模块**。
     * 按 `set`（query 或 body）取对应那一套；没传 / 找不到回第一套（兼容老模块）。
     * 只认 GET/POST 两种方法，两者等价（运行时用的是 POST，因为它只会 `Widget.http.post`）。
     */
    if (p === '/config') {
      const cur = settings.byId(q.set || (body && body.set) || '');
      return {
        body: {
          tpl: cur.tpl || settings.DEFAULT_TPL,
          proxyMaxLines: cur.proxyMaxLines,
          proxyMaxLinesMax: settings.MAX_PROXY_MAX_LINES,
        },
      };
    }

    if (method === 'GET' && p === '/home/plugins') {
      const r = await hostCallOrResponse(ctx, 'home', 'plugins', {});
      return r.ok ? { body: r.value } : r.response;
    }

    if (method === 'GET' && p === '/home/rows') {
      const r = await hostCallOrResponse(ctx, 'home', 'rows', { pluginId: String(q.pluginId || q.home || '').trim() });
      return r.ok ? { body: r.value } : r.response;
    }

    if (method === 'POST' && p === '/home/run') {
      const r = await hostCallOrResponse(ctx, 'home', 'run', {
        pluginId: String(body.pluginId || '').trim(),
        rowId: String(body.rowId || '').trim(),
        startIndex: Number(body.startIndex) || 0,
        limit: Number(body.limit) || 0,
      });
      return r.ok ? { body: r.value } : r.response;
    }

    if (method === 'POST' && p === '/agg/search') {
      const r = await hostCallOrResponse(ctx, 'agg', 'search', body);
      return r.ok ? { body: r.value } : r.response;
    }

    if (method === 'POST' && p === '/agg/detail') {
      const r = await hostCallOrResponse(ctx, 'agg', 'detail', body);
      return r.ok ? { body: r.value } : r.response;
    }

    if (method === 'POST' && p === '/agg/play') {
      const r = await hostCallOrResponse(ctx, 'agg', 'play', body);
      return r.ok ? { body: r.value } : r.response;
    }

    return { status: 404, body: { error: { code: 'NOT_FOUND', message: `没有这个路径：${method} ${p}` } } };
  },
};

module.exports = { actions };
