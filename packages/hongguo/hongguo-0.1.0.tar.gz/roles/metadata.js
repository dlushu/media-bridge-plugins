"use strict";

/**
 * metadata 角色薄壳（CJS）。
 *
 * 面板动作名 → service.mjs 导出名：register/lookup/season/search → metadata*。
 * 实现见 plugins/hongguo/PLAN.md §4.3。
 */

const bridge = require("../lib/bridge.js");

const actions = {
  register: (args) => bridge.call("metadataRegister", args),
  lookup: (args) => bridge.call("metadataLookup", args),
  season: (args) => bridge.call("metadataSeason", args),
  search: (args) => bridge.call("metadataSearch", args),
};

module.exports = { actions };
