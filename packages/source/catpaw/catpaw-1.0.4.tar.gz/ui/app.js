'use strict';
/**
 * 猫爪源设置页的前端。
 *
 * 所有请求都打到**面板的转发通道**：`/api/plugins/<类型>/<id>/api/**` ——
 * 面板把它转成动作 `http`，由插件的 `index.js` 处理（面板不解释内容）。
 *
 * ⚠️ 路径是**算出来的**，不写死类型与 id：页面自己的地址是
 * `/api/plugins/source/catpaw/ui/index.html`，把 `/ui/…` 之后切掉就得到通道前缀。
 * 这样换 id、换类型都不用改这里（也不该依赖 `./api/x` —— 那是相对 `ui/` 目录解析的）。
 */
const API = location.pathname.replace(/\/ui\/.*$/, '') + '/api';

const $ = (id) => document.getElementById(id);

async function call(path, { method = 'GET', body } = {}) {
  const res = await fetch(API + path, {
    method,
    headers: body ? { 'Content-Type': 'application/json' } : undefined,
    body: body ? JSON.stringify(body) : undefined,
  });
  let data = null;
  try {
    data = await res.json();
  } catch {
    throw new Error(`面板回的不是 JSON（HTTP ${res.status}）`);
  }
  if (!res.ok || data.ok === false) throw new Error((data && data.error) || `HTTP ${res.status}`);
  return data;
}

let msgTimer = null;
function say(text, bad = false) {
  const el = $('msg');
  el.textContent = text || '';
  el.style.color = bad ? 'var(--err)' : 'var(--accent)';
  if (msgTimer) clearTimeout(msgTimer);
  msgTimer = setTimeout(() => {
    el.textContent = '';
  }, 4000);
}

/** 面板与插件之间传的是 JSON，所以这里一律用 DOM 建节点，不拼 HTML 串 */
function el(tag, attrs = {}, ...kids) {
  const n = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs)) {
    if (k === 'class') n.className = v;
    else if (k === 'text') n.textContent = v;
    else if (k === 'onclick') n.addEventListener('click', v);
    else if (v !== null && v !== undefined && v !== false) n.setAttribute(k, String(v));
  }
  for (const k of kids) if (k) n.append(k);
  return n;
}

function fmtTime(ms) {
  if (!ms) return '—';
  const d = new Date(ms);
  const p = (n) => String(n).padStart(2, '0');
  return `${p(d.getMonth() + 1)}-${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}:${p(d.getSeconds())}`;
}

function fmtUp(ms) {
  if (!ms || ms < 0) return '—';
  const s = Math.floor(ms / 1000);
  if (s < 60) return `${s} 秒`;
  if (s < 3600) return `${Math.floor(s / 60)} 分 ${s % 60} 秒`;
  return `${Math.floor(s / 3600)} 时 ${Math.floor((s % 3600) / 60)} 分`;
}

const STATUS_TEXT = { running: '运行中', starting: '启动中', stopping: '停止中', stopped: '已停止', error: '异常' };

/** 配置中心的地址：**直连实例端口**（面板不再在中间代理）。
 *  端口没发布到宿主机时浏览器连不上 —— 那是部署的事，这里如实给出地址。 */
function configUrl(one) {
  return `http://${location.hostname}:${one.port}/website`;
}

function statusBadge(one) {
  const cls = one.status === 'running' ? 'ok' : one.status === 'error' ? 'err' : one.status === 'starting' ? 'warn' : '';
  return el('span', { class: 'badge ' + cls }, el('span', { class: 'dot ' + (one.status || '') }), STATUS_TEXT[one.status] || one.status || '—');
}

function instanceRow(one) {
  const ops = el('td', { class: 'ops' });
  const busy = (btn) => {
    btn.disabled = true;
    btn.textContent = '…';
  };
  const act = (op, label, cls) =>
    el('button', {
      class: 'btn mini ' + (cls || ''),
      text: label,
      title: op ? `对这个实例执行 ${op}` : label,
      onclick: async (e) => {
        busy(e.target);
        try {
          await call(`/instances/${encodeURIComponent(one.id)}/${op}`, { method: 'POST' });
          say(`${one.id} ${label}完成`);
        } catch (err) {
          say(`${one.id} ${label}失败：${err.message}`, true);
        }
        await load();
      },
    });

  if (one.mode === 'local') {
    if (one.status === 'running') ops.append(act('stop', '停止'), act('restart', '重启'));
    else ops.append(act('start', '启动', 'primary'));
    ops.append(act('update', '更新'));
  }
  if (one.port) {
    ops.append(
      el('a', { class: 'btn mini', href: configUrl(one), target: '_blank', rel: 'noreferrer', text: '配置中心' })
    );
  }
  ops.append(
    el('button', {
      class: 'btn mini danger',
      text: '删除',
      onclick: async (e) => {
        if (!window.confirm(`删除实例「${one.name || one.id}」？它下载的源包与运行数据会一起删掉。`)) return;
        busy(e.target);
        try {
          await call(`/instances/${encodeURIComponent(one.id)}`, { method: 'DELETE' });
          say(`已删除 ${one.id}`);
        } catch (err) {
          say(`删除失败：${err.message}`, true);
        }
        await load();
      },
    })
  );

  const nameTd = el('td');
  nameTd.append(
    el('div', { text: one.name || '(未命名)' }),
    el('div', { class: 'muted mono', style: 'font-size:12px', text: one.id })
  );

  const whereTd = el('td');
  whereTd.append(
    el('div', { text: one.where }),
    /* 窄屏下表头不显示（表格摊成卡片），两行地址各自带个小标签，不然看不出哪条是哪条 */
    el('div', {
      class: 'muted mono',
      style: 'font-size:12px;word-break:break-all',
      text: (one.mode === 'local' ? '源包 ' : '服务 ') + (one.sourceUrl || ''),
    })
  );

  const addrTd = el('td');
  addrTd.append(
    el('div', { class: 'mono', style: 'font-size:12px;word-break:break-all', text: (one.mode === 'local' ? '服务 ' : '') + (one.url || '（没在服务）') }),
    el('div', { class: 'muted', style: 'font-size:12px', text: one.mode === 'local' ? `已跑 ${fmtUp(one.startedAt ? Date.now() - one.startedAt : 0)}` : '' })
  );

  const statusTd = el('td');
  statusTd.append(statusBadge(one));
  if (one.error) statusTd.append(el('div', { class: 'err', style: 'margin-top:6px;max-width:420px', text: one.error }));

  return el('tr', {}, nameTd, whereTd, addrTd, statusTd, ops);
}

function paintInstances(list) {
  const host = $('instHost');
  host.textContent = '';
  if (!list.length) {
    host.append(el('div', { class: 'hint warn', text: '还没有实例。下面加一个：本地部署（填源包地址）或外部地址（填已经在跑的源地址）。' }));
    return;
  }
  const table = el('table');
  table.append(
    el(
      'thead',
      {},
      el(
        'tr',
        {},
        el('th', { text: '实例' }),
        el('th', { text: '方式' }),
        el('th', { text: '现在服务的地址' }),
        el('th', { text: '状态' }),
        el('th', { text: '' })
      )
    )
  );
  const body = el('tbody');
  for (const one of list) body.append(instanceRow(one));
  table.append(body);
  host.append(table);
}

function paintAutoUpdate(au, results) {
  $('auEnabled').checked = !!au.enabled;
  $('auHours').value = au.hours || 12;
  const bits = [];
  if (au.running) bits.push('正在检查');
  if (au.lastRunAt) bits.push(`上次 ${fmtTime(au.lastRunAt)}（${au.lastReason || '-'}）`);
  if (au.nextRunAt) bits.push(`下次 ${fmtTime(au.nextRunAt)}`);
  $('auState').textContent = bits.join(' · ') || '还没跑过';

  const host = $('auResults');
  host.textContent = '';
  const rows = results || au.results || [];
  if (!rows.length) return;
  const table = el('table');
  table.append(
    el('thead', {}, el('tr', {}, el('th', { text: '实例' }), el('th', { text: '结果' }), el('th', { text: '说明' })))
  );
  const body = el('tbody');
  for (const r of rows) {
    body.append(
      el(
        'tr',
        {},
        el('td', { text: r.name || r.id }),
        el('td', {}, el('span', { class: 'badge ' + (r.ok ? 'ok' : 'err'), text: r.ok ? (r.changed ? '有新版' : '已最新') : '失败' })),
        el('td', { class: 'muted', text: r.error || (r.restarted ? '已重启' : '') })
      )
    );
  }
  table.append(body);
  host.append(table);
}

/** 插件自己那份缓存的用量（两个旋钮是输入框，其余在这儿显示） */
function paintCache(settings, stats) {
  $('cacheTtl').value = settings.ttlMinutes !== undefined ? settings.ttlMinutes : 5;
  $('cacheMax').value = settings.maxMB !== undefined ? settings.maxMB : 64;
  const up = (stats.tables && stats.tables.upstream) || {};
  const mb = (n) => (Number(n || 0) / 1024 / 1024).toFixed(1);
  const cap = up.maxBytes > 0 ? `${mb(up.maxBytes)} MB` : '不限';
  const ttl = settings.ttlMinutes > 0 ? `${settings.ttlMinutes} 分钟` : '不缓存';
  $('cacheState').textContent = `已用 ${mb(stats.bytes)} MB / 上限 ${cap} · ${stats.rows || 0} 条 · 有效期 ${ttl}`;
}

/** 拉一次状态并整页重绘。`loud` 只在首次与手动刷新时为真 —— 轮询期间后端一直不通的话，
 *  不该每 2 秒嚷一次（见下面的 `pollInstances`）。 */
async function load(loud = false) {
  try {
    const d = await call('/state');
    paintInstances(d.instances || []);
    paintAutoUpdate(d.autoUpdate || {});
    paintCache(d.cacheSettings || {}, d.cache || {});
  } catch (e) {
    if (loud) say('读不到状态：' + e.message, true);
  }
}

/**
 * 轮询只重画**实例表**：这一页另外两张卡里是输入框（自动更新的小时数、缓存的旋钮），
 * 整页重绘会把用户正在敲的值冲掉。
 */
async function pollInstances() {
  try {
    const d = await call('/state');
    paintInstances(d.instances || []);
  } catch {
    /* 轮询期间静默：一次读不到不代表坏了，下一轮再试 */
  }
}

/**
 * 实例状态每 2 秒重拉一次（与面板「插件 → 管理」页同一口径）。
 *
 * ⚠️ 这一步不能省：`/instances/:id/start` 是**异步**的 —— 后端 `startInstance()` 不等监听
 * 就返回，那一刻状态是 `starting`。只在动作后刷一次的话，「启动中」会一直挂着、看不到
 * 「运行中」（`running` 是几秒后由 runner 探到端口才置上的）。
 */
let timer = null;
function startPolling() {
  if (timer) return;
  timer = setInterval(async () => {
    if (!$('instHost')) {
      clearInterval(timer);
      timer = null;
      return;
    }
    await pollInstances();
  }, 2000);
}

/* ---------------- 事件接线 ---------------- */

$('reload').addEventListener('click', () => load(true));

$('mode').addEventListener('change', () => {
  const local = $('mode').value === 'local';
  $('urlLabel').textContent = local ? '源包地址（例如 https://example.com/dist/）' : '服务地址（例如 http://192.168.8.1:8090）';
  $('port').parentElement.style.display = local ? '' : 'none';
  $('addHint').textContent = local
    ? '本地部署：插件会把源包下载到自己的数据目录（下载必校验 md5，对不上就删掉重来），再按端口起一个常驻进程。'
    : '外部地址：那台机器上的源由那边自己管，插件只按地址取数。';
});

$('add').addEventListener('click', async (e) => {
  const body = {
    mode: $('mode').value,
    name: $('name').value.trim(),
    url: $('url').value.trim(),
    port: Number($('port').value) || 0,
  };
  if (!body.url) return say('请填地址', true);
  e.target.disabled = true;
  e.target.textContent = '添加中…';
  try {
    const d = await call('/instances', { method: 'POST', body });
    say(`已添加 ${d.instance.id}`);
    $('name').value = '';
    $('url').value = '';
    await load();
  } catch (err) {
    say('添加失败：' + err.message, true);
  }
  e.target.disabled = false;
  e.target.textContent = '添加';
});

$('auSave').addEventListener('click', async (e) => {
  e.target.disabled = true;
  try {
    await call('/autoupdate', { method: 'POST', body: { autoUpdate: $('auEnabled').checked, autoUpdateHours: Number($('auHours').value) || 12 } });
    say('自动更新设置已保存');
  } catch (err) {
    say('保存失败：' + err.message, true);
  }
  e.target.disabled = false;
  await load();
});

$('auRun').addEventListener('click', async (e) => {
  e.target.disabled = true;
  e.target.textContent = '检查中…';
  try {
    const d = await call('/autoupdate/run', { method: 'POST' });
    paintAutoUpdate(d.autoUpdate || {}, d.results || []);
    say('检查完成');
  } catch (err) {
    say('检查失败：' + err.message, true);
  }
  e.target.disabled = false;
  e.target.textContent = '立即检查';
  await load();
});

$('mode').dispatchEvent(new Event('change'));

$('cacheSave').addEventListener('click', async (e) => {
  e.target.disabled = true;
  try {
    const d = await call('/cache/settings', {
      method: 'POST',
      body: { cacheTtlMinutes: Number($('cacheTtl').value), cacheMaxMB: Number($('cacheMax').value) },
    });
    paintCache(d.cacheSettings || {}, d.cache || {});
    say('缓存设置已保存');
  } catch (err) {
    say('保存失败：' + err.message, true);
  }
  e.target.disabled = false;
  await load();
});

$('cacheReload').addEventListener('click', async () => {
  try {
    const d = await call('/cache');
    paintCache(d.cacheSettings || {}, d.cache || {});
    say('缓存用量已刷新');
  } catch (err) {
    say('刷新失败：' + err.message, true);
  }
});

$('cacheClear').addEventListener('click', async (e) => {
  if (!window.confirm('清空缓存？下次取数会重新打上游。')) return;
  e.target.disabled = true;
  try {
    const d = await call('/cache/clear', { method: 'POST' });
    paintCache(d.cacheSettings || {}, d.cache || {});
    say('缓存已清空');
  } catch (err) {
    say('清空失败：' + err.message, true);
  }
  e.target.disabled = false;
  await load();
});

load(true);
startPolling();
