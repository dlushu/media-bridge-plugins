'use strict';
/**
 * MissAV 多类型包入口（首页 + 元数据 + 源，见 docs/adr/0046）。
 *
 * 一个包一个进程，宿主按消息里的 role 把动作分发到对应角色模块：
 *   home/…      → roles/home      首页行
 *   metadata/…  → roles/metadata  注册 / 查信息 / 搜索
 *   source/…    → roles/source    站点 / 搜索 / 详情 / 播放
 *
 * 每个角色各自一份目录（自己的 lib/、ui/），数据共享包根 data/，
 * 但写盘的文件名按角色隔开（见各 lib/settings.js）。
 */
module.exports = {
  actions: {
    home: require('./roles/home').actions,
    metadata: require('./roles/metadata').actions,
    source: require('./roles/source').actions,
  },
};
