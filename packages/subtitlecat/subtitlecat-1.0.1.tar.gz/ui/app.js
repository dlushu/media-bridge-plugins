'use strict';
/**
 * SubtitleCat 字幕设置页的前端。
 *
 * 请求都打到面板的转发通道 `/api/plugins/<类型>/<id>/api/**`：面板把它转成动作 `http`，
 * 由 index.js 处理（面板不解释内容）。
 *
 * 通道前缀是**算出来的**，不写死类型与 id：页面自己的地址是
 * `/api/plugins/subtitle/subtitlecat/ui/index.html`，把 `/ui/…` 之后切掉就得到前缀。
 */
const API = location.pathname.replace(/\/ui\/.*$/, '') + '/api';
const $ = (id) => document.getElementById(id);

async function call(path, { method = 'GET', body } = {}) {
  const res = await fetch(API + path, {
    method,
    headers: body ? { 'Content-Type': 'application/json' } : undefined,
    body: body ? JSON.stringify(body) : undefined,
  });
  let data = null;
  try {
    data = await res.json();
  } catch {
    throw new Error(`面板回的不是 JSON（HTTP ${res.status}）`);
  }
  if (!res.ok || data.ok === false) throw new Error(errText(data, res.status));
  return data;
}

/** 从任意形状的响应里抠一句人能读的错 —— 面板转发层可能把 error 包成对象 */
function errText(data, status) {
  const e = data && data.error;
  if (typeof e === 'string' && e) return e;
  if (e && typeof e === 'object') {
    if (typeof e.message === 'string' && e.message) return e.message;
    const s = JSON.stringify(e);
    if (s && s !== '{}') return s;
  }
  if (typeof (data && data.message) === 'string' && data.message) return data.message;
  return `HTTP ${status}`;
}

let msgTimer = null;
function say(text, bad = false) {
  const el = $('msg');
  el.textContent = text || '';
  el.style.color = bad ? 'var(--err)' : 'var(--accent)';
  if (msgTimer) clearTimeout(msgTimer);
  msgTimer = setTimeout(() => {
    el.textContent = '';
  }, 5000);
}

const fmtMB = (n) => (Number(n || 0) / 1024 / 1024).toFixed(1);
const show = (id, text) => {
  const el = $(id);
  el.style.display = text ? 'block' : 'none';
  el.textContent = text || '';
};

function paintState(d) {
  const s = d.settings || {};
  const c = d.cacheSettings || {};
  $('siteBase').value = s.siteBase || '';
  $('langOrder').value = s.langOrder || 'zh-CN,zh-TW,en,ja,ko';
  $('cacheTtl').value = c.ttlMinutes !== undefined ? c.ttlMinutes : 1440;
  $('cacheMax').value = c.maxMB !== undefined ? c.maxMB : 64;

  const cap = c.maxMB > 0 ? `${fmtMB(c.maxMB * 1024 * 1024)} MB` : '不限';
  const ttl = c.ttlMinutes > 0 ? `${c.ttlMinutes} 分钟` : '不缓存';
  $('cacheState').textContent =
    `已用 ${fmtMB(d.cache && d.cache.bytes)} MB / 上限 ${cap} · ${(d.cache && d.cache.rows) || 0} 条 · 有效期 ${ttl}`;

  $('where').textContent =
    `站点 ${s.siteBase || ''} · 插件 ${(d.plugin && d.plugin.name) || ''} ${(d.plugin && d.plugin.version) || ''}`;
}

async function load() {
  try {
    paintState(await call('/state'));
  } catch (e) {
    say('读不到状态：' + e.message, true);
  }
}

/* ---------------- 事件接线 ---------------- */

$('siteSave').addEventListener('click', async (e) => {
  e.target.disabled = true;
  try {
    paintState(await call('/settings', {
      method: 'POST',
      body: { siteBase: $('siteBase').value, langOrder: $('langOrder').value },
    }));
    say('设置已保存');
  } catch (err) {
    say('保存失败：' + err.message, true);
  }
  e.target.disabled = false;
});

$('cacheSave').addEventListener('click', async (e) => {
  e.target.disabled = true;
  try {
    const d = await call('/cache/settings', {
      method: 'POST',
      body: { cacheTtlMinutes: Number($('cacheTtl').value), cacheMaxMB: Number($('cacheMax').value) },
    });
    paintState({ settings: {}, cacheSettings: d.cacheSettings, cache: d.cache });
    say('缓存设置已保存');
  } catch (err) {
    say('保存失败：' + err.message, true);
  }
  e.target.disabled = false;
});

$('cacheReload').addEventListener('click', async () => {
  try {
    const d = await call('/cache');
    paintState({ settings: {}, cacheSettings: d.cacheSettings, cache: d.cache });
  } catch (err) {
    say('读取失败：' + err.message, true);
  }
});

$('cacheClear').addEventListener('click', async () => {
  try {
    const d = await call('/cache/clear', { method: 'POST', body: {} });
    paintState({ settings: {}, cacheSettings: d.cacheSettings, cache: d.cache });
    say('缓存已清空');
  } catch (err) {
    say('清空失败：' + err.message, true);
  }
});

$('test').addEventListener('click', async (e) => {
  e.target.disabled = true;
  show('testResult', '自检中…');
  try {
    const d = await call('/test', { method: 'POST', body: { code: $('testCode').value } });
    show('testResult', JSON.stringify(d.result, null, 2));
  } catch (err) {
    show('testResult', '自检失败：' + err.message);
  }
  e.target.disabled = false;
});

load();
