'use strict';
/**
 * 小雅 Alist 片源设置页的前端。
 *
 * 请求都打到面板的转发通道 `/api/plugins/<类型>/<id>/api/**`：面板把它转成动作 `http`，
 * 由 index.js 处理（面板不解释内容）。
 *
 * 通道前缀是**算出来的**，不写死类型与 id：页面自己的地址是
 * `/api/plugins/source/xiaoya/ui/index.html`，把 `/ui/…` 之后切掉就得到前缀。
 */
const API = location.pathname.replace(/\/ui\/.*$/, '') + '/api';
const $ = (id) => document.getElementById(id);

async function call(path, { method = 'GET', body } = {}) {
  const res = await fetch(API + path, {
    method,
    headers: body ? { 'Content-Type': 'application/json' } : undefined,
    body: body ? JSON.stringify(body) : undefined,
  });
  let data = null;
  try {
    data = await res.json();
  } catch {
    throw new Error(`面板回的不是 JSON（HTTP ${res.status}）`);
  }
  if (!res.ok || data.ok === false) throw new Error(errText(data, res.status));
  return data;
}

/** 从任意形状的响应里抠一句人能读的错 —— 面板转发层可能把 error 包成对象 */
function errText(data, status) {
  const e = data && data.error;
  if (typeof e === 'string' && e) return e;
  if (e && typeof e === 'object') {
    if (typeof e.message === 'string' && e.message) return e.message;
    const s = JSON.stringify(e);
    if (s && s !== '{}') return s;
  }
  if (typeof (data && data.message) === 'string' && data.message) return data.message;
  return `HTTP ${status}`;
}

let msgTimer = null;
function say(text, bad = false) {
  const el = $('msg');
  el.textContent = text || '';
  el.style.color = bad ? 'var(--err)' : 'var(--accent)';
  if (msgTimer) clearTimeout(msgTimer);
  msgTimer = setTimeout(() => {
    el.textContent = '';
  }, 5000);
}

const fmtMB = (n) => (Number(n || 0) / 1024 / 1024).toFixed(1);
const show = (id, text) => {
  const el = $(id);
  el.style.display = text ? 'block' : 'none';
  el.textContent = text || '';
};

function paintState(d) {
  const s = d.settings || {};
  const a = d.auth || {};
  const c = d.cacheSettings || {};
  $('alistBase').value = s.alistBase || '';
  $('username').value = a.username || '';
  $('cacheTtl').value = c.ttlMinutes !== undefined ? c.ttlMinutes : 30;
  $('cacheMax').value = c.maxMB !== undefined ? c.maxMB : 128;

  $('authState').textContent =
    `${a.loggedIn ? '有令牌' : '没有令牌'} · ${a.hasPassword ? '存了密码' : '没存密码'}` +
    `${a.username ? ' · 账号 ' + a.username : ''}（账号密码选填）`;

  const up = (d.cache && d.cache.tables && d.cache.tables.upstream) || {};
  const cap = up.maxBytes > 0 ? `${fmtMB(up.maxBytes)} MB` : '不限';
  const ttl = c.ttlMinutes > 0 ? `${c.ttlMinutes} 分钟` : '不缓存';
  $('cacheState').textContent =
    `已用 ${fmtMB(d.cache && d.cache.bytes)} MB / 上限 ${cap} · ${(d.cache && d.cache.rows) || 0} 条 · 有效期 ${ttl}`;

  $('where').textContent =
    `站点 ${(d.sites || []).map((x) => x.key).join('、') || ''} · 插件 ${(d.plugin && d.plugin.name) || ''} ${(d.plugin && d.plugin.version) || ''}`;
}

async function load() {
  try {
    paintState(await call('/state'));
  } catch (e) {
    say('读不到状态：' + e.message, true);
  }
}

/* ---------------- 事件接线 ---------------- */

$('siteSave').addEventListener('click', async (e) => {
  const base = $('alistBase').value.trim();
  if (!base) {
    say('请先填小雅 Alist 基地址（如 http://192.168.8.1:5245）', true);
    return;
  }
  e.target.disabled = true;
  try {
    paintState(await call('/settings', { method: 'POST', body: { alistBase: base } }));
    say('设置已保存');
  } catch (err) {
    say('保存失败：' + err.message, true);
  }
  e.target.disabled = false;
});

$('credSave').addEventListener('click', async (e) => {
  e.target.disabled = true;
  try {
    /* 密码只在填了的时候才发 —— 留空表示不动已保存的那份 */
    const body = { username: $('username').value };
    if ($('password').value.trim()) body.password = $('password').value;
    paintState(await call('/credentials', { method: 'POST', body }));
    $('password').value = '';
    say('凭据已保存');
  } catch (err) {
    say('保存失败：' + err.message, true);
  }
  e.target.disabled = false;
});

$('login').addEventListener('click', async (e) => {
  e.target.disabled = true;
  e.target.textContent = '登录中…';
  try {
    paintState(await call('/login', { method: 'POST' }));
    say('登录成功');
  } catch (err) {
    say('登录失败：' + err.message, true);
  }
  e.target.disabled = false;
  e.target.textContent = '登录一下';
});

$('logout').addEventListener('click', async (e) => {
  if (!window.confirm('清掉插件里保存的令牌？（账号密码保留）')) return;
  e.target.disabled = true;
  try {
    paintState(await call('/logout', { method: 'POST' }));
    say('本地登录态已清掉');
  } catch (err) {
    say('操作失败：' + err.message, true);
  }
  e.target.disabled = false;
});

$('test').addEventListener('click', async (e) => {
  e.target.disabled = true;
  e.target.textContent = '自检中…';
  show('testResult', '');
  try {
    const d = await call('/test', {
      method: 'POST',
      body: { alistBase: $('alistBase').value, wd: $('testWd').value },
    });
    const r = d.result || {};
    const line = (label, x, extra) => {
      if (!x) return `${label}：未检测`;
      if (!x.ok) return `${label}：失败 · ${x.error || '未知原因'}`;
      const head = `${label}：${x.ms} ms · ${x.count} 条`;
      const top = x.top && x.top.length ? `\n  ${x.top.join(' | ')}` : '';
      return head + top + (extra || '');
    };
    show(
      'testResult',
      [
        `地址：${r.base || ''}`,
        line('列根目录', r.root),
        line(`搜索「${r.wd || ''}」`, r.search),
        `账号：${r.auth && r.auth.username ? r.auth.username : '（匿名）'}`,
      ].join('\n')
    );
    const ok = !!(r.root && r.root.ok) && !!(r.search && r.search.ok);
    say(ok ? '自检通过' : '自检未全部通过', !ok);
    await load();
  } catch (err) {
    say('自检失败：' + err.message, true);
  }
  e.target.disabled = false;
  e.target.textContent = '自检';
});

$('cacheSave').addEventListener('click', async (e) => {
  e.target.disabled = true;
  try {
    await call('/cache/settings', {
      method: 'POST',
      body: { cacheTtlMinutes: Number($('cacheTtl').value), cacheMaxMB: Number($('cacheMax').value) },
    });
    say('缓存设置已保存');
  } catch (err) {
    say('保存失败：' + err.message, true);
  }
  e.target.disabled = false;
  await load();
});

$('cacheReload').addEventListener('click', async () => {
  try {
    await load();
    say('缓存用量已刷新');
  } catch (err) {
    say('刷新失败：' + err.message, true);
  }
});

$('cacheClear').addEventListener('click', async (e) => {
  if (!window.confirm('清空缓存？下次搜索会重新打小雅。')) return;
  e.target.disabled = true;
  try {
    await call('/cache/clear', { method: 'POST' });
    say('缓存已清空');
  } catch (err) {
    say('清空失败：' + err.message, true);
  }
  e.target.disabled = false;
  await load();
});

load();
