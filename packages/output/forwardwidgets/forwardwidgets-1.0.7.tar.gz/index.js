'use strict';
/**
 * ForwardWidgets 输出插件 · 入口
 *
 * 它自己**不产出任何媒体数据**。全部数据都经反向通道 `ctx.hostCall` 找面板要：
 *
 *   home.plugins / home.rows / home.run   读某个首页插件的行清单与行结果
 *   agg.search / agg.detail / agg.play    读聚合层（搜索 / 详情 / 播放地址）
 *
 * 对外（在 Forward 播放器里跑）只暴露两条 ingress（见 plugin.json）：
 *
 *   GET  /widget.js     匿名公开 —— 给 Forward 下载的模块代码（装 Widget 时还没令牌，
 *                       存在"先有鸡还是先有蛋"，所以这条必须免鉴权；令牌不写进代码里）
 *   其余 /api/**        要外部访问令牌 —— 面板网关验过才会把请求转到这里，
 *                       本插件不再自己验票（网关转发来的都视为已验）。
 *
 * 设计约束：
 *   · widget.js 每次请求**现生成**（行清单来自设置页选定的首页插件，见 lib/settings.js），不缓存到盘；
 *   · 生成时不带任何秘密：面板地址只给一个"可达时"的默认值，令牌始终由用户手填；
 *   · 返回给网关的形状与其他插件一致：`{ status?, body, contentType? }`。
 */
const fs = require('fs');
const path = require('path');
const pkg = require('./plugin.json');
const settings = require('./lib/settings');

const RUNTIME_FILE = path.join(__dirname, 'lib', 'widget-runtime.js');

/** hostCall 失败码 → HTTP 状态：入参类问题 400，取不到上游 502，超时 504，其余 500 */
function statusOf(code) {
  if (code === 'BAD_INPUT' || code === 'NO_DOMAIN' || code === 'NO_SITE' || code === 'NO_SOURCE') return 400;
  if (code === 'TIMEOUT') return 504;
  if (code === 'NO_HOSTCALL' || code === 'HOSTCALL_ERROR' || code === 'PLUGIN_ERROR' || code === 'AGG_ERROR') return 502;
  return 502;
}

async function hostCallOrResponse(ctx, target, action, args) {
  try {
    const value = await ctx.hostCall(target, action, args || {});
    return { ok: true, value };
  } catch (e) {
    return {
      ok: false,
      response: {
        status: statusOf(e && e.code),
        body: { error: { code: (e && e.code) || 'UPSTREAM_ERROR', message: (e && e.message) || String(e) } },
      },
    };
  }
}

/* ------------------------------------------------------- widget.js 生成 */

/**
 * 首页插件选取：设置页选的 → 第一个启用且在跑的 → 第一个（哪怕没在跑，
 * 至少让模块列表先出来；真正翻页时上游会如实报错）。
 */
async function pickHomePlugin(ctx, wantedId) {
  const r = await hostCallOrResponse(ctx, 'home', 'plugins', {});
  if (!r.ok) return { error: r.response };
  const plugins = ((r.value && r.value.plugins) || []).filter((p) => p.type !== 'output');
  const wanted = String(wantedId || '').trim();
  const hit = (wanted && plugins.find((p) => p.id === wanted))
    || plugins.find((p) => p.enabled && p.running)
    || plugins[0]
    || null;
  return { plugin: hit, plugins };
}

/**
 * 拼 widget.js。形状严格照 ForwardWidgets 规范（见上游 widgets/demo.js）：
 *   顶层 WidgetMetadata（globalParams / search / modules）
 *   顶层 loadDetail(link)
 *   每个榜单行一个 list 模块（不写 type，params 是 page）
 *   一个 type:'stream' 的 loadResource 模块
 * 具体逻辑全在 lib/widget-runtime.js；这里只注入三份"生成时就定死"的常量
 * （首页插件 id、聚合域 id、元数据）。
 */
async function buildWidget(args, ctx) {
  settings.bind(ctx && ctx.dataDir);
  const cfg = settings.read();
  const picked = await pickHomePlugin(ctx, cfg.home);
  if (picked.error) {
    // 连首页插件清单都拿不到时不 500：仍然吐模块（只有搜索能⽤），并把原因写进默认值提示
    picked.plugin = null;
  }

  let rows = [];
  if (picked.plugin) {
    const rr = await hostCallOrResponse(ctx, 'home', 'rows', { pluginId: picked.plugin.id });
    if (rr.ok) rows = (rr.value && rr.value.rows) || [];
  }

  /* 面板地址默认值：请求 Host 是回环地址时不给默认（手机上的 Forward 够不到它，
   * 留空强制用户填局域网地址）；反向代理来的 https 也能据此给对协议。 */
  const host = String(args.host || '');
  const proto = String(args.proto || 'http');
  const isLoopback = /^(localhost|127\.)/i.test(host);
  const defaultPanel = host && !isLoopback ? `${proto}://${host}` : '';

  const mbRows = rows.map((row, i) => ({
    i,
    pluginId: picked.plugin.id,
    rowId: String(row.id),
    title: String(row.title || row.id),
    fn: 'mbLoadRow_' + i,
  }));

  const modules = mbRows.map((r) => ({
    id: 'row_' + r.i,
    title: r.title,
    description: `媒体桥首页行「${r.title}」`,
    functionName: r.fn,
    requiresWebView: false,
    cacheDuration: 300,
    params: [{ name: 'page', title: '页码', type: 'page', value: '1' }],
  }));
  modules.push({
    id: 'loadResource',
    title: '加载播放资源',
    description: '按条目定位片源并解析可播放地址（网盘类源到播放时才提交离线下载）',
    functionName: 'mbLoadResource',
    type: 'stream',
    params: [],
    cacheDuration: 0,
  });

  const meta = {
    id: 'mediabridge.fw',
    title: picked.plugin ? `媒体桥 · ${picked.plugin.name || picked.plugin.id}` : '媒体桥',
    version: pkg.version,
    requiredVersion: '0.0.1',
    icon: '',
    description: picked.plugin
      ? `媒体桥面板输出（首页：${picked.plugin.name || picked.plugin.id}，${mbRows.length} 个榜单）。需在全局参数填面板地址与访问令牌。`
      : '媒体桥面板输出（当前没有可用首页插件，仅搜索可用）。需在全局参数填面板地址与访问令牌。',
    author: 'media-bridge',
    site: '',
    detailCacheDuration: 300,
    globalParams: [
      { name: 'panel', title: '面板地址', type: 'input', value: defaultPanel },
      { name: 'token', title: '外部访问令牌', type: 'input', value: '' },
    ],
    search: {
      title: '搜索媒体桥',
      functionName: 'mbSearch',
      params: [
        { name: 'keyword', title: '关键词', type: 'input', value: '' },
        { name: 'page', title: '页码', type: 'page', value: '1' },
      ],
    },
    modules,
  };

  /* 每个行模块一个具名入口（Forward 按 functionName 找全局函数）。
   * 行身份编进闭包，不依赖运行时 params 里有没有模块 id。 */
  const rowBindings = mbRows
    .map((r) => `function ${r.fn}(params){ return mbLoadRow(${JSON.stringify({ pluginId: r.pluginId, rowId: r.rowId, title: r.title })}, params); }`)
    .join('\n');

  const runtime = fs.readFileSync(RUNTIME_FILE, 'utf8');
  const generated = [
    '/* 本文件由 media-bridge forwardwidgets 输出插件自动生成，请勿手改。',
    ` * 面板版本 ${pkg.version}；生成时间 ${new Date().toISOString()}；首页插件 ${picked.plugin ? picked.plugin.id : '(无)'} */`,
    `var MB_META = ${JSON.stringify(meta)};`,
    `var WidgetMetadata = MB_META;`,
    `var MB_HOME_PLUGIN = ${JSON.stringify(picked.plugin ? picked.plugin.id : '')};`,
    `var MB_DOMAINS = ${JSON.stringify(cfg.domains.length ? cfg.domains : [settings.DEFAULT_DOMAIN])};`,
    '',
    runtime,
    '',
    '/* ---- 榜单行模块入口（生成时绑定行身份）---- */',
    rowBindings,
    '',
  ].join('\n');

  return {
    status: 200,
    contentType: 'application/javascript; charset=utf-8',
    body: generated,
  };
}

/* ------------------------------------------------------------- 路由 */

function parseBody(args) {
  if (!args.body) return {};
  try {
    return JSON.parse(args.body);
  } catch {
    return null;
  }
}

const actions = {
  /** 自检/信息（面板插件列表会调一下） */
  async info() {
    return { ok: true, id: pkg.id, version: pkg.version };
  },

  /**
   * webui 后端：面板把 `/api/plugins/output/forwardwidgets/api/**` 原样转来。
   * 令牌校验在面板网关（ingress）做，到这里的 token 路径请求都已验过票。
   */
  async http(args = {}, ctx) {
    const method = String(args.method || 'GET').toUpperCase();
    const p = String(args.path || '/').split('?')[0].replace(/\/+$/, '') || '/';
    const q = args.query || {};
    const body = parseBody(args);
    if (body === null) return { status: 400, body: { error: { code: 'BAD_JSON', message: '请求体不是 JSON' } } };

    /* 唯一的匿名入口（plugin.json ingress.public） */
    if (method === 'GET' && p === '/widget.js') return buildWidget(args, ctx);

    /* ---------------- 以下都在 ingress.token 范围内（验外部令牌或登录 cookie） ---------------- */

    settings.bind(ctx && ctx.dataDir);

    /** 设置页首屏：当前选择 + 可选的首页插件清单（聚合域由页面自己读 /api/plugins 的元数据插件） */
    if (method === 'GET' && p === '/state') {
      const r = await hostCallOrResponse(ctx, 'home', 'plugins', {});
      const plugins = r.ok ? ((r.value && r.value.plugins) || []) : [];
      return {
        body: {
          plugin: { id: pkg.id, name: pkg.name, version: pkg.version },
          settings: settings.read(),
          homes: plugins
            .filter((x) => x.type !== 'output')
            .map((x) => ({ id: String(x.id), name: String(x.name || x.id), enabled: !!x.enabled, running: !!x.running })),
          /* 取不到清单时如实说明，设置页内联显示 */
          error: r.ok ? '' : ((r.response.body.error && r.response.body.error.message) || '取首页插件清单失败'),
        },
      };
    }

    /** 保存首页插件 / 聚合域（只认这两个键，其余一律丢弃；域是数组、可多选） */
    if (method === 'POST' && p === '/settings') {
      const cur = settings.read();
      return {
        body: {
          ok: true,
          settings: settings.write({
            home: body.home !== undefined ? String(body.home || '').trim() : cur.home,
            /* 不是数组就当没传（宁可保留旧值，也不把配置清空） */
            domains: Array.isArray(body.domains) ? body.domains : cur.domains,
          }),
        },
      };
    }

    if (method === 'GET' && p === '/home/plugins') {
      const r = await hostCallOrResponse(ctx, 'home', 'plugins', {});
      return r.ok ? { body: r.value } : r.response;
    }

    if (method === 'GET' && p === '/home/rows') {
      const r = await hostCallOrResponse(ctx, 'home', 'rows', { pluginId: String(q.pluginId || q.home || '').trim() });
      return r.ok ? { body: r.value } : r.response;
    }

    if (method === 'POST' && p === '/home/run') {
      const r = await hostCallOrResponse(ctx, 'home', 'run', {
        pluginId: String(body.pluginId || '').trim(),
        rowId: String(body.rowId || '').trim(),
        startIndex: Number(body.startIndex) || 0,
        limit: Number(body.limit) || 0,
      });
      return r.ok ? { body: r.value } : r.response;
    }

    if (method === 'POST' && p === '/agg/search') {
      const r = await hostCallOrResponse(ctx, 'agg', 'search', body);
      return r.ok ? { body: r.value } : r.response;
    }

    if (method === 'POST' && p === '/agg/detail') {
      const r = await hostCallOrResponse(ctx, 'agg', 'detail', body);
      return r.ok ? { body: r.value } : r.response;
    }

    if (method === 'POST' && p === '/agg/play') {
      const r = await hostCallOrResponse(ctx, 'agg', 'play', body);
      return r.ok ? { body: r.value } : r.response;
    }

    return { status: 404, body: { error: { code: 'NOT_FOUND', message: `没有这个路径：${method} ${p}` } } };
  },
};

module.exports = { actions };
