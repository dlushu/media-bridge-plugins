'use strict';
/**
 * 猫爪源-网盘自解析版 · 入口（动作层）
 *
 * 这是 `catpaw` 那支的**变体**。契约见 docs/plugin-contract.md 第五节，动作名与形状与它一致：
 *
 *   sites   站点清单     —            所有实例的站点（摊平后每项带它属于哪个实例）
 *   search  候选         {source,key,wd,page}      一层/两层式站点都走它
 *   detail  取播放项     {source,key,id}           站点的详情 → 线路与选集
 *   play    解析地址     {source,key,flag,id}      一次播放 → 真实地址
 *   probe   站点测速     {source,key,wd}           体检口径的一发（不重试、不看内容）
 *   http    webui 转发   {method,path,query,body}  插件自己设置页的后端
 *
 * **`source` 是实例 id**（本插件内部的事，面板不知道那背后的地址与端口）。
 *
 * ## 与 `catpaw` 那支的差别（也是这一支存在的理由）
 *
 * 两支**自己托管实例**那一套是同一份：自己存清单（`lib/store.js`）、自己下包起进程
 * （`lib/fetcher.js` + `lib/runner.js`）、自己管自动更新（`lib/auto-update.js`）、
 * 自己带缓存（`lib/cache.js`）。唯一的差别在**播放**这一步：
 *
 *   · 站点清单 / 候选 / 取播放项：照旧打实例（`lib/instance.js`）；
 *   · **线路由本插件自己出**：`detail` 阶段拿到分享坐标后，**不照抄实例给的那几条线路**，
 *     而是按 driver 的**档位声明**展开（夸克 / UC 都是「原画」+「转码」两条，见各自 driver 的 `LINES`）。
 *     实测源站会把同一份分享拆成「夸克原画 / 夸克极速」两条同名线路，
 *     而它们的区别正是本插件的两个档位 —— 与其照抄一堆重名线路，不如自己按档位出。
 *   · 解析地址：**只在插件层本地解析**（现在有夸克 / UC / 115 / 百度 / 迅雷 / 阿里云盘 / 天翼云盘 / PikPak / 123 云盘 /
 *     移动云盘 / 光鸭 十一家，见 `lib/netdisk/`），自己换直连地址，不绕实例的 `/proxy`，**也不落回实例的 `/play`**。
 *   · 登录态：**由插件自己收**（设置页）。夸克 / UC / 115 / 百度 / 阿里云盘 / 光鸭 可以直接点「扫码登录」在设置页扫
 *     （`QR_PROVIDERS` + `GET /qrcode`、`GET /qrcode/status`，实现见各 driver 的 `qrStart` / `qrPoll`）；
 *     夸克与 UC 的接口只给登录短链、不给图片，二维码由 `lib/qr.js` 自己编。迅雷走账号密码 OAuth、
 *     天翼收 Cookie 或账密登录、123 收 JWT、PikPak 走**登录态转存链路**（refresh_token 或账号密码，必须登录）、
 *     移动云盘**全程匿名**一份凭据都不要、光鸭分享列目录匿名可读但取地址要转存自有盘（必须登录）。
 *
 * ⚠️ **"不落回实例"是刻意的**：实例侧的网盘解析要它自己那份登录态（配中心登录），
 * 与插件设置页那份网盘凭据是两回事；落回只会拿到 `HTTP 500`，然后被面板记成"解析失败"，
 * 看着像插件坏了。所以口径是**没有就是没有**：
 *   · 分享链 + 插件解析得了（上面十一家）→ 由插件出线路、出 CDN 直连地址（线路按各 driver 声明走面板中继或直连）；
 *   · 分享链 + 插件解析不了（天翼的秒传 / 阿里秒传115 这类特例、以及未铺的网盘）→ `detail` 阶段就**把这条线路过滤掉**，
 *     `play` 若还是被点到则如实报 `NO_RESOLVER`；
 *   · 非分享链 → 集 id 自己就是站点给的直链就原样交出去，交不出就没有。
 *
 * 还剩"最后一公里"：本地部署的实例/上游回的是回环地址时，换成客户端访问面板用的域名
 * （`lib/address.js`；只在该改写时才改，真直链与非回环地址原样回）。
 */
const protocol = require('./lib/protocol');
const store = require('./lib/store');
const cache = require('./lib/cache');
const runner = require('./lib/runner');
const fetcher = require('./lib/fetcher');
const autoUpdate = require('./lib/auto-update');
const instance = require('./lib/instance');
const netdisk = require('./lib/netdisk');
const quark = require('./lib/netdisk/quark');
const uc = require('./lib/netdisk/uc');
const pan115 = require('./lib/netdisk/pan115');
const ali = require('./lib/netdisk/ali');
const pikpak = require('./lib/netdisk/pikpak');
const baidu = require('./lib/netdisk/baidu');
const guangya = require('./lib/netdisk/guangya');
const { buildDetail, encodeRef, decodeRef } = require('./lib/play-items');
const { toClientReachable } = require('./lib/address');

const MANIFEST = require('./plugin.json');
const PLUGIN_ID = MANIFEST.id;

/**
 * 每个 driver 要的**登录态**（本地解析网盘分享链用）—— 键就是分发表里的 driver 名（`netdisk.keyOf`）。
 * 新铺一家在这里加一条；认不出（理论上不会）就退回夸克那份，绝不"猜一份空的"。
 */
const CREDENTIALS = {
  quark: () => ({ cookie: store.quarkCookie() }),
  uc: () => ({ cookie: store.ucCookie(), token: store.ucToken(), ut: store.ucUt() }),
  pan115: () => ({ cookie: store.pan115Cookie() }),
  baidu: () => ({ cookie: store.baiduCookie() }),
  /* 迅雷没有 Cookie 这条路：账号密码 + 可选的 refresh_token；登录成功回调把新 token 写回 */
  xunlei: () => Object.assign(store.xunleiCred(), { onRefreshToken: (rt) => store.setXunleiRefreshToken(rt) }),
  /* 阿里云盘也没有 Cookie：官方口径就是 OAuth 令牌，refresh_token 只在 access_token 空时续一次 */
  ali: () => store.aliCred(),
  tianyi: () => ({ cookie: store.tianyiCred().cookie }),
  /* PikPak 走**登录态转存链路**（`share/restore` → 自有盘详情 → 候选探测）：refresh_token 优先，
   * 退账号密码；续期拿到的新 refresh_token 由 `onRefresh` 写回设置页 */
  pikpak: () => Object.assign(store.pikpakCred(), { onRefresh: (c) => store.setPikpakCred({ refreshToken: c.refreshToken }) }),
  /* 123 云盘：`123无限` 档匿名就出，只有 `P123` 档要这份 JWT */
  pan123: () => store.pan123Cred(),
  /* 移动云盘（139）分享链**全程匿名**，一份凭据都不要（签名是接口要求，不是登录态） */
  yidong: () => ({}),
  /* 光鸭：分享列目录匿名就出，但**取地址要转存自有盘**，所以必须登录（设备码扫码换来的令牌） */
  guangya: () => Object.assign(store.guangyaCred(), { onRefresh: (c) => store.setGuangyaCred(c) }),
};
const credentialsFor = (driver) => (CREDENTIALS[netdisk.keyOf(driver)] || CREDENTIALS.quark)();

/**
 * 扫码登录：provider → 实现（**别把某一家写死进动作层**）。
 * 每个 provider 给三件事：取码 `start(timeout)`、轮询 `poll(session, timeout)`、落库 `save(cookie)`。
 * 会话只放内存（带 TTL，见 `qrPurge`），不落盘 —— 扫码是短时交互，重启就没意义了。
 */
const QR_PROVIDERS = {
  quark: {
    label: '夸克',
    start: (timeout) => quark.qrStart(timeout),
    poll: (session, timeout) => quark.qrPoll(session, timeout),
    save: (cookie) => store.setQuarkCookie(cookie),
  },
  uc: {
    label: 'UC',
    start: (timeout) => uc.qrStart(timeout),
    poll: (session, timeout) => uc.qrPoll(session, timeout),
    save: (cookie) => store.setUcCookie(cookie),
  },
  '115': {
    label: '115',
    start: (timeout) => pan115.qrStart(timeout),
    poll: (session, timeout) => pan115.qrPoll(session, timeout),
    save: (cookie) => store.setPan115Cookie(cookie),
  },
  baidu: {
    label: '百度',
    start: (timeout) => baidu.qrStart(timeout),
    poll: (session, timeout) => baidu.qrPoll(session, timeout),
    save: (cookie) => store.setBaiduCookie(cookie),
  },
  /* 阿里 / PikPak 扫到的不是 Cookie 而是令牌：`poll` 回的 `cookie` 位放的是令牌，`save` 各存各的 */
  ali: {
    label: '阿里云盘',
    start: (timeout) => ali.qrStart(timeout),
    poll: (session, timeout) => ali.qrPoll(session, timeout),
    save: (refreshToken) => store.setAliCred({ refreshToken }),
  },
  pikpak: {
    label: 'PikPak',
    start: (timeout) => pikpak.qrStart(timeout),
    poll: (session, timeout) => pikpak.qrPoll(session, timeout),
    save: (refreshToken) => store.setPikpakCred({ refreshToken }),
  },
  /* 光鸭走**设备码**：`poll` 确认时把 `{accessToken, refreshToken, deviceId}` 编成 JSON 串传过来 */
  guangya: {
    label: '光鸭',
    start: (timeout) => guangya.qrStart(timeout),
    poll: (session, timeout) => guangya.qrPoll(session, timeout),
    save: (payload) => {
      let c = {};
      try {
        c = JSON.parse(String(payload || '{}'));
      } catch {
        c = { refreshToken: String(payload || '') };
      }
      store.setGuangyaCred(c);
    },
  },
};
const QR_TTL_MS = 3 * 60 * 1000; /* 二维码有效期按 3 分钟兜底（官方约 2 分钟一扫即刷） */
const QR_SESSIONS = new Map(); /* sessionId → { provider, session, expiresAt } */
let qrSeq = 0;
function qrPurge() {
  const now = Date.now();
  for (const [id, rec] of QR_SESSIONS) if (rec.expiresAt <= now) QR_SESSIONS.delete(id);
}
function qrNewId() {
  qrSeq += 1;
  return `q${Date.now().toString(36)}${qrSeq.toString(36)}`;
}

/** 把 `path` 上的查询串与 `args.query` 合成一个对象（两种传法都认） */
function queryOf(path, query) {
  const out = Object.assign({}, query && typeof query === 'object' ? query : {});
  const i = String(path || '').indexOf('?');
  if (i < 0) return out;
  for (const [k, v] of new URLSearchParams(String(path).slice(i + 1))) out[k] = v;
  return out;
}

/** 拼缓存键的一段：`undefined` / `null` 归成空串（不写进 `undefined` 那种字面量） */
const seg = (v) => (v === undefined || v === null ? '' : String(v));

/** 超时 → 让面板那边认出是超时（它与面板约定的判据是 `AbortError`） */
function failFrom(e) {
  if (e && e.name === 'AbortError') return { code: 'TIMEOUT', message: '请求超时' };
  return { code: (e && e.code) || 'UPSTREAM', message: (e && e.message) || String(e) };
}

/**
 * 把「线路 → 选集」收拾成**本插件自己出的线路**。
 *
 * 判据只有一条 —— **这条线路拿到的集 id 是不是"网盘分享坐标"**（`netdisk.classifyCoord`）：
 *
 *   · **不是分享链** → 站点自己给的线路，原样保留（`playVia: 'client'`，裸连可播）；
 *   · **是分享链 + 插件解析得了**（夸克 / UC / 115 / 百度 / 迅雷 / 阿里云盘 / 天翼云盘 / PikPak /
 *     123 云盘 / 移动云盘 / 光鸭云盘）→ **线路由本插件自己出**：按 driver 的档位声明
 *     （`netdisk.linesFor`）把这一条**展开成 N 条**（如 `夸克原画` / `夸克转码`、`UC原画` / `UC转码`、
 *     `百度原画` / `百度无限`、`123云盘123无限` / `123云盘P123`、`115原画`、`迅雷原画`），
 *     每条把档位 `key` 写进 `ref` 的 `q` 字段，`play` 再据它分派到 `resolve` 的 `quality`。
 *     每条线路的 `playVia` **由档位自己声明**（`band.playVia`）：夸克（原画 / 极速转码）/ UC / 百度 / 迅雷
 *     标 `proxy`（CDN 认头，夸克实测直链不带 Cookie 一律 412）；
 *     115 / 天翼 / 阿里 / PikPak / 光鸭 / 123无限 / 移动云盘标 `client`
 *     （出口是带时效签名、播放不要鉴权头的 CDN 直链，裸连可播）。
 *   · **是分享链 + 插件没铺这家 driver**（引擎有、本插件没对等实现的那几家）→ **摘掉**（"没有就是没有"）。
 *     留着也播不动：`play` 只会如实报 `NO_RESOLVER`。与其让客户端挂一条点了就 502 的线路，不如这里就摘掉。
 *     判据与 `play` 同一条（`netdisk.linesFor`），不会出现"留着却播得动 / 摘掉却播得动"的错位。
 *
 * ⚠️ **按"集 id"判、不按"站点 key"判**（原先按站点 key 认 provider，实测是错的）：
 * 实测同一份源（9280）把网盘线路挂在 `video` 组的站点下（`nodejs_huajuan` 这种，key 里根本没有
 * provider 字样），按站点 key 判会把 `夸克原画` 这类线路**全标成 client**。分享链这件事，看线路
 * 自己拿到的坐标最准。
 *
 * ⚠️ **同一份分享只展开一次**（按 `shareKeyOf` 的分享身份去重，坐标剔掉 `mode` / `quality` 后比）：
 * 实测源站常把同一份分享拆成两条线路、坐标只差 `mode` / `quality`（不逐字相同）—— 按集 id 去重会漏掉，
 * 于是展开成 4 条、还得给重名的加 `(2)` 后缀。
 *
 * 这是**声明性标注**不是探测结果（`detail` 阶段还没有地址可测），所以只能按"这条线路是什么"写死。
 * 标 `proxy` 的代价是多走一次面板中继，标错 `client` 的代价是客户端直接播不动 —— 往严的标。
 */
function expandLines(detail, siteKey) {
  if (!detail || !Array.isArray(detail.lines)) return;
  const keep = [];
  const usedNames = new Set();
  const seenShares = new Set();
  let dropped = 0;
  let expanded = 0;

  /* 线路名去重：同一份源里若真有两条**不同**的夸克分享，展开后名字会撞，给后来者加序号 */
  const uniqName = (base) => {
    let name = base;
    let n = 2;
    while (usedNames.has(name)) {
      name = `${base} (${n})`;
      n += 1;
    }
    usedNames.add(name);
    return name;
  };

  /* 克隆一条线路并换掉线路名 / 档位 / 取流方式：`ref` 是插件自己的东西，解出来改 `f`（跟线路名一致）、加 `q` 再编回去 */
  const withBand = (line, flag, q, playVia) => {
    const fix = (item) => {
      if (!item) return item;
      const o = decodeRef(PLUGIN_ID, item.ref);
      return o
        ? Object.assign({}, item, { ref: encodeRef(PLUGIN_ID, Object.assign({}, o, { f: flag, q })) })
        : item;
    };
    const out = Object.assign({}, line, { flag, playVia: playVia || 'proxy' });
    if (Array.isArray(line.items)) out.items = line.items.map(fix);
    if (line.target) out.target = fix(line.target);
    if (Array.isArray(out.items) && out.items.length) out.target = out.items[0];
    return out;
  };

  for (const line of detail.lines) {
    const first = (line.episodes || [])[0];
    const rawId = first ? String(first.id || '') : '';
    /* 识别坐标要带上线路名：`!vod1!` / `*` 裸拼数组都不带 provider，
       站点挂在聚合站（key 无网盘字样）时，靠「夸克原画」「UC无限」「百度2」这类线路名兜底分派 */
    const coord = rawId ? netdisk.classifyCoord(rawId, { flag: line.flag, siteKey }) : null;

    if (!coord) {
      line.playVia = 'client';
      if (!usedNames.has(line.flag)) usedNames.add(line.flag);
      keep.push(line);
      continue;
    }

    /* provider 三级回退：坐标自带 → 站点 key → 线路名（见 netdisk.resolverFor） */
    const driver = netdisk.resolverFor(coord, siteKey, line.flag);
    const packs = netdisk.linesFor(driver);
    if (!packs) {
      dropped += 1; // 分享链但插件解析不了：摘掉（见上面那段）
      continue;
    }
    /* 同一份分享只展开一次：按**分享身份**去重（坐标剔掉 `mode` / `quality` 后比，见 `shareKeyOf`） */
    const shareKey = netdisk.shareKeyOf(coord, siteKey);
    if (seenShares.has(shareKey)) continue;
    seenShares.add(shareKey);

    for (const band of packs.bands) {
      const name = [packs.provider, band.label].filter(Boolean).join('');
      keep.push(withBand(line, uniqName(name || band.key), band.key, band.playVia));
    }
    expanded += 1;
  }

  if (!dropped && !expanded) return;

  detail.lines = keep;
  detail.lineCount = keep.length;
  /* 被摘掉 / 被展开的那条可能正是 `detail.target` 所在线路 —— 重新挑一条，别把 target 指向已摘的线路 */
  detail.target = (keep.find((l) => l.target) || {}).target || null;
  if (dropped) {
    detail.droppedLines = dropped;
    detail.dropNote = `已过滤 ${dropped} 条本插件解析不了的分享线路（现在只支持 ${netdisk.labelList()}）`;
  }
  if (expanded) {
    detail.lineNote = `${expanded} 条分享线路由本插件自己出（按档位展开，如夸克的原画 / 转码）`;
  }
}

/** 一组的站点数（自检回执里给人看） */
function groupCounts(sites) {
  const out = {};
  for (const s of sites || []) {
    const g = String((s && s.group) || 'other');
    out[g] = (out[g] || 0) + 1;
  }
  return out;
}

/* ============================================================
 * 动作
 * ============================================================ */

/**
 * 申报取数式样（契约字段 `directLines`，缺省按两层式）：
 * `filterable`（要站内筛选）/ `indexs`（转搜）任一为真，搜索只出候选、线路要再取详情 —— 两层式；
 * 两个都没有的直查站，搜索行里已内嵌播放地址 —— 一层式。字段只在这里翻译一次。
 */
function markLayer(site) {
  site.directLines = !(site.filterable || site.indexs);
  return site;
}

const actions = {
  /**
   * 站点清单 —— 静态声明"这个插件现在有哪些站点"。
   * 返回 `{ sources, sites }`：`sources` 是实例一行一个（含运行态与端口，设置页与面板日志要用），
   * `sites` 只收**取到站点表**的实例的站点，每项带上它属于哪个实例。
   */
  async sites(args, ctx) {
    const fresh = args && args.fresh === true;
    const rows = await Promise.all(
      instance.list().map(async (one) => {
        const t0 = Date.now();
        const st = instance.stateOf(one);
        const row = {
          id: one.id,
          name: one.name || one.url || one.id,
          url: instance.baseUrlOf(one),
          sourceUrl: one.url,
          mode: one.mode,
          port: st.port || null,
          status: st.status,
          running: st.status === 'running',
          ok: false,
          ms: 0,
          siteCount: 0,
          error: null,
        };
        let sites = [];
        if (!row.url) {
          row.error = one.mode === 'local' ? '这个实例没在运行（到插件设置页启动它）' : '没有地址';
        } else {
          try {
            const map = await instance.sitesOf(one, { fresh });
            sites = Array.from(map.values()).map((x) => markLayer(Object.assign({}, x, { source: one.id })));
            row.ok = true;
            row.siteCount = sites.length;
          } catch (e) {
            row.error = e && e.name === 'AbortError' ? '请求超时' : String((e && e.message) || e);
          }
        }
        row.ms = Date.now() - t0;
        return { row, sites };
      })
    );
    const out = { sources: rows.map((x) => x.row), sites: rows.flatMap((x) => x.sites) };
    if (ctx) ctx.log(`站点清单：${out.sources.length} 个实例 → ${out.sites.length} 个站点`);
    return out;
  },

  /** 候选 —— 一个站的搜索（两层式站点的第一步）。**插件自己那份缓存的第一个落点** */
  async search(args, ctx) {
    const one = instance.need(args.source);
    const site = await instance.needSite(one, args.key);
    const timeoutMs = Math.max(1000, Number(args.timeoutMs) || 5000);
    const key = [one.id, site.key, 'search', seg(args.wd), seg(args.page)].join('|');
    const hit = cache.get('upstream', key);
    if (hit) {
      if (ctx) ctx.log(`插件自己的缓存命中：${one.id} / ${site.key} 的搜索「${seg(args.wd)}」第 ${seg(args.page) || 1} 页 —— 直接回缓存，不打上游`);
      return Object.assign({}, hit, { cached: true, site: site.key, source: one.id });
    }
    try {
      const initCalled = await instance.ensureInit(one, site, timeoutMs);
      const r = await instance.postSite(one, site.api, '/search', { wd: args.wd, page: args.page }, timeoutMs);
      if (r.ok) cache.put('upstream', key, r, cache.limits().ttlMs);
      if (initCalled && ctx) ctx.log(`首次搜索前打了 init：${one.id} / ${site.key}`);
      return Object.assign(r, { initCalled, site: site.key, source: one.id });
    } catch (e) {
      return { error: failFrom(e), source: one.id, site: site.key };
    }
  },

  /**
   * 取播放项 —— 一个站的详情：**自己解析**成「线路 → 选集」，并给每个播放项编一个 `ref`。
   * 解析与 `ref` 编法都是照抄 `catpaw` 那一份（`lib/play-items.js`）；这里多两步：
   * ① 标 `playVia`；② **分享链的线路由本插件自己出**（按档位展开，见 `expandLines`）。
   */
  async detail(args, ctx) {
    const one = instance.need(args.source);
    const site = await instance.needSite(one, args.key);
    const timeoutMs = Math.max(1000, Number(args.timeoutMs) || 10000);
    const pick = args.pick === 'items' ? 'items' : '';
    const key = [one.id, site.key, 'detail', seg(args.id), seg(args.season), seg(args.episode), pick].join('|');
    try {
      /* 缓存的是**上游原始响应** —— 命中时不打上游，但照旧重新跑一遍 `buildDetail`：
       * 它是纯函数，重建出的「线路 → 选集」与现打一次一致，`ref` 里嵌的集 id 也来自这份响应。 */
      let r = cache.get('upstream', key);
      const cached = !!r;
      if (cached) {
        if (ctx) ctx.log(`插件自己的缓存命中：${one.id} / ${site.key} 的详情 ${seg(args.id)} —— 用缓存里的原始响应重建「线路 → 选集」，不打上游`);
      } else {
        r = await instance.postSite(one, site.api, '/detail', { id: args.id }, timeoutMs);
        if (r.ok) cache.put('upstream', key, r, cache.limits().ttlMs);
      }
      const built = buildDetail(r.json, {
        pluginId: PLUGIN_ID,
        instanceId: one.id,
        siteKey: site.key,
        vodId: args.id,
        season: args.season,
        episode: args.episode,
        pick,
      });
      if (built.detail) expandLines(built.detail, site.key);
      const out = Object.assign({}, r, {
        source: one.id,
        site: site.key,
        detail: built.detail,
        detailNote: built.note,
      });
      if (cached) out.cached = true;
      return out;
    } catch (e) {
      if (ctx) ctx.log(`取播放项失败：${one.id} / ${site.key} — ${(e && e.message) || e}`);
      return { error: failFrom(e), source: one.id, site: site.key };
    }
  },

  /**
   * 解析地址 —— 拿一个 `ref` 换**客户端真能连上的地址**。**只在插件层本地解析，不落回实例 `/play`。**
   *
   * 两条路：
   *   ① 集 id 是**分享坐标** → 交给对应 driver（现在有夸克 / UC / 115 / 百度）自己换地址，
 *      档位由 `ref.q` 分派（`origin` 原画 / `transcode` 转码，见 `expandLines`）；
 *      没有 driver（迅雷…）或解析失败 → **如实报错，不落回**（口径见文件头）。
   *   ② 集 id **不是**分享坐标 → 站点自己给的直链就原样交出去（顺带做"最后一公里"回环改写）；
   *      不是直链（拿不到地址）→ 也如实报错。
   */
  async play(args, ctx) {
    const timeoutMs = Math.max(1000, Number(args.timeoutMs) || 5000);
    const clientHost = String(args.clientHost || '');
    const o = decodeRef(PLUGIN_ID, args.ref);
    if (!o) {
      return { error: { code: 'BAD_REF', message: `认不出这个 ref：${String(args.ref || '').slice(0, 80)}` } };
    }
    let one;
    let site;
    try {
      one = instance.need(o.s);
      site = await instance.needSite(one, o.t);
    } catch (e) {
      return { error: failFrom(e) };
    }

    const raw = String(o.e || '').trim();
    /* 重新分类时带上展开后的线路名（如「夸克原画」），vod1 / star 坐标靠它兜底认 provider */
    const coord = raw ? netdisk.classifyCoord(raw, { flag: o.f, siteKey: site.key }) : null;

    /* ① 分享坐标：本地解析（这一支的存在理由） */
    if (coord) {
      const driver = netdisk.resolverFor(coord, site.key, o.f);
      if (!driver) {
        const e = new Error(
          `这条线路是 ${coord.provider || site.key} 分享链，本插件现在只本地解析 ${netdisk.labelList()}（不落回实例 /play）`
        );
        e.code = 'NO_RESOLVER';
        if (ctx) ctx.log(`解析地址失败：${o.s} / ${o.t} / ${o.f} — ${e.message}`);
        return { error: failFrom(e), source: one.id, site: site.key };
      }
      try {
        /* `o.q` 是 `detail` 展开线路时写进去的**档位**（见 `expandLines`）：
         * `origin`（缺省）= 原画，`transcode` = 转码档（各家的实现见对应 driver）。 */
        const got = await driver.resolve(coord, Object.assign({}, credentialsFor(driver), {
          /* 登录态按 provider 分派（`CREDENTIALS`）：夸克只要 cookie，UC 还要 token / ut */
          timeout: Math.max(timeoutMs, 20000),
          quality: String(o.q || 'origin'),
          /* 实例 id 带下去：driver 可能要读这个实例的 runtime KV 补字段（如百度补提取码，见 netdisk/pwd.js） */
          instanceId: one.id,
          log: (s) => ctx && ctx.log(s),
        }));
        if (ctx) ctx.log(`本地解析成功：${site.key} / ${o.f} → ${got.name || '原画'}（${got.quality || 'origin'}）`);
        return {
          ok: true,
          status: 200,
          source: one.id,
          site: site.key,
          flag: o.f,
          urls: [got.url],
          header: got.header || {},
          parse: 0,
          playVia: got.playVia || 'proxy',
          local: true,
          quality: got.quality || 'origin',
          sizeBytes: got.size || 0,
        };
      } catch (e) {
        if (ctx) ctx.log(`本地解析失败：${o.s} / ${o.t} / ${o.f} — ${(e && e.message) || e}`);
        return { error: failFrom(e), source: one.id, site: site.key };
      }
    }

    /* ② 非分享坐标：站点给的直链就交出去；交不出就没有 */
    if (/^https?:\/\//i.test(raw)) {
      const red = toClientReachable(raw, {
        clientHost,
        local: one.mode === 'local',
        port: instance.portOf(one),
      });
      if (red.note && ctx) ctx.log(`解析地址：${red.note}`);
      return {
        ok: true,
        status: 200,
        source: one.id,
        site: site.key,
        flag: o.f,
        urls: [red.url || raw],
        header: {},
        parse: 0,
        playVia: 'client',
        rewrote: red.rewrote,
      };
    }
    const e = new Error('这条线路没有可用的地址（既不是分享链、也不是直链），本插件不落回实例 /play');
    e.code = 'NO_ADDRESS';
    if (ctx) ctx.log(`解析地址失败：${o.s} / ${o.t} / ${o.f} — ${e.message}`);
    return { error: failFrom(e), source: one.id, site: site.key };
  },

  /**
   * 站点测速 —— **体检口径**的一发：只回答"通不通、多快"，不重试、不解释结果内容。
   * 与"候选"打的是同一个接口（`/search`），差别在口径：那边是业务取数、这边是量耗时。
   */
  async probe(args) {
    const one = instance.need(args.source);
    const site = await instance.needSite(one, args.key);
    const timeoutMs = Math.max(1000, Number(args.timeoutMs) || 15000);
    try {
      const initCalled = await instance.ensureInit(one, site, timeoutMs);
      const r = await instance.postSite(one, site.api, '/search', { wd: args.wd, page: '1' }, timeoutMs);
      return Object.assign(r, {
        initCalled,
        source: one.id,
        site: site.key,
        name: one.name || one.url || one.id,
      });
    } catch (e) {
      return { error: failFrom(e), source: one.id, site: site.key };
    }
  },

  /** 插件设置页的后端（面板只转发、不解释，见契约第十一节） */
  async http(args, ctx) {
    const method = String(args.method || 'GET').toUpperCase();
    const rawPath = String(args.path || '/');
    const p = rawPath.includes('?') ? rawPath.slice(0, rawPath.indexOf('?')) : rawPath;
    const q = queryOf(rawPath, args.query);
    const body = (() => {
      if (!args.body) return {};
      if (typeof args.body === 'object') return args.body;
      try {
        return JSON.parse(String(args.body));
      } catch {
        return {};
      }
    })();
    const ok = (v) => ({ status: 200, body: Object.assign({ ok: true }, v) });
    const bad = (status, message) => ({ status, body: { ok: false, error: message } });
    const quarkState = () => {
      const c = store.quarkCookie();
      return { hasCookie: !!c, cookieLength: c.length };
    };
    const ucState = () => {
      const c = store.ucCookie();
      const t = store.ucToken();
      const u = store.ucUt();
      return {
        hasCookie: !!c,
        cookieLength: c.length,
        hasToken: !!t,
        tokenLength: t.length,
        hasUt: !!u,
        utLength: u.length,
      };
    };
    const pan115State = () => {
      const c = store.pan115Cookie();
      return { hasCookie: !!c, cookieLength: c.length };
    };
    const baiduState = () => {
      const c = store.baiduCookie();
      return { hasCookie: !!c, cookieLength: c.length };
    };
    /* 迅雷回显：**不回显账号密码明文**，只说配没配、有没有可续期的 refresh_token */
    const xunleiState = () => {
      const c = store.xunleiCred();
      return { hasUsername: !!c.username, hasPassword: !!c.password, hasRefreshToken: !!c.refreshToken };
    };
    /* 阿里云盘回显：令牌不回显明文，只说有没有 */
    const aliState = () => {
      const c = store.aliCred();
      return { hasToken: !!c.token, tokenLength: c.token.length, hasRefreshToken: !!c.refreshToken };
    };
    const tianyiState = () => {
      const c = store.tianyiCred();
      return {
        hasCookie: !!c.cookie,
        cookieLength: c.cookie.length,
        hasAccount: !!c.account,
        hasPassword: !!c.password,
      };
    };
    /* PikPak 回显：走登录态转存链路，`loggedIn` 为假就是"还没登录"（解析会报 `PIKPAK_NO_LOGIN`） */
    const pikpakState = () => {
      const c = store.pikpakCred();
      return {
        hasUsername: !!c.username,
        hasPassword: !!c.password,
        hasRefreshToken: !!c.refreshToken,
        loggedIn: !!(c.refreshToken || (c.username && c.password)),
      };
    };
    /* 123 云盘回显：`123无限` 档匿名就出，所以 `hasAuth` 为假也不等于"这家不能用" */
    const pan123State = () => {
      const c = store.pan123Cred();
      return { hasAuth: !!c.auth, authLength: c.auth.length, hasAccount: !!c.account, hasPassword: !!c.password };
    };
    /* 移动云盘（139）回显：分享链全程匿名，没有凭据可配 —— `anonymous` 恒为真 */
    const yidongState = () => ({ anonymous: true });
    /* 光鸭回显：令牌不回显明文，只说有没有；没登录也**不表示**这家不能用（分享列目录仍匿名可读） */
    const guangyaState = () => {
      const c = store.guangyaCred();
      return {
        hasAccessToken: !!c.accessToken,
        hasRefreshToken: !!c.refreshToken,
        hasDeviceId: !!c.deviceId,
        loggedIn: !!(c.accessToken || c.refreshToken),
      };
    };
    /* 设置页输入框的回显源（**明文**）：键名与 `ui/index.html` 里的 input id 一一对应 */
    const credentialsEcho = () => {
      const xl = store.xunleiCred();
      const al = store.aliCred();
      const ty = store.tianyiCred();
      const pk = store.pikpakCred();
      const p1 = store.pan123Cred();
      const gY = store.guangyaCred();
      return {
        quarkCookie: store.quarkCookie(),
        ucCookie: store.ucCookie(),
        ucToken: store.ucToken(),
        ucUt: store.ucUt(),
        pan115Cookie: store.pan115Cookie(),
        baiduCookie: store.baiduCookie(),
        xunleiUsername: xl.username,
        xunleiPassword: xl.password,
        aliToken: al.token,
        aliRefreshToken: al.refreshToken,
        tianyiCookie: ty.cookie,
        tianyiAccount: ty.account,
        tianyiPassword: ty.password,
        pikpakUsername: pk.username,
        pikpakPassword: pk.password,
        pikpakRefreshToken: pk.refreshToken,
        pan123Auth: p1.auth,
        pan123Account: p1.account,
        pan123Password: p1.password,
        guangyaAccessToken: gY.accessToken,
        guangyaRefreshToken: gY.refreshToken,
        guangyaDeviceId: gY.deviceId,
      };
    };

    /* ============================================================
     * 真实验证（GET /verify 用）：十一家各打一发轻量接口。
     * 每家的 driver.check 都**不抛异常**：没配凭据时直接回 {ok:false,error}，
     * 网络失败也回 {ok:false,error}，所以并行跑不会互相拖垮。
     * 设置页打开 / 保存凭据后调它 —— 徽章只认真实结果，不再用"填没填"冒充"登没登录"。
     * ============================================================ */
    const CHECK_BUILDERS = {
      quark: () => netdisk.driverFor('quark').check(store.quarkCookie()),
      uc: () => netdisk.driverFor('uc').check(store.ucCookie()),
      pan115: () => netdisk.driverFor('pan115').check(store.pan115Cookie()),
      baidu: () => netdisk.driverFor('baidu').check(store.baiduCookie()),
      xunlei: () => netdisk.driverFor('xunlei').check(store.xunleiCred()),
      ali: () => netdisk.driverFor('ali').check(store.aliCred()),
      tianyi: () => netdisk.driverFor('tianyi').check({ cookie: store.tianyiCred().cookie }),
      /* PikPak 续期换到的新 refresh_token 要落库（与 POST /check 同口径），
       * 否则下次解析还拿旧令牌去换，会被服务端拒。 */
      pikpak: () =>
        netdisk.driverFor('pikpak').check(Object.assign(store.pikpakCred(), {
          onRefresh: (c) => store.setPikpakCred({ refreshToken: c.refreshToken }),
        })),
      pan123: () => netdisk.driverFor('pan123').check(store.pan123Cred()),
      yidong: () => netdisk.driverFor('yidong').check({}),
      guangya: () => netdisk.driverFor('guangya').check(store.guangyaCred()),
    };
    /* 每家"配没配"的本地态（与 /state 里那 11 个 xxxState() 同源）：/verify 一并带回，
     * 前端靠它区分徽章是「未登录」（没配）还是「登录失效」（配了但真实打不通）。 */
    const STATE_BUILDERS = {
      quark: quarkState,
      uc: ucState,
      pan115: pan115State,
      baidu: baiduState,
      xunlei: xunleiState,
      ali: aliState,
      tianyi: tianyiState,
      pikpak: pikpakState,
      pan123: pan123State,
      yidong: yidongState,
      guangya: guangyaState,
    };
    async function runVerify(keys) {
      const checks = {};
      await Promise.all(keys.map(async (k) => {
        const t0 = Date.now();
        try {
          checks[k] = await CHECK_BUILDERS[k]();
        } catch (e) {
          /* driver.check 理论上都自己吞错；这层兜底防一家抛出炸掉整批 */
          checks[k] = { ok: false, ms: Date.now() - t0, error: (e && e.message) || String(e) };
        }
      }));
      const states = {};
      keys.forEach((k) => { states[k] = STATE_BUILDERS[k](); });
      return { checks, states };
    }

    try {
      if (p === '/state' && method === 'GET') {
        return ok({
          instances: store.list().map(instance.stateOf),
          autoUpdate: autoUpdate.state(),
          dataDir: store.DATA_DIR,
          cacheSettings: store.cacheCfg(),
          cache: cache.stats(),
          quark: quarkState(),
          uc: ucState(),
          pan115: pan115State(),
          baidu: baiduState(),
          xunlei: xunleiState(),
          ali: aliState(),
          tianyi: tianyiState(),
          pikpak: pikpakState(),
          pan123: pan123State(),
          yidong: yidongState(),
          guangya: guangyaState(),
          qrProviders: Object.keys(QR_PROVIDERS),
          /* 设置页要把**已存的凭据原样回显**到输入框（用户要求：填的东西要能看见）。
           * 上面那些 `xxxState()` 仍照旧只说"配没配"，这份是明文，UI 拿它填 input。 */
          credentials: credentialsEcho(),
          plugin: { id: PLUGIN_ID, name: MANIFEST.name, version: MANIFEST.version },
          domains: netdisk.DRIVERS.map((d) => d.name),
          /* 每家网盘的**档位声明** —— 设置页「网盘服务」列表要按它标"几档线路"（见 ui/app.js） */
          bands: netdisk.DRIVERS.map((d) => {
            const L = netdisk.linesFor(d.driver) || { provider: d.driver.PROVIDER_LABEL || d.name, bands: [] };
            return {
              name: d.name,
              label: L.provider,
              bands: L.bands.map((b) => ({ key: b.key, label: b.label, playVia: b.playVia })),
            };
          }),
        });
      }

      /* 真实验证：打开设置页自动跑全部十一家；`?provider=a,b` 只跑指定几家
       * （保存某家凭据后只重验这一家，不拖上其余十家）。返回 checks + states。 */
      if (p === '/verify' && method === 'GET') {
        const wanted = String(q.provider || '')
          .split(',')
          .map((x) => x.trim())
          .filter((k) => CHECK_BUILDERS[k]);
        const keys = wanted.length ? wanted : Object.keys(CHECK_BUILDERS);
        return ok(await runVerify(keys));
      }

      if (p === '/instances' && method === 'POST') {
        const one = store.create(body);
        /* 本地部署的实例**加完就起**（下包 → 起常驻进程）：没有"要不要现在启动"这个选项 */
        if (one.mode === 'local') {
          await instance.ensureBundle(one).catch((e) => ctx.log(`下载源包失败（先记下，可稍后点更新）：${e.message}`));
          await instance.startInstance(one).catch((e) => ctx.log(`启动失败：${e.message}`));
        }
        return ok({ instance: instance.stateOf(store.get(one.id) || one), quark: quarkState() });
      }

      const m = /^\/instances\/([^/]+)(?:\/([a-z]+))?$/.exec(p);
      if (m) {
        const id = decodeURIComponent(m[1]);
        const op = m[2] || '';
        const one = instance.need(id);
        if (method === 'DELETE' && !op) {
          await instance.stopInstance(one).catch(() => {});
          store.remove(id);
          instance.forget(id);
          return ok({ removed: id });
        }
        if (method === 'PATCH' && !op) {
          const patch = {};
          for (const k of ['name', 'port', 'host', 'url', 'mode']) {
            if (body[k] !== undefined) patch[k] = body[k];
          }
          const next = store.update(id, patch);
          instance.forget(id);
          return ok({ instance: instance.stateOf(next) });
        }
        if (method === 'POST' && op) {
          if (op === 'start') {
            await instance.ensureBundle(one);
            return ok({ instance: await instance.startInstance(one) });
          }
          if (op === 'stop') return ok({ instance: await instance.stopInstance(one) });
          if (op === 'restart') {
            await instance.ensureBundle(one);
            return ok({ instance: await instance.restartInstance(one) });
          }
          if (op === 'update') {
            const dl = await fetcher.download(instance.bundleUrl(one), store.bundleDir(one.id), { force: true });
            if (!dl.ok) return bad(400, dl.error || '下载/校验失败');
            const running = runner.publicState(one.id).status === 'running';
            if (running) await instance.restartInstance(one);
            return ok({ changed: !!dl.changed, restarted: running });
          }
          return bad(400, `认不出这个操作：${op}（支持 start / stop / restart / update）`);
        }
      }

      if (p === '/autoupdate' && method === 'POST') {
        const next = store.setAutoUpdate(body);
        autoUpdate.apply();
        return ok({ autoUpdate: Object.assign({}, autoUpdate.state(), next) });
      }
      if (p === '/autoupdate/run' && method === 'POST') {
        const r = await autoUpdate.runNow({ reason: 'manual' });
        if (!r.ok) return bad(r.busy ? 409 : 400, r.error || '跑不起来');
        return ok({ results: r.results, autoUpdate: autoUpdate.state() });
      }

      if (p === '/cache' && method === 'GET') {
        return ok({ cacheSettings: store.cacheCfg(), cache: cache.stats() });
      }
      if (p === '/cache/clear' && method === 'POST') {
        const out = cache.clear(body.table ? String(body.table) : '');
        return ok({ cacheSettings: store.cacheCfg(), cache: out });
      }
      if (p === '/cache/settings' && method === 'POST') {
        const next = store.setCache(body);
        /* 上限调小后**立刻淘汰**（不然设置页会显示"已用 60MB / 上限 10MB"，看着像坏了） */
        cache.sweep('upstream', { force: true });
        return ok({ cacheSettings: next, cache: cache.stats() });
      }

      /* 夸克 Cookie（本地解析网盘分享链要的登录态；空串 = 清掉） */
      if (p === '/quark' && method === 'POST') {
        store.setQuarkCookie(body.cookie);
        return ok({ quark: quarkState() });
      }

      /* UC 登录态：Cookie（转存 / 取直连）与 Token（多分辨率「转码」档）/ ut；给了才改，空串 = 清掉 */
      if (p === '/uc' && method === 'POST') {
        if (body.cookie !== undefined) store.setUcCookie(body.cookie);
        if (body.token !== undefined) store.setUcToken(body.token);
        if (body.ut !== undefined) store.setUcUt(body.ut);
        return ok({ uc: ucState() });
      }

      /* 115 Cookie：扫码登录成功后由 `/qrcode/status` 写进来；这里也给手动粘贴一条路（空串 = 清掉） */
      if (p === '/pan115' && method === 'POST') {
        if (body.cookie !== undefined) store.setPan115Cookie(body.cookie);
        return ok({ pan115: pan115State() });
      }

      /* 百度 Cookie：扫码登录成功后由 `/qrcode/status` 写进来；这里也给手动粘贴一条路（要含 BDUSS；空串 = 清掉） */
      if (p === '/baidu' && method === 'POST') {
        if (body.cookie !== undefined) store.setBaiduCookie(body.cookie);
        return ok({ baidu: baiduState() });
      }

      /* 迅雷账号（用户名 / 密码；空串 = 清掉）。没有 Cookie 这条路，走它自己的 OAuth 登录 */
      if (p === '/xunlei' && method === 'POST') {
        const patch = {};
        for (const k of ['username', 'password', 'refreshToken']) {
          if (body[k] !== undefined) patch[k] = body[k];
        }
        store.setXunleiCred(patch);
        return ok({ xunlei: xunleiState() });
      }

      /* 阿里云盘令牌（访问令牌 / 刷新令牌；空串 = 清掉）。也没有 Cookie 这条路，粘令牌或刷新令牌都行 */
      if (p === '/ali' && method === 'POST') {
        const patch = {};
        for (const k of ['token', 'refreshToken']) {
          if (body[k] !== undefined) patch[k] = body[k];
        }
        store.setAliCred(patch);
        return ok({ ali: aliState() });
      }

      /*
       * 天翼云盘：**账号密码登录**或**手动粘贴 Cookie**（空串 = 清掉）。
       * 账号密码这条走 driver 的 `login()`（logbox RSA → 逐跳收 Cookie，见 `lib/netdisk/tianyi.js`）。
       * 分享信息 / 列目录两发是匿名的，只有最后换直链那发要这份登录态。
       */
      if (p === '/tianyi' && method === 'POST') {
        const account = String(body.account || '').trim();
        const password = String(body.password || '');
        let logged = false;
        if (account && password) {
          const r = await netdisk.driverFor('tianyi').login(account, password);
          store.setTianyiCred({ cookie: r.cookie, account, password });
          logged = true;
        } else if (account || password) {
          return bad(400, '天翼账号密码登录要两样都填（只填一样无法登录）');
        }
        if (body.cookie !== undefined) store.setTianyiCred({ cookie: body.cookie });
        /* 「清掉」是"全清"：账号密码也一并抹掉，否则清不干净（只清 Cookie 的语义由 `{cookie:''}` 表达） */
        if (body.clear) store.setTianyiCred({ cookie: '', account: '', password: '' });
        return ok({ tianyi: tianyiState(), logged });
      }

      /* PikPak（用户名 / 密码 / refresh_token；**这条链要登录** —— 转存自有盘才拿得到地址）。空串 = 清掉 */
      if (p === '/pikpak' && method === 'POST') {
        const patch = {};
        for (const k of ['username', 'password', 'refreshToken']) {
          if (body[k] !== undefined) patch[k] = body[k];
        }
        store.setPikpakCred(patch);
        return ok({ pikpak: pikpakState() });
      }

      /* 123 云盘（JWT / 账号 / 密码；`123无限` 档匿名就出，P123 档才要 JWT）。空串 = 清掉 */
      if (p === '/pan123' && method === 'POST') {
        const patch = {};
        for (const k of ['auth', 'account', 'password']) {
          if (body[k] !== undefined) patch[k] = body[k];
        }
        store.setPan123Cred(patch);
        return ok({ pan123: pan123State() });
      }

      /*
       * 光鸭（access_token / refresh_token / device_id）：扫码登录成功后由 `/qrcode/status` 写进来，
       * 这里也给手动粘贴一条路。`clear` = 全清（令牌 + 设备号）。空串 = 清掉对应那一项。
       */
      if (p === '/guangya' && method === 'POST') {
        const patch = {};
        for (const k of ['accessToken', 'refreshToken', 'deviceId']) {
          if (body[k] !== undefined) patch[k] = body[k];
        }
        store.setGuangyaCred(patch);
        if (body.clear) store.setGuangyaCred({ accessToken: '', refreshToken: '', deviceId: '' });
        return ok({ guangya: guangyaState() });
      }

      /*
       * 扫码登录 —— **通用端点**，别把某一家写死进来（provider → `QR_PROVIDERS`）。
       *
       *   GET /qrcode?provider=115                     → {provider, sessionId, image(data URL), expiresAt}
       *   GET /qrcode/status?provider=115&sessionId=…  → {status: pending|scanned|confirmed|expired|failed}
       *
       * 会话只放内存（`QR_SESSIONS`，TTL 见 `QR_TTL_MS`）：扫码是短时交互，重启就没意义了。
       * 状态 2（confirmed）时由 provider 自己把 Cookie 落库，这里只回 `saved: true`。
       */
      if (p === '/qrcode' && method === 'GET') {
        qrPurge();
        const provider = String(q.provider || '');
        const impl = QR_PROVIDERS[provider];
        if (!impl) return bad(404, `没有这个扫码 provider：${provider || '(空)'}（支持 ${Object.keys(QR_PROVIDERS).join(' / ')}）`);
        const t0 = Date.now();
        const got = await impl.start(15000);
        const sessionId = qrNewId();
        const expiresAt = Date.now() + QR_TTL_MS;
        QR_SESSIONS.set(sessionId, { provider, session: got.session, expiresAt });
        if (ctx) ctx.log(`扫码登录：起了一个 ${impl.label} 会话 ${sessionId}`);
        return ok({ provider, sessionId, image: got.image || '', message: got.message || '', expiresAt, ms: Date.now() - t0 });
      }

      if (p === '/qrcode/status' && method === 'GET') {
        qrPurge();
        const provider = String(q.provider || '');
        const sessionId = String(q.sessionId || '');
        const rec = QR_SESSIONS.get(sessionId);
        if (!rec) return ok({ provider, sessionId, status: 'expired', message: '这个二维码会话不在了（过期或插件重启过），点「刷新二维码」再来' });
        if (rec.provider !== provider) return bad(400, '会话与 provider 对不上');
        const impl = QR_PROVIDERS[rec.provider];
        if (!impl) return bad(404, `没有这个扫码 provider：${provider}`);
        const st = await impl.poll(rec.session, 15000);
        if (st.status === 'confirmed') {
          impl.save(st.cookie);
          QR_SESSIONS.delete(sessionId);
          if (ctx) ctx.log(`扫码登录：${impl.label} 已确认，Cookie 已落库`);
          return ok({ provider, sessionId, status: 'confirmed', saved: true });
        }
        if (st.status === 'pending' || st.status === 'scanned') {
          return ok({ provider, sessionId, status: st.status, message: st.message || '', expiresAt: rec.expiresAt });
        }
        QR_SESSIONS.delete(sessionId);
        return ok({ provider, sessionId, status: 'failed', message: st.message || '扫码失败' });
      }

      /* 自检：每个实例按它现在的服务地址打 `/check` + `/config`；再拿十一家网盘各打一发轻量接口 */
      if (p === '/check' && method === 'POST') {
        const rows = await Promise.all(
          store.list().map(async (one) => {
            const url = instance.baseUrlOf(one);
            if (!url) {
              return {
                id: one.id,
                name: one.name || one.url || one.id,
                url: '',
                ok: false,
                siteCount: 0,
                groups: {},
                ms: 0,
                error: one.mode === 'local' ? '这个实例没在运行' : '没有地址',
              };
            }
            const r = await protocol.probe(url, { timeout: 8000 });
            return {
              id: one.id,
              name: one.name || url,
              url,
              ok: r.ok,
              siteCount: r.siteCount,
              groups: groupCounts(r.sites),
              ms: r.elapsed,
              error: r.error,
            };
          })
        );
        const cookie = body.cookie !== undefined ? body.cookie : store.quarkCookie();
        const poke = await netdisk.driverFor('quark').check(cookie);
        const ucCookie = body.ucCookie !== undefined ? body.ucCookie : store.ucCookie();
        const ucPoke = await netdisk.driverFor('uc').check(ucCookie);
        const pan115Cookie = body.pan115Cookie !== undefined ? body.pan115Cookie : store.pan115Cookie();
        const pan115Poke = await netdisk.driverFor('pan115').check(pan115Cookie);
        const baiduCookie = body.baiduCookie !== undefined ? body.baiduCookie : store.baiduCookie();
        const baiduPoke = await netdisk.driverFor('baidu').check(baiduCookie);
        /* 迅雷收的是 `{username, password, refreshToken}` 对象（没有 Cookie 这条路） */
        const xunleiCred = Object.assign({}, store.xunleiCred());
        for (const k of ['username', 'password']) {
          if (body[k === 'username' ? 'xunleiUsername' : 'xunleiPassword'] !== undefined) {
            xunleiCred[k] = body[k === 'username' ? 'xunleiUsername' : 'xunleiPassword'];
          }
        }
        const xunleiPoke = await netdisk.driverFor('xunlei').check(xunleiCred);

        /* 阿里云盘 / 天翼 / 123：凭据都是"给了就用给的、没给就用存的"（自检时还没保存也能试） */
        const aliCred = Object.assign({}, store.aliCred());
        if (body.aliToken !== undefined) aliCred.token = body.aliToken;
        if (body.aliRefreshToken !== undefined) aliCred.refreshToken = body.aliRefreshToken;
        const aliPoke = await netdisk.driverFor('ali').check(aliCred);

        const tianyiCred = { cookie: body.tianyiCookie !== undefined ? body.tianyiCookie : store.tianyiCred().cookie };
        const tianyiPoke = await netdisk.driverFor('tianyi').check(tianyiCred);

        const pan123Cred = Object.assign({}, store.pan123Cred());
        if (body.pan123Auth !== undefined) pan123Cred.auth = body.pan123Auth;
        if (body.pan123Account !== undefined) pan123Cred.account = body.pan123Account;
        if (body.pan123Password !== undefined) pan123Cred.password = body.pan123Password;
        const pan123Poke = await netdisk.driverFor('pan123').check(pan123Cred);

        /* PikPak 走登录态转存链路：先登录，再列自有盘根目录验连通（没登录会如实回"还没登录"）。
         * 凭据"给了就用给的、没给就用存的"（自检时还没保存也能试） */
        const pikpakCred = Object.assign(store.pikpakCred(), { onRefresh: (c) => store.setPikpakCred({ refreshToken: c.refreshToken }) });
        if (body.pikpakUsername !== undefined) pikpakCred.username = body.pikpakUsername;
        if (body.pikpakPassword !== undefined) pikpakCred.password = body.pikpakPassword;
        const pikpakPoke = await netdisk.driverFor('pikpak').check(pikpakCred);

        /* 移动云盘同样**不要凭据**，自检打一发匿名分享接口验连通 */
        const yidongPoke = await netdisk.driverFor('yidong').check({});

        /* 光鸭收的是 `{accessToken, refreshToken, deviceId}`（给了就用给的、没给就用存的） */
        const guangyaCred = Object.assign({}, store.guangyaCred());
        for (const k of ['accessToken', 'refreshToken', 'deviceId']) {
          const bk = 'guangya' + k.charAt(0).toUpperCase() + k.slice(1);
          if (body[bk] !== undefined) guangyaCred[k] = body[bk];
        }
        const guangyaPoke = await netdisk.driverFor('guangya').check(guangyaCred);

        return ok({
          instances: rows,
          quark: poke,
          quarkState: quarkState(),
          uc: ucPoke,
          ucState: ucState(),
          pan115: pan115Poke,
          pan115State: pan115State(),
          baidu: baiduPoke,
          baiduState: baiduState(),
          xunlei: xunleiPoke,
          xunleiState: xunleiState(),
          ali: aliPoke,
          aliState: aliState(),
          tianyi: tianyiPoke,
          tianyiState: tianyiState(),
          pikpak: pikpakPoke,
          pikpakState: pikpakState(),
          pan123: pan123Poke,
          pan123State: pan123State(),
          yidong: yidongPoke,
          yidongState: yidongState(),
          guangya: guangyaPoke,
          guangyaState: guangyaState(),
        });
      }

      return bad(404, `插件设置页没有这个接口：${method} ${p}`);
    } catch (e) {
      return bad((e && e.code === 'NO_SOURCE') ? 404 : 400, (e && e.message) || String(e));
    }
  },
};

/* ============================================================
 * 开机：拉起本地实例 + 自动更新计时
 *
 * 放在**下一个事件循环**跑：宿主是先拿到 `ready`（动作清单）再发第一条调用的，
 * 开机这几件事可能很慢（下包、起进程），不该挡在 `ready` 前面。
 *
 * 本地部署的实例**一律拉起**（没有"开机自启"这个开关）：面板起来后它们就该在跑。
 * ============================================================ */
setTimeout(async () => {
  for (const one of store.list()) {
    if (one.mode !== 'local') continue;
    try {
      await instance.ensureBundle(one);
      await instance.startInstance(one, { awaitReady: true });
      console.log(`✔ 自启实例：${one.id} ${one.name || one.url}`);
    } catch (e) {
      console.log(`✘ 自启失败 ${one.id}：${(e && e.message) || e}`);
    }
  }
  autoUpdate.start();
}, 0).unref?.();

/* ============================================================
 * 善后：**插件被停掉时，把实例进程一起带走**
 *
 * 这是"插件自己起的东西自己清"那条义务里最要紧的一半：插件是实例进程的父进程，
 * 父进程一没，它会变成孤儿 —— 端口还占着、面板下次又起一份，而且谁都看不见它。
 * （面板停插件走的是 SIGTERM，见 `modules/plugin/host.js` 的 `stop()`。）
 * ============================================================ */
let exiting = false;
function shutdown(sig) {
  if (exiting) return;
  exiting = true;
  const running = store.list().filter((x) => x.mode === 'local' && runner.publicState(x.id).status === 'running');
  if (running.length) console.log(`收到 ${sig}：正在停 ${running.length} 个实例（${running.map((x) => x.id).join(' / ')}）`);
  Promise.resolve()
    .then(() => runner.stopAll())
    .catch(() => {});
  setTimeout(() => process.exit(0), 1200).unref?.();
}
process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));

module.exports = { actions };