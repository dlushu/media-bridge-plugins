'use strict';
/**
 * Emby 片源 · 插件入口（动作层）
 *
 * 契约见 docs/plugin-contract.md 第五节。六动作：
 *
 *   sites   站点清单     —                        注册「Emby」一个站
 *   search  候选         {source,key,wd,page}     外部 Emby 的 /Items 搜索 → macCMS 形状的列表
 *   detail  取播放项     {source,key,id,season,episode,pick}
 *                                                 按 id 取条目 → 媒体源逐个成版本 / 按季集定位
 *   play    解析地址     {ref}                     一个 ref（条目 id + 媒体源 id）→ /Videos/{id}/stream
 *   probe   站点测速     {source,key,wd}           体检口径的一发（搜索）
 *   http    webui 后端   {method,path,query,body}  插件自己设置页的后端
 *
 * 取数式样：**两层式**（`directLines` 不写 = false）。搜索给候选，取详情时才展开版本。
 *
 * 地址口径（用户要求）：**用户直接填「客户端可达地址」** —— 面板不做 `clientHost` 自动改写，
 * 插件也不改写。填 `https://media.example.com`，客户端就得能直连它。
 *
 * 鉴权：账号密码换 `AccessToken`（见 docs 里 Emby 那条），换回来的令牌存插件自己的
 * `data/auth.json`；到期 / 被吊销（401）时**用存着的账密自动重登一次**。
 *
 * 播放：`/Videos/{id}/stream?static=true&MediaSourceId=<msid>&api_key=<token>`
 * —— 真机实测 HEAD 200、`accept-ranges: bytes`，地址**能裸用**（`playVia` 缺省 = client），
 * 所以只回 `urls`、不带 `header`。
 *
 * 同集多版本：一个条目在 Emby 里可以有多个 `MediaSources[]`（同一集的不同压制），
 * 剧集就**按其数量各发一条线路**（flag 相同 `直连`，`line.target` 各指一个媒体源）——
 * 面板「线路 = 版本」，这样客户端就能挑版本播。
 */
const settings = require('./lib/settings');
const cache = require('./lib/cache');
const emby = require('./lib/emby');
const locate = require('./lib/locate');
const spec = require('./lib/spec');
const { encodeCandidate, decodeCandidate, encodeRef, decodeRef } = require('./lib/ref');
const pkg = require('./plugin.json');

const PLUGIN_ID = pkg.id;
/** 源实例 id：面板分组头的左半段取设置页里的实例名（如「动漫」），留空回落 `Emby` */
const INSTANCE_ID = 'emby';
const SITE_KEY = 'emby';
const SITE_NAME = 'Emby';
const FALLBACK_NAME = 'Emby';
const SITES = [{ key: SITE_KEY, name: SITE_NAME }];

/** 线路名：Emby 直连地址能裸用，就这一路；模板 lineFilter 要认它 */
const LINE_FLAG = '直连';
/** 各动作兜底超时（面板都会带自己的值，这几个只是没带时的口径） */
const SEARCH_TIMEOUT_MS = 15000;
const DETAIL_TIMEOUT_MS = 55000;
/** 单次搜索最多回多少条候选（面板还要打分，不必全给） */
const MAX_ROWS = 50;
/** 分集分页：一页 200、最多 20 页（4000 集够用，防某个库把面板拖死） */
const EP_PAGE = 200;
const EP_MAX_PAGES = 20;
/** 自检默认搜索词 */
const TEST_WD = '让子弹飞';

const NO_BASE = { code: 'NO_BASE', message: emby.noBase().message };
const NEED_AUTH = { code: 'NEED_AUTH', message: '外部 Emby 需要登录 —— 到插件设置页填上账号密码' };

/** 每次动作进来先登记数据目录（缓存、设置与凭据都按它定位） */
function useCtx(ctx) {
  if (ctx && ctx.dataDir) settings.setDataDir(ctx.dataDir);
}

/** 超时让面板认出是超时（判据是 `AbortError`） */
function failFrom(e) {
  if (e && e.name === 'AbortError') return { code: 'TIMEOUT', message: '请求超时' };
  const cause = e && e.cause && (e.cause.code || e.cause.message);
  const msg = (e && e.message) || String(e);
  return { code: (e && e.code) || 'UPSTREAM', message: cause ? `${msg}（${cause}）` : msg };
}

/** 401 / 登录失败 —— 归「要凭据」这一档（决定要不要用存着的账密重登） */
function isAuth(e) {
  return !!e && (e.status === 401 || e.code === 'AUTH_FAILED');
}

function authErr() {
  const e = new Error(NEED_AUTH.message);
  e.code = NEED_AUTH.code;
  return e;
}

function noBase() {
  const e = new Error(NO_BASE.message);
  e.code = NO_BASE.code;
  return e;
}

/** 实例名：设置页填了就用，留空回落 `Emby`（分组头「实例名 · 站名」，见 docs/source-display-rules.md） */
function instanceName(cfg) {
  return String((cfg && cfg.name) || '').trim() || FALLBACK_NAME;
}

/** 上游地址里的 api_key 一律抹掉再进日志 / 诊断字段（令牌不进面板） */
function redact(u) {
  return String(u || '').replace(/([?&]api_key=)[^&]*/gi, '$1***');
}

/** 拿存着的账密登录一次并存下令牌；没账密就抛「要凭据」 */
async function loginAndSave(base, timeoutMs) {
  const a = settings.readAuth();
  if (!a.username || !a.password) throw authErr();
  const r = await emby.authenticate(base, a.username, a.password, { timeout: timeoutMs });
  settings.patchAuth({ token: r.token, userId: r.userId });
  return r.token;
}

/**
 * 带着令牌跑 `run(token)`：
 *   有令牌就先用；401 且有账密 → 重登一次再跑（令牌过期/被吊销的自愈）
 *   没令牌先匿名试；401 且有账密 → 登录后再跑
 * 401 且没账密 → 抛「要凭据」（如实说，不装作没结果）
 */
async function withToken(base, timeoutMs, run) {
  const a = settings.readAuth();
  const canLogin = !!(a.username && a.password);
  const once = async (token) => {
    try {
      return await run(token);
    } catch (e) {
      if (!isAuth(e) || !canLogin) throw e;
      const fresh = await loginAndSave(base, timeoutMs);
      return await run(fresh);
    }
  };
  return once(a.token || '');
}

/** 播放用：没有令牌时不主动登录（先试匿名），拿不到就算了 —— 真被挡了会在拉流那步 401 */
async function ensureToken(base, timeoutMs) {
  const a = settings.readAuth();
  if (a.token) return a.token;
  if (!a.username || !a.password) return '';
  return loginAndSave(base, timeoutMs);
}

/** 取一部剧的全部分集（分页收齐；契约要求 `episodes[]` 回全集，不许截断） */
async function fetchAllEpisodes(base, seriesId, opts) {
  const o = opts || {};
  const items = [];
  let total = 0;
  for (let page = 0; page < EP_MAX_PAGES; page += 1) {
    const res = await emby.episodesOf(base, seriesId, {
      token: o.token,
      startIndex: page * EP_PAGE,
      limit: EP_PAGE,
      timeout: o.timeout,
    });
    total = res.total || total;
    if (!res.items.length) break;
    items.push(...res.items);
    if (items.length >= total) break;
  }
  return { items, total: total || items.length };
}

/** Emby 的季 / 集号 → 数值；没给（空 / 非数）回 null（0 也是 Emby 表达「没有」的方式，交给定位判） */
function embyNum(v) {
  if (v === undefined || v === null || v === '') return null;
  const n = Number(v);
  return Number.isFinite(n) ? n : null;
}

/** 集名显示：清洗后挂上本文件体积（`[2.0GB]…`）；ref 里的 `n` 仍是原始文件名 */
function episodeLabel(rawName, bytes) {
  const base = String(rawName || '').trim() || 'video';
  const tag = spec.compactSize(bytes);
  const hasSizePrefix = /^\s*\[\s*[\d.]+\s*(?:GB|MB|KB|TB|B)\s*\]/i.test(base);
  return tag && !hasSizePrefix ? `[${tag}]${base}` : base;
}

/** 媒体文件名：Emby 的 `MediaSource.Name`（发布名）优先，退回 `Path` 末段；没扩展名按容器补一个 */
function mediaFileName(ms, item) {
  const m = ms || {};
  const it = item || {};
  const leaf = String(m.Path || it.Path || '')
    .split('/')
    .filter(Boolean)
    .pop();
  let base = String(m.Name || '').trim() || String(leaf || '').trim();
  if (!base) base = String(it.Name || '').trim() || 'video';
  const container = String(m.Container || it.Container || '')
    .replace(/^\./, '')
    .toLowerCase();
  if (container && !/\.[a-z0-9]{2,5}$/i.test(base)) base = `${base}.${container}`;
  return base;
}

/**
 * 一个播放项（剧集 = 一集的一个媒体源；电影 = 一个媒体源）。
 * `name` 给界面看（剧集带 `[体积]` 前缀），`ref` 里存的是**原始文件名**与定位播放所需的两段 id。
 */
function playItemOf(item, ms, index, opts) {
  const o = opts || {};
  const m = ms || {};
  const file = mediaFileName(m, item);
  const sizeBytes = Number(m.Size) || 0;
  return Object.assign(
    {
      name: o.withSize ? episodeLabel(file, sizeBytes) : file,
      /* 有媒体源 id 就用它（同集多版本靠它区分），没有退回条目 id */
      id: String(m.Id || (item && item.Id) || ''),
      index,
      ref: encodeRef(PLUGIN_ID, { i: String((item && item.Id) || ''), m: String(m.Id || ''), n: file }),
      sizeBytes,
    },
    spec.specOf(m)
  );
}

/** macCMS 形状的一条候选（面板只读 vod_id / vod_name / vod_pic / vod_remarks） */
function toMacRow(item, base, token) {
  const it = item || {};
  const year = Number(it.ProductionYear) || 0;
  const isSeries = String(it.Type || '') === 'Series';
  return {
    /* 候选 = `{ i: 条目 id, t: 标题, y: 年份, k: 类型, g: 主图 tag }` —— 面板原样交回 */
    vod_id: encodeCandidate({ i: it.Id, t: String(it.Name || ''), y: year, k: String(it.Type || ''), g: (it.ImageTags || {}).Primary || '' }),
    vod_name: String(it.Name || ''),
    vod_pic: emby.primaryImageUrl(base, it, token),
    /* 备注只写事实（年份 / 类型），不写广告词 */
    vod_remarks: isSeries ? [year ? String(year) : '', '剧集'].filter(Boolean).join(' ') : year ? String(year) : '',
  };
}

/** 搜索一条（带缓存：键含基地址、关键词与页码，换实例后自然作别） */
async function doSearch(cfg, wd, page, timeoutMs, ctx) {
  const keyword = String(wd || '').trim();
  const key = [SITE_KEY, 'search', keyword, String(page), cfg.base].join('|');
  const hit = cache.get('upstream', key);
  if (hit) {
    if (ctx) ctx.log(`缓存命中：Emby 搜索「${keyword}」第 ${page} 页 —— 不打外部服务器`);
    return Object.assign({}, hit, { source: SITE_KEY, site: SITE_KEY, cached: true });
  }
  try {
    let token = '';
    const res = await withToken(cfg.base, timeoutMs, (t) => {
      token = t;
      return emby.searchItems(cfg.base, {
        term: keyword,
        token: t,
        limit: MAX_ROWS,
        startIndex: (page - 1) * MAX_ROWS,
        timeout: timeoutMs,
      });
    });
    const rows = res.items.slice(0, MAX_ROWS).map((it) => toMacRow(it, cfg.base, token));
    const out = {
      status: 200,
      ok: true,
      text: '',
      json: { list: rows, page, total: res.total || rows.length },
      url: redact(res.url),
      source: SITE_KEY,
      site: SITE_KEY,
      term: keyword,
    };
    cache.put('upstream', key, out, cache.limits().ttlMs);
    if (ctx) ctx.log(`Emby 搜索「${keyword}」第 ${page} 页：外部共 ${res.total} 条，回 ${rows.length} 条候选`);
    return out;
  } catch (e) {
    if (ctx) ctx.log(`Emby 搜索失败：「${keyword}」— ${(e && e.message) || e}`);
    return { error: failFrom(e), source: SITE_KEY, site: SITE_KEY, term: keyword };
  }
}

/** 电影：一个条目的每个媒体源各成一个版本（`pick: 'items'` 取法） */
async function detailMovie(cfg, cand, budgetMs, ctx) {
  const base = cfg.base;
  const timeout = Math.max(3000, budgetMs - 3000);
  let token = '';
  const res = await withToken(base, timeout, (t) => {
    token = t;
    return emby.itemById(base, cand.i, { token: t, timeout });
  });
  const full = res.item;
  const name = String((full && full.Name) || cand.t || '').trim() || 'Emby 条目';
  if (!full) {
    return { error: { code: 'NOT_FOUND', message: `外部 Emby 里找不到这个条目（${cand.i}）` }, source: SITE_KEY, site: SITE_KEY, title: name };
  }
  const pic = emby.primaryImageUrl(base, full, token);
  const items = spec.mediaSourcesOf(full).map((ms, i) => playItemOf(full, ms, i, { withSize: false }));
  const lines = [];
  if (items.length) {
    lines.push({
      flag: LINE_FLAG,
      episodes: items.map((x) => ({ name: x.name, id: x.id, index: x.index, ref: x.ref })),
      episodeCount: items.length,
      items,
      target: items[0],
    });
  }
  const detail = {
    vodId: String(cand.i || ''),
    name,
    pic,
    content: '',
    remarks: '',
    lines,
    lineCount: lines.length,
    target: items[0] || null,
    pick: 'items',
  };
  const detailNote = items.length
    ? `外部 Emby 里这个条目有 ${items.length} 个媒体源（各成一个版本）`
    : `外部 Emby 里这个条目没有可播的媒体源`;
  if (ctx) ctx.log(`取播放项：${name} → ${items.length} 个媒体源`);
  return {
    status: 200,
    ok: true,
    text: '',
    json: { list: [macDetailRow(detail, lines)], page: 1, total: 1 },
    detail,
    detailNote,
    url: redact(res.url),
    source: SITE_KEY,
    site: SITE_KEY,
    title: name,
  };
}

/** 剧集：取全部分集 → 按季集号定位 → 命中那集的每个媒体源各成一条线路 */
async function detailSeries(cfg, cand, args, budgetMs, ctx) {
  const base = cfg.base;
  const timeout = Math.max(3000, budgetMs - 3000);
  let token = '';
  const res = await withToken(base, timeout, (t) => {
    token = t;
    return fetchAllEpisodes(base, cand.i, { token: t, timeout });
  });
  const eps = res.items;
  const name = String(cand.t || '').trim() || 'Emby 剧集';
  const pic = emby.primaryImageUrl(base, { Id: cand.i, ImageTags: { Primary: cand.g } }, token);

  /* 全集基线：每集取第一个媒体源做「这一集」的代表项（列表要回全集，不许截断） */
  const list = eps.map((ep, i) => {
    const t = playItemOf(ep, spec.firstSourceOf(ep), i, { withSize: true });
    return { ep, season: embyNum(ep.ParentIndexNumber), episode: embyNum(ep.IndexNumber), score: t };
  });

  const wantEp = args.episode === undefined || args.episode === null || args.episode === '' ? null : Number(args.episode);
  const wantEpOk = wantEp !== null && Number.isFinite(wantEp) && wantEp > 0;
  const hit = wantEpOk ? locate.locateEpisode(list, args.season, wantEp) : null;

  const baseEpisodes = () => list.map((x) => ({ name: x.score.name, id: x.score.id, index: x.score.index, ref: x.score.ref }));

  const lines = [];
  let targetNote = '';
  if (hit) {
    /* 命中那一集的每个媒体源各成一条线路 —— 同一集多版本就靠这里列出来 */
    const sources = spec.mediaSourcesOf(hit.ep);
    for (let k = 0; k < sources.length; k += 1) {
      const t = Object.assign(playItemOf(hit.ep, sources[k], hit.score.index, { withSize: true }), { matchedBy: hit.matchedBy });
      const episodes = baseEpisodes();
      episodes[t.index] = { name: t.name, id: t.id, index: t.index, ref: t.ref };
      lines.push({ flag: LINE_FLAG, episodes, episodeCount: episodes.length, target: t });
    }
  } else if (list.length) {
    /* 没定位到：线路照给，但 `target` 留 null（面板据此不列这条版本），并如实说明原因 */
    lines.push({ flag: LINE_FLAG, episodes: baseEpisodes(), episodeCount: list.length, target: null });
  }

  if (!list.length) {
    targetNote = '外部 Emby 里这部剧没有分集';
  } else if (wantEpOk && !hit) {
    targetNote =
      `这部剧的 ${list.length} 个分集里没有 ` + `${Number(args.season) > 0 ? `S${Number(args.season)} ` : ''}E${wantEp}`;
  } else if (!wantEpOk) {
    targetNote = '这次请求没带集号 —— 剧集要按季集号定位，无法确定是这一集';
  }

  const detail = {
    vodId: String(cand.i || ''),
    name,
    pic,
    content: '',
    remarks: '',
    lines,
    lineCount: lines.length,
    target: (lines[0] && lines[0].target) || null,
  };
  if (targetNote) detail.targetNote = targetNote;

  const detailNote = hit
    ? `定位到 ${hit.matchedBy === 'title' ? '同一季集' : '这一集'}，该集有 ${spec.mediaSourcesOf(hit.ep).length} 个媒体源`
    : targetNote;
  if (ctx) ctx.log(`取播放项：${name} → ${list.length} 集${hit ? `（E${wantEp} 有 ${lines.length} 个媒体源）` : '（没定位到）'}`);
  return {
    status: 200,
    ok: true,
    text: '',
    json: { list: [macDetailRow(detail, lines)], page: 1, total: 1 },
    detail,
    detailNote,
    url: redact(res.url),
    source: SITE_KEY,
    site: SITE_KEY,
    title: name,
  };
}

/** 详情的 macCMS 兜底形状（面板走 `detail`，这份只是「也给了」） */
function macDetailRow(detail, lines) {
  const first = lines[0] || {};
  const picked = (first.target && [first.target]) || first.items || [];
  return {
    vod_id: detail.vodId,
    vod_name: detail.name,
    vod_pic: detail.pic,
    vod_content: '',
    vod_remarks: '',
    vod_play_from: lines.length ? first.flag : '',
    vod_play_url: picked.map((x) => `${x.name}$${x.id}`).join('#'),
  };
}

const actions = {
  /** 站点清单 —— 静态声明「这个插件现在有哪些站点」 */
  async sites(args, ctx) {
    useCtx(ctx);
    const cfg = settings.read();
    const t0 = Date.now();
    if (ctx) ctx.log(`站点清单：${SITE_KEY} → ${cfg.base ? redact(cfg.base) : '（还没填地址）'}`);
    return {
      sources: [
        {
          id: INSTANCE_ID,
          name: instanceName(cfg),
          url: cfg.base,
          mode: 'remote',
          enabled: true,
          ok: true,
          ms: Date.now() - t0,
          siteCount: SITES.length,
        },
      ],
      sites: SITES.map((x) => ({
        key: x.key,
        name: x.name,
        api: '/',
        searchable: true,
        source: SITE_KEY,
      })),
    };
  },

  /** 候选 —— 打外部 Emby 的 `/Items`（两层式，候选不带线路） */
  async search(args, ctx) {
    useCtx(ctx);
    const cfg = settings.read();
    const timeoutMs = Math.max(1000, Number(args.timeoutMs) || SEARCH_TIMEOUT_MS);
    const wd = String(args.wd || '').trim();
    const page = Math.max(1, Number(args.page) || 1);
    if (!wd) return { status: 200, ok: true, text: '', json: { list: [], page, total: 0 }, source: SITE_KEY, site: SITE_KEY };
    if (!cfg.base) return { error: failFrom(noBase()), source: SITE_KEY, site: SITE_KEY, term: wd };
    return doSearch(cfg, wd, page, timeoutMs, ctx);
  },

  /**
   * 取播放项 —— 电影（`pick:'items'`）：每个媒体源一个版本；
   * 剧集：按季集号定位，命中那一集的每个媒体源各成一条线路（同集多版本）。
   * 定位不到就 `target=null` 并如实说明，绝不按列表顺序顶一个。
   */
  async detail(args, ctx) {
    useCtx(ctx);
    const cfg = settings.read();
    const budgetMs = Math.max(5000, Math.min(Number(args.timeoutMs) || DETAIL_TIMEOUT_MS, DETAIL_TIMEOUT_MS));
    const cand = decodeCandidate(args.id);
    if (!cand) {
      return { error: { code: 'BAD_ID', message: `认不出这个条目编号：${String(args.id || '').slice(0, 60)}` }, source: SITE_KEY, site: SITE_KEY };
    }
    const title = String(cand.t || '').trim() || 'Emby 条目';
    if (!cfg.base) return { error: failFrom(noBase()), source: SITE_KEY, site: SITE_KEY, title };
    const pick = args.pick === 'items' ? 'items' : '';
    const isMovie = pick === 'items' || String(cand.k || '') === 'Movie';
    try {
      return isMovie ? await detailMovie(cfg, cand, budgetMs, ctx) : await detailSeries(cfg, cand, args, budgetMs, ctx);
    } catch (e) {
      if (ctx) ctx.log(`取播放项失败：${title} — ${(e && e.message) || e}`);
      return { error: failFrom(e), source: SITE_KEY, site: SITE_KEY, title };
    }
  },

  /** 解析地址 —— 一个 ref（条目 id + 媒体源 id）→ 外部 Emby 的静态 stream 地址 */
  async play(args, ctx) {
    useCtx(ctx);
    const cfg = settings.read();
    const o = decodeRef(PLUGIN_ID, args.ref);
    if (!o) {
      return { error: { code: 'BAD_REF', message: `认不出这个 ref：${String(args.ref || '').slice(0, 80)}` } };
    }
    if (!cfg.base) return { error: failFrom(noBase()), source: SITE_KEY, site: SITE_KEY };
    const timeoutMs = Math.max(3000, Number(args.timeoutMs) || 15000);
    const token = await ensureToken(cfg.base, timeoutMs);
    /* 地址能裸用（真机实测 HEAD 200 + accept-ranges），故只回 urls、不带 header */
    const url = emby.streamUrl(cfg.base, o.i, o.m, token);
    if (ctx) ctx.log(`解析地址：${o.n || o.i} → ${redact(url)}`);
    return {
      ok: true,
      status: 200,
      urls: [url],
      header: {},
      parse: 0,
      name: String(o.n || ''),
      source: SITE_KEY,
      site: SITE_KEY,
    };
  },

  /** 站点测速 —— 体检口径的一发：搜索打一次，只回答「通不通、多快」 */
  async probe(args, ctx) {
    useCtx(ctx);
    const cfg = settings.read();
    const timeoutMs = Math.max(1000, Number(args.timeoutMs) || SEARCH_TIMEOUT_MS);
    const wd = String(args.wd || '').trim();
    if (!wd) {
      return { error: { code: 'BAD_REQUEST', message: '测速需要一个搜索关键词' }, source: SITE_KEY, site: SITE_KEY, name: SITE_NAME };
    }
    if (!cfg.base) return { error: failFrom(noBase()), source: SITE_KEY, site: SITE_KEY, name: SITE_NAME };
    try {
      let token = '';
      const res = await withToken(cfg.base, timeoutMs, (t) => {
        token = t;
        return emby.searchItems(cfg.base, { term: wd, token: t, limit: 10, timeout: timeoutMs });
      });
      const rows = res.items.slice(0, 10).map((it) => toMacRow(it, cfg.base, token));
      return {
        status: 200,
        ok: true,
        text: '',
        json: { list: rows, page: 1, total: rows.length },
        url: redact(res.url),
        source: SITE_KEY,
        site: SITE_KEY,
        name: SITE_NAME,
      };
    } catch (e) {
      return { error: failFrom(e), source: SITE_KEY, site: SITE_KEY, name: SITE_NAME };
    }
  },

  /** 插件设置页的后端（面板只转发、不解释，见契约第十一节） */
  async http(args, ctx) {
    useCtx(ctx);
    const method = String(args.method || 'GET').toUpperCase();
    const p = String(args.path || '/').replace(/\/+$/, '') || '/';
    let body = {};
    if (args.body) {
      try {
        body = typeof args.body === 'string' ? JSON.parse(args.body) : args.body;
      } catch {
        return { status: 400, body: { ok: false, error: '请求体不是 JSON' } };
      }
    }
    const ok = (v) => ({ status: 200, body: Object.assign({ ok: true }, v) });
    const bad = (status, message) => ({ status, body: { ok: false, error: message } });
    const state = () => ({
      plugin: { id: pkg.id, name: pkg.name, version: pkg.version },
      settings: settings.read(),
      auth: settings.publicAuth(),
      cacheSettings: settings.cacheCfg(),
      cache: cache.stats(),
      sites: SITES.map((x) => ({ key: x.key, name: x.name })),
    });

    try {
      if (p === '/state' && method === 'GET') return ok(state());

      /* 连接两项：实例名 + 客户端可达地址 */
      if (p === '/settings' && method === 'POST') {
        settings.setSite(body);
        return ok(state());
      }

      /* 凭据只进不出：这里保存，界面读到的永远只是「有没有」 */
      if (p === '/credentials' && method === 'POST') {
        const patch = {};
        for (const k of ['username', 'password']) {
          if (body[k] !== undefined && String(body[k]).trim()) {
            patch[k] = String(body[k]).trim();
          }
        }
        if (!Object.keys(patch).length) return bad(400, '没有要保存的内容');
        settings.patchAuth(patch);
        return ok(state());
      }

      /* 登录：拿存着的账密换令牌（改过密码 / 换了账号后来一下） */
      if (p === '/login' && method === 'POST') {
        const base = settings.read().base;
        if (!base) return bad(400, NO_BASE.message);
        const a = settings.readAuth();
        if (!a.username || !a.password) return bad(400, NEED_AUTH.message);
        const r = await emby.authenticate(base, a.username, a.password, { timeout: 15000 });
        settings.patchAuth({ token: r.token, userId: r.userId });
        return ok(state());
      }

      if (p === '/logout' && method === 'POST') {
        settings.clearSession();
        return ok(state());
      }

      if (p === '/cache' && method === 'GET') {
        return ok({ cacheSettings: settings.cacheCfg(), cache: cache.stats() });
      }
      if (p === '/cache/clear' && method === 'POST') {
        return ok({ cacheSettings: settings.cacheCfg(), cache: cache.clear(body.table ? String(body.table) : '') });
      }
      if (p === '/cache/settings' && method === 'POST') {
        const next = settings.setCache(body);
        cache.sweep('upstream', { force: true });
        return ok({ cacheSettings: next, cache: cache.stats() });
      }

      if (p === '/test' && method === 'POST') {
        return ok({ result: await selfTest(body) });
      }

      return bad(404, `插件设置页没有这个接口：${method} ${p}`);
    } catch (e) {
      return bad(400, (e && e.message) || String(e));
    }
  },
};

/**
 * 一键自检：① 服务连通性（`/System/Info/Public`，无需鉴权）
 * ② 登录 + 搜索一发（界面里刚敲的账密也能先拿来测）。
 * 两段各报一次，失败如实说原因（不猜、不兜底）。
 * **不展示 `ServerName`** —— 真机上它是容器主机名，没有意义。
 */
async function selfTest(body) {
  const cfg = settings.effective(body, settings.read(), settings.readAuth());
  const wd = String((body && body.wd) || TEST_WD).trim() || TEST_WD;
  const auth = settings.publicAuth();
  const out = { name: instanceName(cfg), base: cfg.base, wd, auth, info: null, search: null };

  if (!cfg.base) {
    const miss = { ok: false, status: 0, ms: 0, error: NO_BASE.message, code: NO_BASE.code };
    out.info = miss;
    out.search = miss;
    return out;
  }

  /* 1) 连通性 */
  const t0 = Date.now();
  try {
    const r = await emby.info(cfg.base, { timeout: 12000 });
    const j = r.json || {};
    out.info = { ok: true, ms: Date.now() - t0, version: String(j.Version || ''), serverId: String(j.Id || '') };
  } catch (e) {
    out.info = {
      ok: false,
      status: Number(e && e.status) || 0,
      ms: Date.now() - t0,
      error: (e && e.message) || String(e),
      code: (e && e.code) || '',
    };
  }

  /* 2) 登录（给了账密就现登，验证账密本身）+ 搜索一发 */
  const t1 = Date.now();
  try {
    let token = '';
    let loggedIn = false;
    if (cfg.username && cfg.password) {
      const r = await emby.authenticate(cfg.base, cfg.username, cfg.password, { timeout: 12000 });
      token = r.token;
      loggedIn = true;
    } else {
      token = settings.readAuth().token;
    }
    const res = await emby.searchItems(cfg.base, { term: wd, token, limit: 10, timeout: 12000 });
    out.search = {
      ok: true,
      ms: Date.now() - t1,
      loggedIn,
      count: res.items.length,
      total: res.total,
      top: res.items.slice(0, 3).map((x) => x.Name),
    };
  } catch (e) {
    out.search = {
      ok: false,
      status: Number(e && e.status) || 0,
      ms: Date.now() - t1,
      error: (e && e.message) || String(e),
      code: (e && e.code) || '',
    };
  }
  return out;
}

module.exports = { actions };
